'use strict';
const root = document.getElementById('root');
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const svg = (d, s = 24) => `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${d}</svg>`;
const BRAND = `<div class="brand"><i>${svg('<path d="m5 12.5 4.5 4.5L19 7.5" stroke="#fff" stroke-width="2.6"/>', 20)}</i>Betriebsportal</div>`;
const I_SERVER = '<rect x="3.5" y="4" width="17" height="7" rx="2"/><rect x="3.5" y="13" width="17" height="7" rx="2"/><path d="M7.5 7.5h.01M7.5 16.5h.01"/>';
const I_PC = '<rect x="3" y="4.5" width="18" height="12" rx="2"/><path d="M8.5 20h7M12 16.5V20"/>';

function choose() {
  root.innerHTML = `${BRAND}<h1>Willkommen!</h1><p>Wie soll dieser Computer das Betriebsportal benutzen?</p>
    <div class="cards">
      <button class="card" id="srv"><span class="ico">${svg(I_SERVER)}</span><b>Das ist der Hauptrechner</b>
        <span>Hier werden alle Daten der Firma gespeichert. Diesen Computer gibt es nur einmal – er sollte während der Arbeitszeit eingeschaltet sein.</span><em>Für die erste Installation in der Firma</em></button>
      <button class="card" id="cli"><span class="ico">${svg(I_PC)}</span><b>Mit dem Hauptrechner verbinden</b>
        <span>Für alle weiteren Arbeitsplätze. Das Programm sucht den Hauptrechner automatisch im Netzwerk.</span><em>Für alle Kollegen</em></button>
    </div>`;
  document.getElementById('srv').onclick = () => { starting('Hauptrechner wird eingerichtet …'); portalApp.choose({ mode: 'server' }); };
  document.getElementById('cli').onclick = () => connect();
}
async function connect(prefill = '', error = '') {
  root.innerHTML = `${BRAND}<h1>Hauptrechner verbinden</h1><p>Das Betriebsportal muss auf dem Hauptrechner gestartet sein.</p>
    <div class="panel"><div class="lbl">Im Netzwerk gefunden</div><div id="list"><p style="margin-top:10px">Suche läuft …</p></div>
      <div class="lbl">Oder Adresse von Hand eingeben</div>
      <form class="row" id="f"><input id="url" placeholder="z. B. 192.168.1.20 oder https://portal.firma.de" value="${esc(prefill)}" spellcheck="false"><button class="btn primary">Verbinden</button></form>
      <div class="err" id="err" ${error ? '' : 'hidden'}>${esc(error)}</div></div>
    <button class="link" id="back">← Zurück</button> &nbsp; <button class="link" id="again">Erneut suchen</button>`;
  const err = document.getElementById('err');
  const go = async (url, btn) => {
    err.hidden = true; if (btn) btn.disabled = true;
    const r = await portalApp.choose({ mode: 'client', url });
    if (r && r.error) { err.textContent = r.error; err.hidden = false; if (btn) btn.disabled = false; }
  };
  document.getElementById('f').onsubmit = (e) => { e.preventDefault(); go(document.getElementById('url').value, e.target.querySelector('button')); };
  document.getElementById('back').onclick = choose;
  document.getElementById('again').onclick = () => connect(document.getElementById('url').value);
  const found = await portalApp.discover();
  const list = document.getElementById('list'); if (!list) return;
  list.innerHTML = found.length
    ? found.map((s, i) => `<button class="srv" data-i="${i}"><span style="color:var(--accent)">${svg(I_SERVER)}</span><span><b>${esc(s.name)}</b><small>${esc(s.url)}</small></span></button>`).join('')
    : '<p style="margin-top:10px">Kein Hauptrechner gefunden. Ist das Betriebsportal dort gestartet und sind beide Computer im selben Netzwerk? Du kannst die Adresse auch unten eingeben – sie steht am Hauptrechner im Menü des Symbols neben der Uhr.</p>';
  list.querySelectorAll('.srv').forEach((b) => b.onclick = () => go(found[+b.dataset.i].url, b));
}
function starting(text = 'Betriebsportal wird gestartet …') {
  root.innerHTML = `<div class="center"><div class="spin"></div><h1 style="font-size:21px">${esc(text)}</h1></div>`;
}
function offline(st) {
  root.innerHTML = `${BRAND}<h1>Hauptrechner nicht erreichbar</h1>
    <p>Unter <b>${esc(st.url || '')}</b> antwortet das Betriebsportal gerade nicht. Bitte prüfe, ob der Hauptrechner eingeschaltet ist, das Programm dort läuft und du im Firmennetzwerk bist.</p>
    <div class="row" style="margin-top:22px"><button class="btn primary" id="retry">Erneut versuchen</button><button class="btn" id="other">Anderen Hauptrechner wählen</button></div>`;
  document.getElementById('retry').onclick = () => { starting('Verbindung wird hergestellt …'); portalApp.retry(); };
  document.getElementById('other').onclick = () => connect();
  setTimeout(() => { if (document.getElementById('retry')) portalApp.retry(); }, 15000); // von selbst erneut versuchen
}
(async () => {
  const st = await portalApp.state();
  document.getElementById('ver').textContent = st ? `Version ${st.version}` : '';
  if (!st || st.view === 'choose') choose();
  else if (st.view === 'offline') offline(st);
  else starting();
})();
