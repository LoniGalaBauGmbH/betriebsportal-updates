'use strict';
const $ = (id) => document.getElementById(id);
portalApp.onProgress((d) => {
  $('title').textContent = d.title; $('text').textContent = d.text;
  const run = !(d.pct >= 0);
  $('bar').classList.toggle('run', run);
  $('fill').style.width = run ? '' : Math.round(d.pct * 100) + '%';
  $('pct').textContent = run ? '' : Math.round(d.pct * 100) + ' %';
});
