"use strict";
var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  try {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  } catch (e) {
    throw mod = 0, e;
  }
};

// versions.js
var require_versions = __commonJS({
  "versions.js"(exports2, module2) {
    "use strict";
    var fs2 = require("node:fs");
    var path2 = require("node:path");
    var RE2 = /^\d+\.\d+\.\d+$/;
    var cmp2 = (a, b) => {
      const x = a.split(".").map(Number), y = b.split(".").map(Number);
      for (let i = 0; i < 3; i++) if (x[i] !== y[i]) return x[i] - y[i];
      return 0;
    };
    function staged(dataDir, than, onlyApproved = false) {
      const dir = path2.join(dataDir, "app");
      let names = [];
      try {
        names = fs2.readdirSync(dir);
      } catch {
        return null;
      }
      let best = null;
      for (const n of names) {
        if (!RE2.test(n) || cmp2(n, than) <= 0) continue;
        const d = path2.join(dir, n);
        if (!fs2.existsSync(path2.join(d, "ok")) || fs2.existsSync(path2.join(d, "bad"))) continue;
        if (onlyApproved && !fs2.existsSync(path2.join(d, "approved"))) continue;
        if (!best || cmp2(n, best.version) > 0) best = { version: n, dir: d };
      }
      return best;
    }
    var updateMode = (dataDir) => {
      try {
        return fs2.readFileSync(path2.join(dataDir, "update-mode.txt"), "utf8").trim() === "manual" ? "manual" : "auto";
      } catch {
        return "auto";
      }
    };
    var pick = (dataDir, embedded) => staged(dataDir, embedded, updateMode(dataDir) === "manual");
    module2.exports = { RE: RE2, cmp: cmp2, staged, updateMode, pick };
  }
});

// supervisor.js
var require_supervisor = __commonJS({
  "supervisor.js"(exports2, module2) {
    "use strict";
    var fs2 = require("node:fs");
    var path2 = require("node:path");
    var crypto2 = require("node:crypto");
    var zlib = require("node:zlib");
    var { RE: RE2, cmp: cmp2, staged, updateMode, pick } = require_versions();
    function createSupervisor2({ dataDir, embedded, pubkey, bakedUrl, spawnChild, log: log2 = () => {
    }, onExit = () => {
    }, onStart = () => {
    } }) {
      const APPDIR = path2.join(dataDir, "app");
      let child = null, running = null, restarting = false, stopping = false, first = true, busy = false;
      const fails = /* @__PURE__ */ new Map();
      const mode = () => updateMode(dataDir);
      const writeStatus = (extra) => {
        try {
          fs2.writeFileSync(path2.join(APPDIR, "check-result.json"), JSON.stringify({ at: (/* @__PURE__ */ new Date()).toISOString(), running, current: current(), configured: !!updateUrl(), ...extra }));
        } catch {
        }
      };
      function updateUrl() {
        let u = process.env.PORTAL_UPDATE_URL || "";
        if (!u) {
          try {
            u = fs2.readFileSync(path2.join(dataDir, "update-url.txt"), "utf8").trim();
          } catch {
          }
        }
        u = (u || bakedUrl || "").replace(/\/+$/, "");
        if (!u) return null;
        let p;
        try {
          p = new URL(u);
        } catch {
          return null;
        }
        if (p.protocol !== "https:" && !["localhost", "127.0.0.1"].includes(p.hostname)) return null;
        return u;
      }
      const current = () => pick(dataDir, embedded)?.version || embedded;
      const newest = () => staged(dataDir, embedded)?.version || embedded;
      async function check() {
        const url = updateUrl();
        if (!url || !pubkey) return null;
        const r = await fetch(`${url}/update.json?t=${Date.now()}`, { signal: AbortSignal.timeout(15e3), cache: "no-store" });
        if (r.status === 404) return null;
        if (!r.ok) throw new Error(`Update-Server antwortet mit ${r.status}`);
        const m = await r.json();
        if (!RE2.test(m.version) || !/^[\w.\-]+$/.test(m.file || "") || !/^[0-9a-f]{64}$/.test(m.sha256 || "") || typeof m.sig !== "string") throw new Error("Ung\xFCltige Update-Beschreibung");
        if (cmp2(m.version, newest()) <= 0) return null;
        if (fs2.existsSync(path2.join(APPDIR, m.version, "bad"))) return null;
        const okSig = crypto2.verify(null, Buffer.from(`${m.version}
${m.sha256}`), crypto2.createPublicKey(pubkey), Buffer.from(m.sig, "base64"));
        if (!okSig) throw new Error("Signatur des Updates ist ung\xFCltig \u2013 Update wird NICHT installiert");
        const fr = await fetch(new URL(m.file, url + "/"), { signal: AbortSignal.timeout(12e4), cache: "no-store" });
        if (!fr.ok) throw new Error(`Update-Paket nicht ladbar (${fr.status})`);
        const buf = Buffer.from(await fr.arrayBuffer());
        if (buf.length > 60 * 1024 * 1024) throw new Error("Update-Paket ist zu gro\xDF");
        if (crypto2.createHash("sha256").update(buf).digest("hex") !== m.sha256) throw new Error("Pr\xFCfsumme des Updates stimmt nicht \u2013 Update wird NICHT installiert");
        const pkg = JSON.parse(zlib.gunzipSync(buf, { maxOutputLength: 200 * 1024 * 1024 }).toString("utf8"));
        if (pkg.version !== m.version || !pkg.files || !pkg.files["portal.js"]) throw new Error("Update-Paket ist unvollst\xE4ndig");
        const tmp = path2.join(APPDIR, `.tmp-${m.version}`), dest = path2.join(APPDIR, m.version);
        fs2.rmSync(tmp, { recursive: true, force: true });
        fs2.rmSync(dest, { recursive: true, force: true });
        fs2.mkdirSync(path2.join(tmp, "public"), { recursive: true });
        for (const [name, b64] of Object.entries(pkg.files)) {
          if (!/^(portal\.js|public\/[\w.\-]+)$/.test(name) || name.includes("..")) throw new Error(`Unerwartete Datei im Update: ${name}`);
          fs2.writeFileSync(path2.join(tmp, name), Buffer.from(b64, "base64"));
        }
        fs2.renameSync(tmp, dest);
        fs2.writeFileSync(path2.join(dest, "ok"), (/* @__PURE__ */ new Date()).toISOString());
        for (const n of fs2.readdirSync(APPDIR)) {
          if (n === m.version || n === running) continue;
          const d = path2.join(APPDIR, n);
          try {
            if (RE2.test(n) && fs2.existsSync(path2.join(d, "bad"))) {
              for (const f of fs2.readdirSync(d)) if (f !== "bad") fs2.rmSync(path2.join(d, f), { recursive: true, force: true });
            } else fs2.rmSync(d, { recursive: true, force: true });
          } catch {
          }
        }
        return m.version;
      }
      function start() {
        running = current();
        restarting = false;
        const usedStaged = running !== embedded;
        child = spawnChild({ PORTAL_CHILD: "1", PORTAL_PACKAGED: "1", PORTAL_SUPERVISED: "1", ...first ? {} : { NO_BROWSER: "1" } });
        const isRestart = !first;
        first = false;
        onStart({ version: running, isRestart });
        child.on("exit", (code, signal) => {
          if (stopping) return;
          if (restarting || code === 75) return start();
          if (code === 0) return onExit(0);
          const dir = path2.join(APPDIR, running);
          if (usedStaged && !signal && !fs2.existsSync(path2.join(dir, "started"))) {
            fails.set(running, (fails.get(running) || 0) + 1);
            if (fails.get(running) >= 2) {
              try {
                fs2.writeFileSync(path2.join(dir, "bad"), String(code));
              } catch {
              }
              log2(`Version ${running} l\xE4sst sich nicht starten \u2013 zur\xFCck zur vorherigen Version.`);
            }
            return start();
          }
          onExit(code || 1);
        });
      }
      const restart = () => {
        if (child && !restarting) {
          restarting = true;
          child.kill();
        }
      };
      const stop = () => {
        stopping = true;
        if (child) child.kill();
      };
      async function tick(initial) {
        if (busy) return;
        busy = true;
        try {
          const v = await check();
          if (v) log2(`Version ${v} heruntergeladen und gepr\xFCft.`);
          writeStatus({ ok: true, found: v });
        } catch (e) {
          log2(`Pr\xFCfung nicht m\xF6glich: ${e.message}`);
          writeStatus({ ok: false, error: e.message });
        } finally {
          busy = false;
        }
        if (initial) return;
        const pending = current() !== running;
        const h = (/* @__PURE__ */ new Date()).getHours();
        if (pending && mode() === "auto" && h >= 2 && h < 5) {
          log2(`Installiere Version ${current()} \u2026`);
          restart();
        } else if (pending) log2(`Version ${current()} liegt bereit \u2013 wird heute Nacht, beim n\xE4chsten Start oder per Klick (\u201EJetzt installieren\u201C) eingespielt.`);
        else if (newest() !== running && mode() === "manual") log2(`Version ${newest()} liegt bereit \u2013 wartet auf die Freigabe durch einen Administrator (\u201EJetzt installieren\u201C).`);
      }
      async function run() {
        fs2.mkdirSync(APPDIR, { recursive: true });
        if (updateUrl()) {
          log2("Suche nach Updates \u2026");
          await tick(true);
        }
        start();
        const every = Math.max(1, Number(process.env.PORTAL_UPDATE_MINUTES) || 60) * 6e4;
        const t = setInterval(() => tick(false), every);
        t.unref?.();
        const flag = path2.join(APPDIR, "check-now");
        const w = setInterval(() => {
          if (fs2.existsSync(flag)) {
            fs2.rmSync(flag, { force: true });
            tick(false);
          }
        }, 2e3);
        w.unref?.();
      }
      return { run, stop, restart, check, current, updateUrl, runningVersion: () => running };
    }
    module2.exports = { createSupervisor: createSupervisor2 };
  }
});

// package.json
var require_package = __commonJS({
  "package.json"(exports2, module2) {
    module2.exports = {
      name: "betriebsportal",
      version: "1.5.3",
      description: "Betriebsinternes Portal: Aufgaben, Nachrichten, Dateien, Kalender",
      private: true,
      engines: {
        node: ">=22.5"
      },
      scripts: {
        start: "node --no-warnings server.js",
        demo: "node --no-warnings demo.js",
        build: "node build.js",
        "build:update": "node build.js --update-only",
        release: "node release.js"
      },
      devDependencies: {
        esbuild: "^0.28.2",
        "pe-library": "^2.0.3",
        "png-to-ico": "^3.0.2",
        postject: "^1.0.0-alpha.6",
        resedit: "^3.1.1"
      }
    };
  }
});

// desktop/main.js
var { app, BrowserWindow, Tray, Menu, ipcMain, shell, dialog, clipboard, nativeImage, screen, nativeTheme, powerSaveBlocker } = require("electron");
var fs = require("node:fs");
var path = require("node:path");
var os = require("node:os");
var dgram = require("node:dgram");
var { spawn } = require("node:child_process");
var crypto = require("node:crypto");
var { createSupervisor } = require_supervisor();
var { RE, cmp } = require_versions();
var EMBEDDED = require_package().version;
var PUBKEY = true ? "-----BEGIN PUBLIC KEY-----\nMCowBQYDK2VwAyEAyws5xZoB3KzaP/iGvCj6eyJoX0BTrYeUknfkEitCP2I=\n-----END PUBLIC KEY-----\n" : "";
var BAKED_URL = true ? "https://github.com/LoniGalaBauGmbH/betriebsportal-updates/releases/latest/download" : "";
var PORT = Number(process.env.PORT) || 3e3;
var DISCOVERY_PORT = 41234;
var DATA = process.env.DATA_DIR ? path.resolve(process.env.DATA_DIR) : path.join(os.homedir(), "Betriebsportal-Daten");
var RES = __dirname;
var ICON = path.join(RES, "icon.png");
var LOCAL_URL = `http://localhost:${PORT}`;
var MAC = process.platform === "darwin";
var HIDDEN_START = process.argv.includes("--hidden") || MAC && app.getLoginItemSettings().wasOpenedAtLogin;
app.setName("Betriebsportal");
if (process.platform === "win32") app.setAppUserModelId("de.betriebsportal.app");
if (!app.requestSingleInstanceLock()) {
  app.quit();
  return;
}
var cfgFile = () => path.join(app.getPath("userData"), "config.json");
var cfg = {};
var loadCfg = () => {
  try {
    cfg = JSON.parse(fs.readFileSync(cfgFile(), "utf8"));
  } catch {
    cfg = {};
  }
};
var saveCfg = () => {
  fs.mkdirSync(path.dirname(cfgFile()), { recursive: true });
  fs.writeFileSync(cfgFile(), JSON.stringify(cfg, null, 2));
};
var win = null;
var tray = null;
var popup = null;
var popupTimer = null;
var popupData = null;
var unread = 0;
var sup = null;
var quitting = false;
var state = { view: "choose" };
var logStream = null;
var discoverySocket = null;
var log = (m) => {
  try {
    logStream?.write(`[${(/* @__PURE__ */ new Date()).toISOString()}] ${m}
`);
  } catch {
  }
};
var lanAddresses = () => Object.values(os.networkInterfaces()).flat().filter((n) => n && n.family === "IPv4" && !n.internal);
var lanUrl = () => {
  const a = lanAddresses()[0];
  return a ? `http://${a.address}:${PORT}` : LOCAL_URL;
};
var sleep = (ms) => new Promise((r) => setTimeout(r, ms));
async function isPortal(url, timeout = 2500) {
  try {
    const r = await fetch(`${url}/api/setup`, { signal: AbortSignal.timeout(timeout) });
    return r.ok && typeof (await r.json()).needed === "boolean";
  } catch {
    return false;
  }
}
async function waitForPortal(url, ms) {
  const end = Date.now() + ms;
  while (Date.now() < end) {
    if (await isPortal(url, 1500)) return true;
    await sleep(300);
  }
  return false;
}
function showSetup(next) {
  state = next;
  if (win) win.loadFile(path.join(RES, "setup.html"));
}
function createWindow() {
  win = new BrowserWindow({
    width: 1320,
    height: 880,
    minWidth: 380,
    minHeight: 560,
    show: false,
    title: "Betriebsportal",
    icon: ICON,
    backgroundColor: "#f5f6f8",
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(RES, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      spellcheck: true,
      backgroundThrottling: false
    }
    // auch bei geschlossenem Fenster weiter nach neuen Nachrichten sehen
  });
  win.once("ready-to-show", () => {
    if (!HIDDEN_START) win.show();
  });
  win.on("close", (e) => {
    if (quitting || !cfg.mode) return;
    e.preventDefault();
    win.hide();
    if (cfg.trayHint !== 2) {
      cfg.trayHint = 2;
      saveCfg();
      const where = MAC ? "oben rechts in der Men\xFCleiste" : "unten rechts neben der Uhr";
      dialog.showMessageBox({
        type: "info",
        title: "Betriebsportal l\xE4uft weiter",
        message: "Das Betriebsportal l\xE4uft im Hintergrund weiter",
        buttons: ["Verstanden"],
        detail: (cfg.mode === "server" ? "Dieser Computer ist der Hauptrechner \u2013 solange das Programm l\xE4uft, k\xF6nnen deine Kollegen arbeiten." : "So bekommst du neue Nachrichten auch dann angezeigt, wenn das Fenster zu ist.") + `

\xD6ffnen oder ganz beenden kannst du es \xFCber das Symbol ${where}.`
      });
    }
  });
  win.on("focus", () => {
    win.flashFrame(false);
    hidePopup();
  });
  win.on("page-title-updated", (_e, title) => {
    if (/^\(\d+\)/.test(title) && !win.isFocused()) win.flashFrame(true);
  });
  const allowed = (url) => url.startsWith("file://") || state.url && url.startsWith(state.url);
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:\/\//.test(url) && !allowed(url)) shell.openExternal(url);
    return { action: "deny" };
  });
  win.webContents.on("will-navigate", (e, url) => {
    if (!allowed(url)) {
      e.preventDefault();
      if (/^https?:\/\//.test(url)) shell.openExternal(url);
    }
  });
  win.webContents.on("did-fail-load", (_e, code, _desc, url, isMain) => {
    if (!isMain || code === -3 || url.startsWith("file://")) return;
    showSetup({ view: "offline", mode: cfg.mode, url: cfg.url });
  });
  win.webContents.session.setSpellCheckerLanguages?.(["de-DE"]);
}
var showWindow = () => {
  if (!win) return;
  if (win.isMinimized()) win.restore();
  win.show();
  win.focus();
};
async function openPortal(url) {
  state = { view: "portal", url };
  await win.loadURL(url).catch(() => {
  });
}
function startDiscovery() {
  try {
    discoverySocket = dgram.createSocket({ type: "udp4", reuseAddr: true });
    discoverySocket.on("error", () => {
    });
    discoverySocket.on("message", (msg, r) => {
      if (msg.toString() !== "BETRIEBSPORTAL?") return;
      discoverySocket.send(JSON.stringify({ app: "betriebsportal", name: os.hostname(), port: PORT }), r.port, r.address);
    });
    discoverySocket.bind(DISCOVERY_PORT);
  } catch {
  }
}
async function quitApp() {
  if (cfg.mode === "server") {
    const r = await dialog.showMessageBox({ type: "question", title: "Betriebsportal beenden", message: "Betriebsportal wirklich beenden?", detail: "Dieser Computer ist der Hauptrechner. Solange das Programm beendet ist, k\xF6nnen deine Kollegen nicht mehr darauf zugreifen.", buttons: ["Beenden", "Abbrechen"], defaultId: 1, cancelId: 1 });
    if (r.response !== 0) return;
  }
  quitting = true;
  app.quit();
}
var autostart = () => MAC ? app.getLoginItemSettings().openAtLogin : app.getLoginItemSettings({ args: ["--hidden"] }).openAtLogin;
var setAutostart = (on) => app.setLoginItemSettings(MAC ? { openAtLogin: on } : { openAtLogin: on, args: ["--hidden"] });
function buildTray() {
  if (tray) return;
  let img = nativeImage.createFromPath(path.join(RES, "tray.png"));
  if (MAC) img = img.resize({ width: 18, height: 18 });
  tray = new Tray(img);
  const server = () => cfg.mode === "server";
  const menu = () => Menu.buildFromTemplate([
    { label: unread ? `Betriebsportal \xF6ffnen (${unread} ungelesen)` : "Betriebsportal \xF6ffnen", click: showWindow },
    { type: "separator" },
    ...server() ? [
      { label: `Adresse f\xFCr Kollegen: ${lanUrl()}`, sublabel: "Klicken zum Kopieren", click: () => clipboard.writeText(lanUrl()) },
      { label: "Daten-Ordner \xF6ffnen", click: () => shell.openPath(DATA) }
    ] : [{ label: "Verbindung zum Hauptrechner \xE4ndern \u2026", click: () => {
      showSetup({ view: "choose" });
      showWindow();
    } }],
    { label: "Nach Programm-Update suchen", click: () => checkShellUpdate(true) },
    { label: "Test-Benachrichtigung anzeigen", click: testNotification },
    { label: "Beim Start des Computers automatisch starten", type: "checkbox", checked: autostart(), click: (i) => setAutostart(i.checked) },
    { type: "separator" },
    { label: `Version ${sup?.runningVersion() || EMBEDDED}`, enabled: false },
    { label: "Beenden", click: quitApp }
  ]);
  if (MAC) {
    tray.on("click", () => tray.popUpContextMenu(menu()));
    tray.on("right-click", () => tray.popUpContextMenu(menu()));
  } else {
    tray.on("click", showWindow);
    tray.on("right-click", () => tray.popUpContextMenu(menu()));
  }
  paintUnread();
}
function paintUnread() {
  if (tray) tray.setToolTip(unread ? `Betriebsportal \u2013 ${unread} ungelesene Nachricht${unread === 1 ? "" : "en"}` : cfg.mode === "server" ? "Betriebsportal (Hauptrechner)" : "Betriebsportal");
  try {
    if (MAC) app.dock?.setBadge(unread ? String(unread) : "");
    else if (process.platform === "win32" && win) win.setOverlayIcon(unread ? nativeImage.createFromPath(path.join(RES, "dot.png")) : null, unread ? `${unread} ungelesen` : "");
  } catch {
  }
}
function shellLog(msg) {
  try {
    const f = path.join(app.getPath("userData"), "programm.log");
    try {
      if (fs.statSync(f).size > 1024 * 1024) fs.renameSync(f, f + ".alt");
    } catch {
    }
    fs.appendFileSync(f, `[${(/* @__PURE__ */ new Date()).toISOString()}] ${msg}
`);
  } catch {
  }
}
var mainFocused = () => !!win && win.isVisible() && !win.isMinimized() && win.isFocused();
var initialsOf = (n) => String(n || "").split(/\s+/).filter(Boolean).slice(0, 2).map((p) => p[0]).join("").toUpperCase();
var hueOf = (n) => {
  let h = 0;
  for (const c of String(n || "")) h = (h * 31 + c.charCodeAt(0)) % 360;
  return h;
};
function hidePopup() {
  clearTimeout(popupTimer);
  if (popup && !popup.isDestroyed()) popup.hide();
}
function showPopup(data) {
  popupData = data;
  const W = 372, H = 98, M = 16;
  const area = screen.getPrimaryDisplay().workArea;
  const pos = { x: area.x + area.width - W - M, y: MAC ? area.y + M : area.y + area.height - H - M };
  const send = () => {
    if (!popup || popup.isDestroyed()) return;
    popup.setBounds({ ...pos, width: W, height: H });
    popup.webContents.send("popup:data", data);
    popup.showInactive();
    popup.setAlwaysOnTop(true, "screen-saver");
    popup.moveTop();
    shellLog(`Nachrichten-Fenster gezeigt: sichtbar=${popup.isVisible()} Position=${JSON.stringify(popup.getBounds())} Titel=${data.title}`);
  };
  if (popup && !popup.isDestroyed()) send();
  else {
    popup = new BrowserWindow({
      ...pos,
      width: W,
      height: H,
      frame: false,
      resizable: false,
      minimizable: false,
      maximizable: false,
      fullscreenable: false,
      skipTaskbar: true,
      alwaysOnTop: true,
      focusable: false,
      show: false,
      title: "Neue Nachricht",
      backgroundColor: nativeTheme.shouldUseDarkColors ? "#1d2129" : "#ffffff",
      webPreferences: { preload: path.join(RES, "preload.js"), contextIsolation: true, nodeIntegration: false, sandbox: true, backgroundThrottling: false }
    });
    try {
      popup.setVisibleOnAllWorkspaces(true, { visibleOnFullScreen: true });
    } catch {
    }
    popup.on("closed", () => {
      popup = null;
    });
    popup.loadFile(path.join(RES, "popup.html")).then(send).catch((e) => shellLog(`Nachrichten-Fenster konnte nicht geladen werden: ${e.message}`));
  }
  clearTimeout(popupTimer);
  popupTimer = setTimeout(hidePopup, 9e3);
}
var msgToken = null;
var msgLast = null;
async function pollMessages() {
  if (!win || state.view !== "portal" || !state.url) return;
  try {
    const ck = await win.webContents.session.cookies.get({ url: state.url, name: "sid" });
    const token = ck[0]?.value;
    if (!token) {
      msgToken = null;
      msgLast = null;
      return;
    }
    if (token !== msgToken) {
      msgToken = token;
      msgLast = null;
    }
    const r = await fetch(`${state.url}/api/summary`, { headers: { Cookie: `sid=${token}` }, signal: AbortSignal.timeout(6e3), cache: "no-store" });
    if (!r.ok) return;
    const s = await r.json();
    unread = Math.max(0, Number(s.unread) || 0);
    paintUnread();
    const l = s.latest;
    if (msgLast === null) {
      msgLast = l ? l.id : 0;
      return;
    }
    if (!l || l.id <= msgLast) return;
    msgLast = l.id;
    if (mainFocused()) return;
    const name = l.sender_name || "Neue Nachricht";
    showPopup({
      title: (name + (l.conv === "all" ? " \xB7 an alle" : "")).slice(0, 80),
      body: String(l.text || "").slice(0, 240),
      conv: String(l.conv || "all").slice(0, 20),
      initials: initialsOf(l.sender_name),
      hue: hueOf(l.sender_name),
      more: Math.max(0, unread - 1),
      sound: cfg.sound !== false
    });
    if (!MAC && win.isVisible()) win.flashFrame(true);
  } catch (e) {
  }
}
function testNotification() {
  showPopup({ title: "Test-Benachrichtigung", body: "So erscheint eine neue Nachricht \u2013 mit Ton. Ein Klick \xF6ffnet das Betriebsportal.", conv: "all", initials: "\u2713", hue: 225, more: 0, sound: true });
}
var fromPortal = (e) => win && e.sender === win.webContents && state.view === "portal" && (e.senderFrame?.url || "").startsWith(state.url);
ipcMain.handle("portal:message", (e) => fromPortal(e) ? !mainFocused() : false);
ipcMain.handle("portal:focused", (e) => fromPortal(e) ? mainFocused() : true);
ipcMain.on("portal:prefs", (e, p) => {
  if (!fromPortal(e) || !p) return;
  const s = p.sound !== false;
  if (cfg.sound !== s) {
    cfg.sound = s;
    saveCfg();
  }
});
ipcMain.on("portal:unread", (e, n) => {
  if (!fromPortal(e)) return;
  unread = Math.max(0, Math.min(9999, Number(n) || 0));
  paintUnread();
});
ipcMain.handle("portal:pickFolder", async (e, current) => {
  if (!fromPortal(e) || cfg.mode !== "server") return null;
  const r = await dialog.showOpenDialog(win, {
    title: "Ordner f\xFCr die Sicherung w\xE4hlen",
    buttonLabel: "Diesen Ordner verwenden",
    defaultPath: typeof current === "string" && current ? current : void 0,
    properties: ["openDirectory", "createDirectory"]
  });
  return r.canceled || !r.filePaths[0] ? null : r.filePaths[0];
});
ipcMain.handle("portal:openFolder", async (e, p) => {
  if (!fromPortal(e) || cfg.mode !== "server" || typeof p !== "string" || !path.isAbsolute(p)) return false;
  try {
    if (!fs.statSync(p).isDirectory()) return false;
  } catch {
    return false;
  }
  return await shell.openPath(p) === "";
});
var fromPopup = (e) => popup && !popup.isDestroyed() && e.sender === popup.webContents;
ipcMain.on("popup:close", (e) => {
  if (fromPopup(e)) hidePopup();
});
ipcMain.on("popup:click", (e) => {
  if (!fromPopup(e)) return;
  hidePopup();
  showWindow();
  const conv = JSON.stringify(popupData?.conv || "all");
  win.webContents.executeJavaScript(`(() => { try { S.conv = ${conv}; if (currentPage() === 'nachrichten') refresh(); else location.hash = '#/nachrichten'; } catch (e) {} })()`).catch(() => {
  });
});
async function startServer() {
  showSetup({ view: "starting" });
  if (await isPortal(`http://127.0.0.1:${PORT}`, 1200)) return openPortal(LOCAL_URL);
  fs.mkdirSync(DATA, { recursive: true });
  const logFile = path.join(DATA, "portal.log");
  try {
    if (fs.statSync(logFile).size > 2 * 1024 * 1024) fs.renameSync(logFile, logFile + ".alt");
  } catch {
  }
  logStream = fs.createWriteStream(logFile, { flags: "a" });
  sup = createSupervisor({
    dataDir: DATA,
    embedded: EMBEDDED,
    pubkey: PUBKEY,
    bakedUrl: BAKED_URL,
    log: (m) => log(`[Update] ${m}`),
    spawnChild: (env) => {
      const c = spawn(process.execPath, [path.join(RES, "server", "portal.js")], {
        env: { ...process.env, ...env, ELECTRON_RUN_AS_NODE: "1", PORTAL_DESKTOP: "1", NO_BROWSER: "1", PORT: String(PORT), DATA_DIR: DATA },
        stdio: ["pipe", "pipe", "pipe"],
        windowsHide: true
        // stdin bleibt offen und dient als Lebensleine
      });
      c.stdout.on("data", (d) => logStream.write(d));
      c.stderr.on("data", (d) => logStream.write(d));
      return c;
    },
    onStart: async ({ isRestart }) => {
      if (!isRestart) return;
      if (await waitForPortal(`http://127.0.0.1:${PORT}`, 3e4) && state.view === "portal") win.webContents.reload();
    },
    onExit: (code) => {
      if (quitting) return;
      dialog.showErrorBox("Betriebsportal konnte nicht gestartet werden", code === 3 ? `Der Anschluss ${PORT} wird auf diesem Computer bereits von einem anderen Programm benutzt.` : `Details stehen in der Datei:
${logFile}`);
      quitting = true;
      app.quit();
    }
  });
  await sup.run();
  if (await waitForPortal(`http://127.0.0.1:${PORT}`, 4e4)) {
    startDiscovery();
    await openPortal(LOCAL_URL);
  }
}
var shellBusy = false;
var shellDeclined = false;
var progressWin = null;
function showProgress(title, text, pct) {
  const data = { title, text, pct };
  if (progressWin && !progressWin.isDestroyed()) {
    progressWin.webContents.send("progress:data", data);
    return;
  }
  progressWin = new BrowserWindow({
    width: 460,
    height: 210,
    resizable: false,
    minimizable: false,
    maximizable: false,
    fullscreenable: false,
    closable: false,
    alwaysOnTop: true,
    title: "Programm-Update",
    icon: ICON,
    autoHideMenuBar: true,
    show: false,
    backgroundColor: "#f5f6f8",
    webPreferences: { preload: path.join(RES, "preload.js"), contextIsolation: true, nodeIntegration: false, sandbox: true }
  });
  progressWin.setMenuBarVisibility(false);
  progressWin.loadFile(path.join(RES, "progress.html")).then(() => {
    if (progressWin && !progressWin.isDestroyed()) {
      progressWin.webContents.send("progress:data", data);
      progressWin.show();
    }
  }).catch(() => {
  });
}
function closeProgress() {
  if (progressWin && !progressWin.isDestroyed()) {
    progressWin.destroy();
  }
  progressWin = null;
}
function manifestUrl() {
  let u = process.env.PORTAL_UPDATE_URL || "";
  if (!u) {
    try {
      u = fs.readFileSync(path.join(DATA, "update-url.txt"), "utf8").trim();
    } catch {
    }
  }
  u = (u || BAKED_URL || "").replace(/\/+$/, "");
  try {
    const p = new URL(u);
    if (p.protocol === "https:" || ["localhost", "127.0.0.1"].includes(p.hostname)) return u;
  } catch {
  }
  return null;
}
var safeUrl = (u) => {
  try {
    const p = new URL(u);
    return p.protocol === "https:" || ["localhost", "127.0.0.1"].includes(p.hostname);
  } catch {
    return false;
  }
};
async function findShellUpdate() {
  const url = manifestUrl();
  if (!url || !PUBKEY) return null;
  const r = await fetch(`${url}/update.json?t=${Date.now()}`, { signal: AbortSignal.timeout(15e3), cache: "no-store" });
  if (!r.ok) throw new Error(`Update-Server antwortet mit ${r.status}`);
  const s = (await r.json()).shell;
  if (!s || !RE.test(s.version || "") || cmp(s.version, EMBEDDED) <= 0) return null;
  if (!/^[0-9a-f]{64}$/.test(s.sha256 || "") || typeof s.sig !== "string" || !safeUrl(s.url)) throw new Error("Ung\xFCltige Update-Beschreibung");
  if (!crypto.verify(null, Buffer.from(`shell
${s.version}
${s.sha256}`), crypto.createPublicKey(PUBKEY), Buffer.from(s.sig, "base64"))) throw new Error("Signatur des Programm-Updates ist ung\xFCltig");
  return s;
}
async function downloadShell(s, onProgress = () => {
}) {
  const file = path.join(app.getPath("temp"), `Betriebsportal-Setup-${s.version}.exe`);
  const r = await fetch(s.url, { signal: AbortSignal.timeout(30 * 6e4), cache: "no-store" });
  if (!r.ok || !r.body) throw new Error(`Download fehlgeschlagen (${r.status})`);
  const total = Number(r.headers.get("content-length")) || 0;
  const hash = crypto.createHash("sha256"), out = fs.createWriteStream(file);
  let got = 0;
  for await (const chunk of r.body) {
    got += chunk.length;
    if (got > 600 * 1024 * 1024) {
      out.destroy();
      throw new Error("Download ist zu gro\xDF");
    }
    hash.update(chunk);
    if (!out.write(chunk)) await new Promise((res) => out.once("drain", res));
    if (total && win) win.setProgressBar(Math.min(got / total, 1));
    onProgress(got, total);
  }
  await new Promise((res, rej) => out.end((e) => e ? rej(e) : res()));
  if (win) win.setProgressBar(-1);
  if (hash.digest("hex") !== s.sha256) {
    fs.rmSync(file, { force: true });
    throw new Error("Pr\xFCfsumme des Downloads stimmt nicht \u2013 es wird nichts installiert");
  }
  return file;
}
async function checkShellUpdate(manual = false) {
  if (shellBusy || process.platform !== "win32" && !process.env.PORTAL_SHELL_DRYRUN) {
    if (manual && !shellBusy) dialog.showMessageBox({ type: "info", message: "Programm-Updates gibt es derzeit nur f\xFCr Windows." });
    return;
  }
  if (shellDeclined && !manual) return;
  shellBusy = true;
  try {
    const s = await findShellUpdate();
    if (!s) {
      if (manual) dialog.showMessageBox({ type: "info", title: "Betriebsportal", message: "Das Programm ist aktuell", detail: `Installiert ist Version ${EMBEDDED}.` });
      return;
    }
    const ask = process.env.PORTAL_SHELL_AUTO ? { response: 0 } : await dialog.showMessageBox({
      type: "question",
      title: "Programm-Update",
      message: `Eine neue Programmversion (${s.version}) ist verf\xFCgbar`,
      detail: "Das Update wird heruntergeladen, gepr\xFCft und installiert. Das Programm startet danach von selbst neu \u2013 das dauert etwa eine Minute." + (cfg.mode === "server" ? "\n\nW\xE4hrend der Installation k\xF6nnen deine Kollegen kurz nicht arbeiten." : ""),
      buttons: ["Jetzt aktualisieren", "Sp\xE4ter"],
      defaultId: 0,
      cancelId: 1
    });
    if (ask.response !== 0) {
      shellDeclined = true;
      return;
    }
    const mb = (n) => (n / 1048576).toFixed(0);
    let last = 0;
    showProgress(`Version ${s.version} wird geladen`, "Verbindung wird aufgebaut \u2026", -1);
    const file = await downloadShell(s, (got, total) => {
      if (Date.now() - last < 150 && got < total) return;
      last = Date.now();
      showProgress(`Version ${s.version} wird geladen`, total ? `${mb(got)} von ${mb(total)} MB` : `${mb(got)} MB`, total ? got / total : -1);
    });
    showProgress("Update wird installiert", "Das Programm schlie\xDFt sich gleich und startet danach von selbst neu.", -1);
    log(`[Programm-Update] Version ${s.version} gepr\xFCft, Installation startet`);
    if (process.env.PORTAL_SHELL_DRYRUN) {
      fs.writeFileSync(process.env.PORTAL_SHELL_DRYRUN, file);
      await sleep(1500);
      closeProgress();
      return;
    }
    spawn(file, ["/S"], { detached: true, stdio: "ignore" }).unref();
    quitting = true;
    setTimeout(() => app.quit(), 1500);
  } catch (e) {
    log(`[Programm-Update] ${e.message}`);
    closeProgress();
    if (win) win.setProgressBar(-1);
    if (manual) dialog.showMessageBox({ type: "warning", title: "Programm-Update", message: "Das Update konnte nicht geladen werden", detail: e.message });
  } finally {
    shellBusy = false;
  }
}
function discover(ms = 1600) {
  return new Promise((resolve) => {
    const found = /* @__PURE__ */ new Map();
    const s = dgram.createSocket("udp4");
    s.on("error", () => resolve([]));
    s.on("message", (msg, r) => {
      try {
        const j = JSON.parse(msg.toString());
        if (j.app === "betriebsportal") found.set(r.address, { name: String(j.name || r.address).slice(0, 60), url: `http://${r.address}:${Number(j.port) || 3e3}` });
      } catch {
      }
    });
    s.bind(() => {
      s.setBroadcast(true);
      const targets = /* @__PURE__ */ new Set(["255.255.255.255"]);
      for (const n of lanAddresses()) {
        const a = n.address.split(".").map(Number), m = n.netmask.split(".").map(Number);
        targets.add(a.map((x, i) => x & m[i] | ~m[i] & 255).join("."));
      }
      for (const t of targets) s.send("BETRIEBSPORTAL?", DISCOVERY_PORT, t, () => {
      });
    });
    setTimeout(() => {
      try {
        s.close();
      } catch {
      }
      resolve([...found.values()]);
    }, ms);
  });
}
async function connectClient() {
  showSetup({ view: "starting" });
  if (await isPortal(cfg.url, 4e3)) return openPortal(cfg.url);
  showSetup({ view: "offline", mode: "client", url: cfg.url });
}
function normalizeUrl(input) {
  let u = String(input || "").trim();
  if (!u) return null;
  if (!/^https?:\/\//i.test(u)) u = "http://" + u;
  try {
    const p = new URL(u);
    if (!p.port && p.protocol === "http:") p.port = "3000";
    return p.origin;
  } catch {
    return null;
  }
}
var fromSetup = (e) => (e.senderFrame?.url || "").startsWith("file://");
ipcMain.handle("portal:state", (e) => fromSetup(e) ? { ...state, version: EMBEDDED } : null);
ipcMain.handle("portal:discover", (e) => fromSetup(e) ? discover() : []);
ipcMain.handle("portal:choose", async (e, c) => {
  if (!fromSetup(e)) return { error: "Nicht erlaubt" };
  if (c.mode === "server") {
    cfg = { ...cfg, mode: "server", url: void 0 };
    saveCfg();
    buildTray();
    startServer();
    return { ok: true };
  }
  const url = normalizeUrl(c.url);
  if (!url) return { error: "Bitte eine g\xFCltige Adresse eingeben, z. B. 192.168.1.20" };
  if (!await isPortal(url, 4e3)) return { error: `Unter ${url} antwortet kein Betriebsportal. L\xE4uft das Programm auf dem Hauptrechner, und sind beide Computer im selben Netzwerk?` };
  cfg = { ...cfg, mode: "client", url };
  saveCfg();
  buildTray();
  openPortal(url);
  return { ok: true };
});
ipcMain.handle("portal:retry", (e) => {
  if (fromSetup(e)) cfg.mode === "server" ? startServer() : connectClient();
});
ipcMain.handle("portal:reset", (e) => {
  if (fromSetup(e) && cfg.mode !== "server") showSetup({ view: "choose" });
});
app.on("second-instance", showWindow);
app.on("before-quit", () => {
  quitting = true;
  sup?.stop();
  try {
    discoverySocket?.close();
  } catch {
  }
});
app.on("window-all-closed", () => {
  if (!cfg.mode) app.quit();
});
app.on("activate", () => showWindow());
app.whenReady().then(() => {
  loadCfg();
  if (!cfg.mode && process.env.PORTAL_AUTOROLE === "server") cfg.mode = "server";
  Menu.setApplicationMenu(Menu.buildFromTemplate([{ label: "Betriebsportal", submenu: [
    { label: "Neu laden", accelerator: "F5", click: () => win?.webContents.reload() },
    { label: "Gr\xF6\xDFer", accelerator: "CmdOrCtrl+Plus", role: "zoomIn" },
    { label: "Kleiner", accelerator: "CmdOrCtrl+-", role: "zoomOut" },
    { label: "Normale Gr\xF6\xDFe", accelerator: "CmdOrCtrl+0", role: "resetZoom" },
    { type: "separator" },
    { label: "Nach Programm-Update suchen", click: () => checkShellUpdate(true) },
    { label: "Test-Benachrichtigung anzeigen", click: testNotification },
    { label: "Verbindung zum Hauptrechner \xE4ndern \u2026", visible: cfg.mode !== "server", click: () => showSetup({ view: "choose" }) },
    { label: "Fenster schlie\xDFen", accelerator: "CmdOrCtrl+W", click: () => win?.close() },
    { label: "Beenden", accelerator: "CmdOrCtrl+Q", click: quitApp }
  ] }, { role: "editMenu", label: "Bearbeiten" }]));
  createWindow();
  if (cfg.mode) buildTray();
  if (cfg.mode === "server") startServer();
  else if (cfg.mode === "client" && cfg.url) connectClient();
  else showSetup({ view: "choose" });
  setInterval(pollMessages, 4e3);
  if (MAC) {
    try {
      powerSaveBlocker.start("prevent-app-suspension");
    } catch {
    }
  }
  shellLog(`Programm ${EMBEDDED} gestartet (${process.platform}, Rolle ${cfg.mode || "noch nicht gew\xE4hlt"})`);
  setTimeout(() => checkShellUpdate(false), Number(process.env.PORTAL_SHELL_DELAY) || 3e4);
  setInterval(() => checkShellUpdate(false), 6 * 36e5).unref?.();
});
