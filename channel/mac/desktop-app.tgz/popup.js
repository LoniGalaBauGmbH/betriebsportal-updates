'use strict';
const $ = (id) => document.getElementById(id);
let audioCtx = null;
function chime() { // zwei helle Töne
  try {
    const A = window.AudioContext || window.webkitAudioContext; if (!A) return;
    audioCtx = audioCtx || new A();
    if (audioCtx.state === 'suspended') audioCtx.resume();
    const t0 = audioCtx.currentTime;
    [[880, 0], [1174.66, 0.13]].forEach(([freq, at]) => {
      const o = audioCtx.createOscillator(), g = audioCtx.createGain();
      o.type = 'sine'; o.frequency.value = freq;
      g.gain.setValueAtTime(0.0001, t0 + at); g.gain.exponentialRampToValueAtTime(0.25, t0 + at + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, t0 + at + 0.42);
      o.connect(g).connect(audioCtx.destination); o.start(t0 + at); o.stop(t0 + at + 0.45);
    });
  } catch { /* kein Ton möglich */ }
}
portalApp.onPopup((d) => {
  $('title').textContent = d.title; $('body').textContent = d.body;
  $('av').textContent = d.initials || '✉'; $('av').style.background = `hsl(${d.hue} 48% 44%)`;
  $('more').textContent = d.more ? `und ${d.more} weitere ungelesene Nachricht${d.more === 1 ? '' : 'en'}` : 'Klicken zum Öffnen';
  const c = $('card'); c.classList.remove('in'); void c.offsetWidth; c.classList.add('in');
  if (d.sound) chime();
});
$('card').addEventListener('click', (e) => { if (e.target.id === 'x') portalApp.popupClose(); else portalApp.popupClick(); });
