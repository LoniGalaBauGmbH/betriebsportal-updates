'use strict';
const $ = (id) => document.getElementById(id);
portalApp.onPopup((d) => {
  $('title').textContent = d.title; $('body').textContent = d.body;
  $('av').textContent = d.initials || '✉'; $('av').style.background = `hsl(${d.hue} 48% 44%)`;
  $('more').textContent = d.more ? `und ${d.more} weitere ungelesene Nachricht${d.more === 1 ? '' : 'en'}` : 'Klicken zum Öffnen';
  const c = $('card'); c.style.animation = 'none'; void c.offsetWidth; c.style.animation = ''; // Einblenden neu starten
});
$('card').addEventListener('click', (e) => { if (e.target.id === 'x') portalApp.popupClose(); else portalApp.popupClick(); });
