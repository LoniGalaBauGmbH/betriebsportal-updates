'use strict';
// Brücke zwischen Fenster und Programm. Das Hauptprogramm prüft bei jedem Aufruf, von welcher Seite er kommt.
const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('portalApp', {
  // Einrichtungsseite
  state: () => ipcRenderer.invoke('portal:state'),
  discover: () => ipcRenderer.invoke('portal:discover'),
  choose: (c) => ipcRenderer.invoke('portal:choose', c),
  retry: () => ipcRenderer.invoke('portal:retry'),
  reset: () => ipcRenderer.invoke('portal:reset'),
  // Portal: neue Nachricht melden (kleines Fenster am Bildschirmrand) und Ungelesen-Zähler
  message: (m) => ipcRenderer.invoke('portal:message', m),
  unread: (n) => ipcRenderer.send('portal:unread', n),
  // Sicherungsordner am Hauptrechner wählen / öffnen (Explorer bzw. Finder)
  pickFolder: (current) => ipcRenderer.invoke('portal:pickFolder', current),
  openFolder: (p) => ipcRenderer.invoke('portal:openFolder', p),
  // Nachrichten-Fenster
  onPopup: (cb) => ipcRenderer.on('popup:data', (_e, d) => cb(d)),
  popupClick: () => ipcRenderer.send('popup:click'),
  popupClose: () => ipcRenderer.send('popup:close'),
});
