'use strict';
/*
 * Ab Version 1.8.1: Eigener Bereich für die Baustelle.
 * Mitarbeiter mit Arbeitsbereich „Baustelle“ sehen nur: Start, Zeit, Baustellen (Fotos, Mappen, Tagesberichte), Nachrichten, Aufgaben.
 * Die Sperre selbst sitzt auf dem Server – hier wird nur die Oberfläche passend aufgeräumt.
 */
const SITE_NAV = ['', 'zeit', 'projekte', 'kalender', 'nachrichten', 'aufgaben'];
const siteOnly = () => isSite() && S.me.role !== 'admin';

const renderShellBeforeArea = renderShell;
renderShell = function () {
  document.body.classList.toggle('site', siteOnly());
  if (!siteOnly()) return renderShellBeforeArea();
  const all = NAV.splice(0, NAV.length);                                   // Menü nur mit den freigeschalteten Punkten aufbauen
  NAV.push(...SITE_NAV.map((k) => all.find((n) => n[0] === k)).filter(Boolean).map((n) => (n[0] === 'projekte' ? ['projekte', 'Baustellen', n[2]] : n[0] === 'kalender' ? ['kalender', 'Termine', n[2]] : n)));
  try { renderShellBeforeArea(); } finally { NAV.splice(0, NAV.length, ...all); }
  $$('#gsearch,#tsearch').forEach((b) => b.remove());
};
// Gesperrte Seiten führen zurück zum Start; Suche über alles gibt es hier nicht
for (const k of Object.keys(PAGES)) {
  if (SITE_NAV.includes(k) || k === 'stempeln') continue;
  const base = PAGES[k];
  PAGES[k] = (main) => { if (siteOnly()) { location.hash = '#/'; return; } return base(main); };
}
const calendarBeforeArea = PAGES.kalender;
const openSearchBeforeArea = openSearch;
openSearch = function () { if (!siteOnly()) openSearchBeforeArea(); };

/* ---------- Baustellen: Liste und einzelne Baustelle ---------- */
const projectsBeforeArea = PAGES.projekte;
PAGES.projekte = async function (main) {
  if (!siteOnly()) return projectsBeforeArea(main);
  const [, id, tab] = hashParts();
  if (!id) {
    const [projects, home] = await Promise.all([loadProjects(), api('GET', '/api/site/home')]);
    const list = [...home.recent.map((i) => projects.find((p) => p.id === i)).filter(Boolean), ...projects.filter((p) => !home.recent.includes(p.id))];
    main.innerHTML = `<div class="page sitehome"><div class="page-head"><div><h1>Baustellen</h1><p>Fotos, Mappen und Tagesberichte zu jeder Baustelle.</p></div></div>
      <div class="search" style="margin-bottom:14px">${icon('search', 16)}<input type="search" id="q" placeholder="Baustelle suchen …"></div><section class="card"><div class="card-b" id="plist" style="padding-top:10px"></div></section></div>`;
    const paint = (q = '') => { $('#plist').innerHTML = list.filter((p) => !q || [p.name, p.number, p.customer, p.address].join(' ').toLowerCase().includes(q)).map((p) => `<a class="li" href="#/projekte/${p.id}" style="text-decoration:none;color:inherit"><span class="ft">${icon('projects', 18)}</span>
      <div class="t"><b>${esc(p.name)}</b><small>${esc([p.number, p.customer, p.address].filter(Boolean).join(' · '))}</small></div>${home.current === p.id ? '<span class="chip ok">jetzt</span>' : ''}<span class="muted" style="font-size:12.5px;display:inline-flex;gap:4px;align-items:center">${icon('image', 14)}${p.images}</span>${icon('right', 16)}</a>`).join('')
      || `<div class="empty">${icon('projects', 28)}${q ? 'Keine Treffer.' : 'Noch keine aktiven Baustellen.'}</div>`; };
    paint(); $('#q').oninput = (e) => paint(e.target.value.trim().toLowerCase());
    return;
  }
  const data = await api('GET', `/api/projects/${Number(id)}`), p = data.project;
  const t = tab === 'fotos' ? 'fotos' : 'berichte';
  main.innerHTML = `<div class="page pdetail-page" style="max-width:900px"><a class="back" href="#/projekte">${icon('left', 16)}Alle Baustellen</a>
    <div class="page-head"><div><h1>${esc(p.name)}</h1><p><span class="chip">${esc(p.number)}</span>${p.customer ? ` &nbsp;${esc(p.customer)}` : ''}${p.address ? ` · <a href="https://www.openstreetmap.org/search?query=${encodeURIComponent(p.address)}" target="_blank" rel="noopener">${icon('pin', 13)} ${esc(p.address)}</a>` : ''}</p></div></div>
    <nav class="tabs">${[['berichte', 'Tagesberichte & Fotos'], ['fotos', 'Mappen']].map(([k, l]) => `<a href="#/projekte/${p.id}/${k}" class="${t === k ? 'on' : ''}">${l}</a>`).join('')}</nav>
    <div id="xtab"><div class="empty">Wird geladen …</div></div></div>`;
  const openFile = (fid) => { const f = data.files.find((x) => x.id === +fid); if (f) fileViewer(data, f); };
  $('.pdetail-page', main).addEventListener('click', (e) => { const el = e.target.closest('[data-file]'); if (el) { e.preventDefault(); openFile(el.dataset.file); } });
  await PROJECT_TABS[t]($('#xtab', main), data, openFile);
};

/* ---------- Aufgaben: nur die eigenen, zum Abhaken ---------- */
const tasksBeforeArea = PAGES.aufgaben;
PAGES.aufgaben = async function (main) {
  if (!siteOnly()) return tasksBeforeArea(main);
  const tasks = await api('GET', '/api/tasks');
  const open = tasks.filter((t) => t.status !== 'done').sort((a, b) => (a.due || '9').localeCompare(b.due || '9')), done = tasks.filter((t) => t.status === 'done').slice(0, 10);
  const proj = (t) => { const p = t.project_id && (S.projects || []).find((x) => x.id === t.project_id); return p ? p.name : ''; };
  const row = (t) => `<div class="li plain"><button class="circle ${t.status === 'done' ? 'done' : ''}" data-toggle="${t.id}">${icon('check', 13)}</button><div class="t"><b style="white-space:normal;${t.status === 'done' ? 'text-decoration:line-through;color:var(--muted)' : ''}">${esc(t.title)}</b>
    <small style="white-space:normal">${esc([proj(t), t.description].filter(Boolean).join(' · '))}</small></div>${dueChip(t.due, t.status)}</div>`;
  main.innerHTML = `<div class="page sitehome"><div class="page-head"><div><h1>Meine Aufgaben</h1><p>Was für dich ansteht – erledigt? Einfach abhaken.</p></div></div>
    <section class="card"><div class="card-b" style="padding-top:10px">${open.map(row).join('') || `<div class="empty">${icon('check', 28)}Keine offenen Aufgaben.</div>`}</div></section>
    ${done.length ? `<section class="card" style="margin-top:20px"><div class="card-h"><h3>Zuletzt erledigt</h3></div><div class="card-b">${done.map(row).join('')}</div></section>` : ''}</div>`;
  $$('[data-toggle]', main).forEach((b) => b.onclick = guard(async () => { const t = tasks.find((x) => x.id === +b.dataset.toggle); await api('PUT', `/api/tasks/${t.id}`, { status: t.status === 'done' ? 'open' : 'done' }); refresh(); }));
};

// Aufgaben werden hier nur abgehakt, nicht bearbeitet
const taskModalBeforeArea = taskModal;
taskModal = function (...a) { if (!siteOnly()) return taskModalBeforeArea(...a); };

/* ---------- Meine Termine: alles, wofür mich das Büro im Kalender eingetragen hat (nur ansehen) ---------- */
async function myEvents(from, to) {
  const [events, away] = await Promise.all([api('GET', `/api/events?from=${from}&to=${to}`), api('GET', `/api/absences/calendar?from=${from}&to=${to}`).catch(() => [])]);
  for (const a of away) events.push({ id: 'a' + a.id, away: true, kind: 'absence', title: a.title.replace(/:.*$/, ''), date_start: a.date_start, date_end: a.date_end, time_start: null, attendees: [], description: '' });
  const days = {};
  for (const e of events) for (let d = e.date_start < from ? from : e.date_start; d <= e.date_end && d <= to; d = addDays(d, 1)) (days[d] ||= []).push(e);
  for (const d of Object.keys(days)) days[d].sort((a, b) => (a.time_start || '').localeCompare(b.time_start || ''));
  return days;
}
const eventRow = (e) => `<div class="li plain k-${esc(e.kind)}"><span class="dot"></span><div class="t"><b style="white-space:normal">${esc(e.title)}</b>
  <small style="white-space:normal">${e.time_start ? e.time_start + (e.time_end ? '–' + e.time_end : '') + ' Uhr' : 'Ganztägig'}${e.date_start !== e.date_end ? ` · ${dmy(e.date_start).slice(0, 6)} bis ${dmy(e.date_end).slice(0, 6)}` : ''}${e.attendees.length > 1 ? ' · mit ' + e.attendees.filter((id) => id !== S.me.id).map((id) => esc(firstName(userById(id)))).join(', ') : ''}</small>
  ${e.description ? `<small style="white-space:pre-wrap;color:var(--text);margin-top:3px">${esc(e.description)}</small>` : ''}</div></div>`;
const ABSCAL = { vacation: ['Urlaub', 'vac'], sick: ['Krank', 'sick'], other: ['Abwesend', 'oth'], comp: ['Überstunden-Ausgleich', 'oth'] };
PAGES.kalender = async function (main) {
  if (!siteOnly()) return calendarBeforeArea(main);
  if (!S.myCal) { const n = new Date(); S.myCal = new Date(n.getFullYear(), n.getMonth(), 1); }
  const first = S.myCal, t0 = todayStr();
  const start = new Date(first.getFullYear(), first.getMonth(), 1 - ((first.getDay() + 6) % 7));
  const cells = Array.from({ length: 42 }, (_, i) => ymd(new Date(start.getFullYear(), start.getMonth(), start.getDate() + i)));
  const from = cells[0], to = cells[41], monthKey = ymd(first).slice(0, 7);
  const [events, tdays, abs, me] = await Promise.all([api('GET', `/api/events?from=${from}&to=${to}`), api('GET', `/api/time/days?from=${from}&to=${to}`), api('GET', '/api/absences'), api('GET', '/api/time/me')]);
  const info = {};
  for (const d of tdays.days) info[d.date] = { holiday: d.holiday, off: !me.work.workdays.includes(d.weekday) && !d.holiday, events: [], abs: null };   // frei = kein vereinbarter Arbeitstag
  for (const a of abs) if (a.status !== 'rejected') for (let d = a.date_start < from ? from : a.date_start; d <= a.date_end && d <= to; d = addDays(d, 1)) if (info[d]) info[d].abs = a;
  for (const e of events) for (let d = e.date_start < from ? from : e.date_start; d <= e.date_end && d <= to; d = addDays(d, 1)) if (info[d]) info[d].events.push(e);
  for (const d of cells) info[d].events.sort((a, b) => (a.time_start || '').localeCompare(b.time_start || ''));
  if (!S.myCalDay || S.myCalDay.slice(0, 7) !== monthKey) S.myCalDay = t0.slice(0, 7) === monthKey ? t0 : cells.find((d) => d.slice(0, 7) === monthKey && (info[d].events.length || info[d].abs)) || ymd(first);
  const cell = (d) => { const i = info[d], a = i.abs;
    return `<button class="mc ${d.slice(0, 7) !== monthKey ? 'other' : ''} ${d === t0 ? 'today' : ''} ${d === S.myCalDay ? 'sel' : ''} ${i.off ? 'off' : ''} ${i.holiday ? 'hol' : ''} ${a ? 'a-' + ABSCAL[a.type][1] + (a.status === 'pending' ? ' pend' : '') : ''}" data-day="${d}"><span class="n">${+d.slice(8)}</span>
      ${a ? `<span class="tag">${ABSCAL[a.type][0]}${a.half ? ' ½' : ''}</span>` : i.holiday ? '<span class="tag">Feiertag</span>' : ''}
      ${i.events.slice(0, 2).map((e) => `<span class="ev k-${esc(e.kind)}">${e.time_start ? `<em>${e.time_start}</em> ` : ''}${esc(e.title)}</span>`).join('')}${i.events.length > 2 ? `<span class="more">+${i.events.length - 2}</span>` : ''}</button>`; };
  const detail = (d) => { const i = info[d], a = i.abs, rows = [];
    if (i.holiday) rows.push(`<div class="li plain"><span class="ft">${icon('sun', 18)}</span><div class="t"><b>${esc(i.holiday)}</b><small>Feiertag – frei</small></div></div>`);
    if (a) rows.push(`<div class="li plain"><span class="ft ${a.type === 'sick' ? 'late' : a.type === 'vacation' ? 'ok' : 'soon'}">${icon(a.type === 'vacation' ? 'sun' : a.type === 'sick' ? 'plus' : 'cal', 18)}</span><div class="t"><b>${ABSCAL[a.type][0]}${a.half ? ' (halber Tag)' : ''}</b><small style="white-space:normal">${a.date_start === a.date_end ? dmy(a.date_start) : `${dmy(a.date_start)} bis ${dmy(a.date_end)}`}${a.status === 'pending' ? ' · wartet auf Genehmigung' : ''}${a.note ? ' · ' + esc(a.note) : ''}</small></div></div>`);
    rows.push(...i.events.map(eventRow));
    if (!rows.length) rows.push(`<div class="empty" style="padding:18px 10px">${i.off ? 'Frei – kein Arbeitstag.' : 'Für diesen Tag ist nichts eingetragen.'}</div>`);
    return `<div class="card-h"><h3>${d === t0 ? 'Heute, ' : ''}${parseD(d).toLocaleDateString('de-DE', { weekday: 'long', day: 'numeric', month: 'long' })}</h3></div><div class="card-b">${rows.join('')}</div>`; };
  main.innerHTML = `<div class="page sitehome mycal"><div class="page-head"><div><h1>Meine Termine</h1><p>Was das Büro für dich eingetragen hat – dazu Urlaub, Krankheit und freie Tage.</p></div></div>
    <div class="cal-head"><h2>${first.toLocaleDateString('de-DE', { month: 'long', year: 'numeric' })}</h2><span class="sp"></span><button class="icon-btn" id="mprev" aria-label="Vorheriger Monat">${icon('left', 20)}</button><button class="btn sm" id="mnow">Heute</button><button class="icon-btn" id="mnext" aria-label="Nächster Monat">${icon('right', 20)}</button></div>
    <div class="card mcard"><div class="mdow">${['Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa', 'So'].map((x) => `<span>${x}</span>`).join('')}</div><div class="mgrid">${cells.map(cell).join('')}</div></div>
    <div class="mleg"><span><i class="l-ev"></i>Termin</span><span><i class="l-vac"></i>Urlaub</span><span><i class="l-sick"></i>Krank</span><span><i class="l-hol"></i>Feiertag</span><span><i class="l-off"></i>Frei</span></div>
    <section class="card" id="mday" style="margin-top:14px">${detail(S.myCalDay)}</section></div>`;
  $('#mprev').onclick = () => { S.myCal = new Date(first.getFullYear(), first.getMonth() - 1, 1); S.myCalDay = null; refresh(); };
  $('#mnext').onclick = () => { S.myCal = new Date(first.getFullYear(), first.getMonth() + 1, 1); S.myCalDay = null; refresh(); };
  $('#mnow').onclick = () => { S.myCal = null; S.myCalDay = null; refresh(); };
  $$('.mc', main).forEach((c) => c.onclick = () => { S.myCalDay = c.dataset.day; $$('.mc.sel', main).forEach((x) => x.classList.remove('sel')); c.classList.add('sel'); $('#mday').innerHTML = detail(c.dataset.day); });
};
// Startseite: was heute und in den nächsten Tagen ansteht
const homeBeforeArea = PAGES[''];
PAGES[''] = async function (main) {
  await homeBeforeArea(main);
  if (!siteOnly()) return;
  const t0 = todayStr(), days = await myEvents(t0, addDays(t0, 7)).catch(() => ({})), keys = Object.keys(days).sort().slice(0, 3), tiles = $('.tiles', main);
  if (!keys.length || !tiles) return;
  tiles.insertAdjacentHTML('beforebegin', `<section class="card" style="margin-bottom:20px"><div class="card-h"><h3>${keys[0] === t0 ? 'Heute steht an' : 'Demnächst'}</h3><a href="#/kalender">Alle Termine</a></div><div class="card-b">
    ${keys.map((d) => `${d === t0 && keys.length === 1 ? '' : `<div class="daylabel">${d === t0 ? 'Heute' : d === addDays(t0, 1) ? 'Morgen' : fmtShort(d)}</div>`}${days[d].map(eventRow).join('')}`).join('')}</div></section>`);
};
