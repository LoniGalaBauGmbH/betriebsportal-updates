'use strict';
/* Ab Version 1.5: Projekte, Telefonbuch, Suche über alles, Einstellungen (Firma, Sicherung, Updates), Benachrichtigungen. */

Object.assign(ICONS, {
  projects: '<path d="M3.5 8.5a2 2 0 0 1 2-2h13a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2h-13a2 2 0 0 1-2-2Z"/><path d="M9 6.5V5a1.5 1.5 0 0 1 1.5-1.5h3A1.5 1.5 0 0 1 15 5v1.5M3.5 12.5h17"/>',
  book: '<path d="M5 4.5h11.5a2 2 0 0 1 2 2V20H7a2 2 0 0 1-2-2Z"/><path d="M5 17.5a2 2 0 0 1 2-2h11.5M9 8.5h5.5M9 11.5h3.5"/>',
  gear: '<circle cx="12" cy="12" r="3"/><path d="M12 3v2.5M12 18.5V21M3 12h2.5M18.5 12H21M5.6 5.6l1.8 1.8M16.6 16.6l1.8 1.8M5.6 18.4l1.8-1.8M16.6 7.4l1.8-1.8"/>',
  phone: '<path d="M5 4.5h3.2l1.5 4-2 1.3a11 11 0 0 0 6.5 6.5l1.3-2 4 1.5V19a1.5 1.5 0 0 1-1.6 1.5A16 16 0 0 1 3.5 6.100A1.5 1.5 0 0 1 5 4.5Z"/>',
  mail: '<rect x="3.500" y="5.5" width="17" height="13" rx="2.500"/><path d="m4.500 7.500 7.500 5.500 7.500-5.500"/>',
  globe: '<circle cx="12" cy="12" r="8.500"/><path d="M3.500 12h17M12 3.500c2.500 2.700 2.500 14.300 0 17M12 3.500c-2.500 2.700-2.500 14.300 0 17"/>',
  pin: '<path d="M12 21s6.500-5.600 6.500-11a6.500 6.500 0 0 0-13 0c0 5.400 6.500 11 6.500 11Z"/><circle cx="12" cy="10" r="2.300"/>',
  image: '<rect x="3.500" y="4.500" width="17" height="15" rx="2.500"/><circle cx="9" cy="10" r="1.700"/><path d="m4.500 17.500 5-4.500 4 3.500 2.500-2 3.500 3"/>',
  doc: '<path d="M7 3.500h7l4.500 4.500V19a1.500 1.500 0 0 1-1.500 1.500H7A1.500 1.500 0 0 1 5.500 19V5A1.500 1.500 0 0 1 7 3.500Z"/><path d="M14 3.500V8h4.500M9 13h6M9 16.500h4"/>',
  eye: '<path d="M2.500 12S6 5.500 12 5.500 21.500 12 21.500 12 18 18.500 12 18.500 2.500 12 2.500 12Z"/><circle cx="12" cy="12" r="2.800"/>',
  bell: '<path d="M6 16.500V11a6 6 0 0 1 12 0v5.500l1.500 2h-15Z"/><path d="M10 20.500a2 2 0 0 0 4 0"/>',
  shield: '<path d="M12 3.500 5 6v5.500c0 4.300 2.900 7.400 7 9 4.100-1.600 7-4.700 7-9V6Z"/><path d="m9 12 2.200 2.200L15 10"/>',
  link: '<path d="M10 14a4 4 0 0 0 5.700 0l3-3a4 4 0 0 0-5.700-5.700l-1 1"/><path d="M14 10a4 4 0 0 0-5.700 0l-3 3A4 4 0 0 0 11 18.700l1-1"/>',
});
// Navigation: Projekte nach der Übersicht, Telefonbuch vor dem Team, Einstellungen nur für Admins
NAV.splice(1, 0, ['projekte', 'Projekte', 'projects']);
NAV.splice(NAV.findIndex((n) => n[0] === 'team'), 0, ['telefonbuch', 'Telefonbuch', 'book']);
NAV.push(['einstellungen', 'Einstellungen', 'gear', true]);

const hashParts = () => location.hash.replace(/^#\/?/, '').split('/');
const ago = (iso) => {
  const s = (Date.now() - Date.parse(iso)) / 1000;
  if (s < 60) return 'gerade eben';
  if (s < 3600) return `vor ${Math.floor(s / 60)} Min.`;
  if (s < 86400 && ymd(new Date(iso)) === todayStr()) return `vor ${Math.floor(s / 3600)} Std.`;
  if (ymd(new Date(iso)) === addDays(todayStr(), -1)) return 'gestern';
  return new Date(iso).toLocaleDateString('de-DE', { day: 'numeric', month: 'short', year: new Date(iso).getFullYear() === new Date().getFullYear() ? undefined : 'numeric' });
};
const IMG_RE = /\.(jpe?g|png|gif|webp)$/i;
const canPreview = (name) => IMG_RE.test(name) || /\.pdf$/i.test(name);
const CATS = [['delivery', 'Lieferschein', 'Lieferscheine'], ['invoice', 'Rechnung', 'Rechnungen'], ['other', 'Sonstiges', 'Sonstiges']];
const catLabel = (c) => ({ delivery: 'Lieferschein', invoice: 'Rechnung', image: 'Bild', other: 'Sonstiges' }[c] || 'Dokument');
async function uploadTo(file, query) {
  const r = await fetch('/api/files?' + new URLSearchParams({ name: file.name, ...query }), { method: 'POST', headers: { 'Content-Type': 'application/octet-stream' }, body: file });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(data.error || 'Upload fehlgeschlagen');
  return data;
}
const telHref = (t) => 'tel:' + String(t).replace(/[^\d+]/g, '');
const webHref = (w) => (/^https?:\/\//i.test(w) ? w : 'https://' + w);
async function loadProjects() { S.projects = await api('GET', '/api/projects'); return S.projects; }

/* ============ Firma: Name und Logo ============ */
function brandHtml(size = 16) {
  const b = S.brand || {}, name = esc(b.name || 'Betriebsportal');
  return b.logo ? `<div class="brand has-logo"><img src="${esc(b.logo)}" alt=""><span>${name}</span></div>` : `<div class="brand"><i>${icon('check', size)}</i><span>${name}</span></div>`;
}

/* ============ Benachrichtigung mit Ton ============ */
let audioCtx = null;
function chime() {
  try {
    const A = window.AudioContext || window.webkitAudioContext; if (!A) return;
    audioCtx = audioCtx || new A();
    if (audioCtx.state === 'suspended') audioCtx.resume();
    const t0 = audioCtx.currentTime;
    [[880, 0], [1174.66, 0.13]].forEach(([freq, at]) => { // zwei helle Töne
      const o = audioCtx.createOscillator(), g = audioCtx.createGain();
      o.type = 'sine'; o.frequency.value = freq;
      g.gain.setValueAtTime(0.0001, t0 + at); g.gain.exponentialRampToValueAtTime(0.22, t0 + at + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, t0 + at + 0.42);
      o.connect(g).connect(audioCtx.destination); o.start(t0 + at); o.stop(t0 + at + 0.45);
    });
  } catch { /* kein Ton möglich */ }
}
const soundOn = () => { try { return localStorage.getItem('sound') !== 'off'; } catch { return true; } };
function notifyMessage(unread, latest, first) {
  if (!latest) return;
  if (first || latest.id <= (S.lastNotified || 0)) { S.lastNotified = Math.max(S.lastNotified || 0, latest.id); return; }
  S.lastNotified = latest.id;
  // Name kommt vom Server mit – so stimmt er auch für Kollegen, die erst nach dem Programmstart angelegt wurden
  const sender = userById(latest.sender_id) || (latest.sender_name ? { name: latest.sender_name } : null), title = (sender ? sender.name : 'Neue Nachricht') + (latest.conv === 'all' ? ' · an alle' : '');
  const inChat = currentPage() === 'nachrichten' && S.conv === latest.conv; // diese Unterhaltung ist gerade geöffnet
  const inApp = () => { if (inChat) return; if (soundOn()) chime(); toast(`${title}: ${latest.text}`); };
  // Installiertes Programm: Es entscheidet selbst, ob das Fenster gerade zu sehen ist, und zeigt sonst ein kleines Fenster am Bildschirmrand.
  if (window.portalApp && typeof portalApp.message === 'function') {
    Promise.resolve(portalApp.message({ title, body: latest.text, conv: latest.conv, initials: sender ? initials(sender.name) : '', hue: sender ? hue(sender.name) : 220, more: Math.max(0, unread - 1) }))
      .then((shown) => { if (shown) { if (soundOn()) chime(); } else inApp(); }).catch(inApp);
    return;
  }
  // Browser
  if (document.hasFocus()) return inApp();
  if (soundOn()) chime();
  if (window.Notification && Notification.permission === 'granted') {
    const n = new Notification(title, { body: latest.text, icon: (S.brand && S.brand.logo) || undefined, silent: true, tag: 'portal-msg' });
    n.onclick = () => { window.focus(); S.conv = latest.conv; if (currentPage() === 'nachrichten') refresh(); else location.hash = '#/nachrichten'; n.close(); };
  }
}
document.addEventListener('click', () => { // im Browser einmalig um Erlaubnis bitten (im installierten Programm nicht nötig)
  if (S.me && window.Notification && Notification.permission === 'default') Notification.requestPermission().catch(() => {});
}, { once: false, passive: true });

/* ============ Suche über alles (Strg+K) ============ */
function openSearch() {
  if ($('dialog.palette')) return;
  const d = document.createElement('dialog'); d.className = 'modal palette';
  d.innerHTML = `<div class="pal"><div class="pal-in">${icon('search', 20)}<input type="search" id="pq" placeholder="Firma, Stichwort, Person, Projekt, Aufgabe, Datei …" autocomplete="off"><kbd>Esc</kbd></div><div class="pal-res" id="pres"><div class="pal-hint">Tippe mindestens zwei Buchstaben – zum Beispiel ein Stichwort aus dem Telefonbuch.</div></div></div>`;
  document.body.appendChild(d); d.showModal();
  d.addEventListener('close', () => d.remove());
  d.addEventListener('mousedown', (e) => { if (e.target === d) d.close(); });
  const input = $('#pq', d), res = $('#pres', d);
  let timer = null, seq = 0, actions = [];
  const run = async () => {
    const q = input.value.trim(), my = ++seq;
    if (q.length < 2) { res.innerHTML = '<div class="pal-hint">Tippe mindestens zwei Buchstaben – zum Beispiel ein Stichwort aus dem Telefonbuch.</div>'; actions = []; return; }
    const r = await api('GET', '/api/search?q=' + encodeURIComponent(q)).catch(() => null);
    if (my !== seq || !r) return;
    actions = []; let html = '';
    const item = (ico, title, sub, fn, extra = '') => { actions.push(fn); return `<button class="pal-it" data-i="${actions.length - 1}"><span class="ico">${ico}</span><span class="t"><b>${title}</b><small>${sub}</small></span>${extra}</button>`; };
    if (r.contacts.length) html += '<div class="pal-h">Telefonbuch</div>' + r.contacts.map((k) => item(icon('book', 18), esc(k.company),
      esc([k.phone, k.website, k.persons.map((p) => p.name + (p.phone ? ' ' + p.phone : '')).join(', ')].filter(Boolean).join(' · ') || k.keywords), () => contactView(k),
      k.phone ? `<a class="chip accent" href="${esc(telHref(k.phone))}" data-stop>${icon('phone', 13)}${esc(k.phone)}</a>` : '')).join('');
    if (r.projects.length) html += '<div class="pal-h">Projekte</div>' + r.projects.map((p) => item(icon('projects', 18), esc(p.name), esc([p.number, p.customer, p.status === 'done' ? 'abgeschlossen' : 'aktiv'].filter(Boolean).join(' · ')), () => { location.hash = `#/projekte/${p.id}`; })).join('');
    if (r.tasks.length) html += '<div class="pal-h">Aufgaben</div>' + r.tasks.map((t) => item(icon('tasks', 18), esc(t.title), esc((t.status === 'done' ? 'erledigt' : 'offen') + ' · ' + firstName(userById(t.assignee_id))), async () => { taskModal((await api('GET', '/api/tasks')).find((x) => x.id === t.id) || undefined); })).join('');
    if (r.files.length) html += '<div class="pal-h">Dateien</div>' + r.files.map((f) => item(icon('doc', 18), esc(f.name), esc(fmtSize(f.size) + (f.project_id ? ' · im Projekt' : ' · Dateiablage')), () => { if (f.project_id) location.hash = `#/projekte/${f.project_id}/dokumente`; else location.href = `/api/files/${f.id}/download`; })).join('');
    res.innerHTML = html || `<div class="pal-hint">Keine Treffer für „${esc(q)}“.</div>`;
    $$('.pal-it', res).forEach((b) => b.addEventListener('click', (e) => { if (e.target.closest('[data-stop]')) return; d.close(); actions[+b.dataset.i](); }));
  };
  input.addEventListener('input', () => { clearTimeout(timer); timer = setTimeout(run, 140); });
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') { e.preventDefault(); d.close(); }
    if (e.key === 'Enter' && actions.length) { e.preventDefault(); d.close(); actions[0](); }
  });
  input.focus();
}
document.addEventListener('keydown', (e) => { if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k' && S.me) { e.preventDefault(); openSearch(); } });

// Ungelesen-Zähler an das installierte Programm melden (Symbol, Taskleiste, Dock)
const paintBadgeBase = paintBadge;
paintBadge = function () { // eslint-disable-line no-func-assign
  paintBadgeBase();
  try { if (window.portalApp && typeof portalApp.unread === 'function') portalApp.unread(S.unread || 0); } catch { /* egal */ }
};

// Suchfeld und Ton-Schalter in die Seitenleiste einfügen
const renderShellBase = renderShell;
renderShell = function () { // eslint-disable-line no-func-assign
  renderShellBase();
  const brand = $('.side .brand');
  if (brand) brand.insertAdjacentHTML('afterend', `<button class="searchbtn" id="gsearch">${icon('search', 16)}<span>Suchen …</span><kbd>Strg K</kbd></button>`);
  const tb = $('#tb-menu');
  if (tb) tb.insertAdjacentHTML('beforebegin', `<button class="icon-btn" id="tsearch" aria-label="Suchen">${icon('search', 20)}</button>`);
  $$('#gsearch,#tsearch').forEach((b) => b.addEventListener('click', openSearch));
};

/* ============ Telefonbuch ============ */
function contactCardBody(k) {
  return `${k.keywords ? `<div class="kw">${k.keywords.split(/[,;]+/).map((w) => w.trim()).filter(Boolean).map((w) => `<span class="chip">${esc(w)}</span>`).join('')}</div>` : ''}
    <div class="clines">
      ${k.phone ? `<a href="${esc(telHref(k.phone))}">${icon('phone', 15)}${esc(k.phone)}</a>` : ''}
      ${k.email ? `<a href="mailto:${esc(k.email)}">${icon('mail', 15)}${esc(k.email)}</a>` : ''}
      ${k.website ? `<a href="${esc(webHref(k.website))}" target="_blank" rel="noopener">${icon('globe', 15)}${esc(k.website.replace(/^https?:\/\//i, ''))}</a>` : ''}
      ${k.address ? `<span>${icon('pin', 15)}${esc(k.address)}</span>` : ''}
    </div>
    ${k.persons.length ? `<div class="persons">${k.persons.map((p) => `<div class="pers">${avatar({ name: p.name }, 30)}<div class="t"><b>${esc(p.name)}</b><small>${esc(p.role || 'Ansprechperson')}</small></div>
      <div class="pc">${p.phone ? `<a href="${esc(telHref(p.phone))}" title="Durchwahl">${icon('phone', 14)}${esc(p.phone)}</a>` : ''}${p.mobile ? `<a href="${esc(telHref(p.mobile))}" title="Mobil">${icon('phone', 14)}${esc(p.mobile)}</a>` : ''}${p.email ? `<a href="mailto:${esc(p.email)}">${icon('mail', 14)}${esc(p.email)}</a>` : ''}</div></div>`).join('')}</div>` : ''}
    ${k.notes ? `<p class="cnotes">${esc(k.notes)}</p>` : ''}`;
}
function contactView(k) {
  const { d } = modal({ title: k.company, readonly: true, onSubmit: async () => {}, body: `<div class="cview">${contactCardBody(k)}</div>`, extra: `<button type="button" class="btn" id="ced">${icon('edit', 16)}Bearbeiten</button>` });
  $('#ced', d).onclick = () => { d.close(); contactModal(k); };
}
function contactModal(k) {
  const isNew = !k; k = k || { company: '', website: '', phone: '', email: '', address: '', keywords: '', notes: '', persons: [] };
  const personRow = (p = {}) => `<div class="prow"><input type="text" data-p="name" placeholder="Name" value="${esc(p.name || '')}"><input type="text" data-p="role" placeholder="Funktion" value="${esc(p.role || '')}">
    <input type="text" data-p="phone" placeholder="Durchwahl" value="${esc(p.phone || '')}"><input type="text" data-p="mobile" placeholder="Mobil" value="${esc(p.mobile || '')}"><input type="text" data-p="email" placeholder="E-Mail" value="${esc(p.email || '')}">
    <button type="button" class="icon-btn" data-rm aria-label="Entfernen">${icon('x', 16)}</button></div>`;
  const { d } = modal({
    title: isNew ? 'Neuer Kontakt' : 'Kontakt bearbeiten', submit: isNew ? 'Kontakt anlegen' : 'Speichern',
    extra: isNew ? '' : `<button type="button" class="btn danger" id="del">${icon('trash', 16)}Löschen</button>`,
    body: `${field('Firma', `<input type="text" name="company" value="${esc(k.company)}" maxlength="120" placeholder="z. B. WPC Bodenbeläge GmbH">`)}
      <div class="row">${field('Telefon (Zentrale)', `<input type="text" name="phone" value="${esc(k.phone)}">`)}${field('E-Mail', `<input type="text" name="email" value="${esc(k.email)}">`)}</div>
      <div class="row">${field('Webseite', `<input type="text" name="website" value="${esc(k.website)}" placeholder="www.beispiel.de">`)}${field('Adresse', `<input type="text" name="address" value="${esc(k.address)}">`)}</div>
      ${field('Stichwörter für die Suche (mit Komma trennen)', `<input type="text" name="keywords" value="${esc(k.keywords)}" placeholder="z. B. wpc, terrasse, dielen">`)}
      <label class="f"><span>Ansprechpersonen</span><div id="prows">${(k.persons.length ? k.persons : [{}]).map(personRow).join('')}</div><button type="button" class="btn sm" id="padd" style="margin-top:8px">${icon('plus', 14)}Weitere Person</button></label>
      ${field('Notizen', `<textarea name="notes" placeholder="Konditionen, Öffnungszeiten, Besonderheiten …">${esc(k.notes)}</textarea>`)}`,
    onSubmit: async (fd) => {
      const persons = $$('.prow', d).map((r) => Object.fromEntries($$('[data-p]', r).map((i) => [i.dataset.p, i.value])));
      const body = { company: fd.get('company'), phone: fd.get('phone'), email: fd.get('email'), website: fd.get('website'), address: fd.get('address'), keywords: fd.get('keywords'), notes: fd.get('notes'), persons };
      if (isNew) await api('POST', '/api/contacts', body); else await api('PUT', `/api/contacts/${k.id}`, body);
      toast(isNew ? 'Kontakt angelegt' : 'Gespeichert'); refresh();
    },
  });
  d.classList.add('wide');
  $('#padd', d).onclick = () => { $('#prows', d).insertAdjacentHTML('beforeend', personRow()); };
  $('#prows', d).addEventListener('click', (e) => { const b = e.target.closest('[data-rm]'); if (b) b.closest('.prow').remove(); });
  const del = $('#del', d);
  if (del) del.onclick = async () => { if (await confirmBox(`„${k.company}“ wird aus dem Telefonbuch gelöscht.`)) { await guard(() => api('DELETE', `/api/contacts/${k.id}`))(); d.close(); refresh(); } };
}
PAGES.telefonbuch = async function pageContacts(main) {
  const contacts = await api('GET', '/api/contacts');
  main.innerHTML = `<div class="page"><div class="page-head"><div><h1>Telefonbuch</h1><p>Firmen, Ansprechpersonen und Durchwahlen – über Stichwörter sofort zu finden.</p></div>
    <div class="actions"><button class="btn primary" id="new">${icon('plus', 16)}Neuer Kontakt</button></div></div>
    <div class="toolbar"><div class="search" style="width:min(420px,100%)">${icon('search', 16)}<input type="search" id="q" placeholder="Firma, Stichwort, Name, Nummer …" value="${esc(S.contactQ || '')}"></div><span class="muted" id="cnt"></span></div>
    <div class="cgrid" id="cgrid"></div></div>`;
  const paint = () => {
    const q = (S.contactQ || '').toLowerCase().trim();
    const list = contacts.filter((k) => !q || [k.company, k.keywords, k.phone, k.website, k.email, k.notes, ...k.persons.flatMap((p) => [p.name, p.role, p.phone, p.mobile, p.email])].join(' ').toLowerCase().includes(q));
    $('#cnt').textContent = contacts.length ? `${list.length} von ${contacts.length}` : '';
    $('#cgrid').innerHTML = list.map((k) => `<div class="card ccard"><div class="chead"><span class="ft">${esc(initials(k.company))}</span><b>${esc(k.company)}</b><button class="icon-btn" data-edit="${k.id}" aria-label="Bearbeiten">${icon('edit')}</button></div>${contactCardBody(k)}</div>`).join('')
      || `<div class="card empty" style="grid-column:1/-1">${icon('book', 30)}${q ? 'Keine Treffer.' : 'Noch keine Kontakte – lege den ersten an, z. B. einen Lieferanten.'}</div>`;
    $$('[data-edit]').forEach((b) => b.onclick = () => contactModal(contacts.find((k) => k.id === +b.dataset.edit)));
  };
  $('#new').onclick = () => contactModal();
  $('#q').oninput = (e) => { S.contactQ = e.target.value; paint(); };
  paint();
};

/* ============ Projekte ============ */
async function projectModal(p) {
  const isNew = !p; p = p || { name: '', number: '', customer: '', description: '', address: '', start_date: '', end_date: '', lead_id: S.me.id, contact_id: '' };
  const contacts = await api('GET', '/api/contacts');
  const { d } = modal({
    title: isNew ? 'Neues Projekt' : 'Projekt bearbeiten', submit: isNew ? 'Projekt anlegen' : 'Speichern',
    extra: !isNew && S.me.role === 'admin' ? `<button type="button" class="btn danger" id="del">${icon('trash', 16)}Löschen</button>` : '',
    body: `${field('Projektname', `<input type="text" name="name" value="${esc(p.name)}" maxlength="160" placeholder="z. B. Terrasse Familie Meier">`)}
      <div class="row">${field('Kunde / Auftraggeber', `<input type="text" name="customer" value="${esc(p.customer)}">`)}${field('Projektnummer', `<input type="text" name="number" value="${esc(p.number)}" placeholder="${isNew ? 'wird automatisch vergeben' : ''}">`)}</div>
      <div class="row">${field('Projektleitung', `<select name="lead_id">${userOptions(p.lead_id)}</select>`)}${field('Kontakt aus dem Telefonbuch', `<select name="contact_id"><option value="">— Keiner —</option>${options(contacts.map((k) => [k.id, k.company]), p.contact_id)}</select>`)}</div>
      <div class="row">${field('Beginn', `<input type="date" name="start_date" value="${esc(p.start_date || '')}">`)}${field('Geplantes Ende', `<input type="date" name="end_date" value="${esc(p.end_date || '')}">`)}</div>
      ${field('Ort / Baustelle', `<input type="text" name="address" value="${esc(p.address)}">`)}
      ${field('Beschreibung', `<textarea name="description" placeholder="Worum geht es? Besonderheiten, Absprachen …">${esc(p.description)}</textarea>`)}`,
    onSubmit: async (fd) => {
      const body = Object.fromEntries(['name', 'customer', 'number', 'lead_id', 'contact_id', 'start_date', 'end_date', 'address', 'description'].map((k) => [k, fd.get(k)]));
      const saved = isNew ? await api('POST', '/api/projects', body) : await api('PUT', `/api/projects/${p.id}`, body);
      toast(isNew ? 'Projekt angelegt' : 'Gespeichert');
      if (isNew) location.hash = `#/projekte/${saved.id}`; else refresh();
    },
  });
  const del = $('#del', d);
  if (del) del.onclick = async () => { if (await confirmBox(`Das Projekt „${p.name}“ wird mit allen Dokumenten, Bildern und Kommentaren endgültig gelöscht.`)) { await guard(() => api('DELETE', `/api/projects/${p.id}`))(); d.close(); location.hash = '#/projekte'; } };
}
const progress = (p) => (p.tasks_total ? Math.round((p.tasks_done / p.tasks_total) * 100) : null);
const rangeText = (p) => (p.start_date || p.end_date ? `${p.start_date ? fmtShort(p.start_date) : '…'} – ${p.end_date ? fmtShort(p.end_date) : 'offen'}` : '');

async function pageProjectList(main) {
  const projects = await loadProjects();
  S.projTab = S.projTab || 'active';
  main.innerHTML = `<div class="page"><div class="page-head"><div><h1>Projekte</h1><p>Jedes Vorhaben an einem Ort – mit Lieferscheinen, Rechnungen, Bildern, Aufgaben und dem ganzen Verlauf.</p></div>
    <div class="actions"><button class="btn primary" id="new">${icon('plus', 16)}Neues Projekt</button></div></div>
    <div class="toolbar"><div class="seg" id="seg"><button data-t="active">Aktiv (${projects.filter((p) => p.status === 'active').length})</button><button data-t="done">Abgeschlossen (${projects.filter((p) => p.status === 'done').length})</button></div>
      <div class="search">${icon('search', 16)}<input type="search" id="q" placeholder="Projekt, Kunde, Nummer …" value="${esc(S.projQ || '')}"></div></div>
    <div class="pgrid" id="pgrid"></div></div>`;
  const paint = () => {
    $$('#seg button').forEach((b) => b.classList.toggle('on', b.dataset.t === S.projTab));
    const q = (S.projQ || '').toLowerCase().trim();
    const list = projects.filter((p) => p.status === S.projTab && (!q || [p.name, p.customer, p.number, p.address].join(' ').toLowerCase().includes(q)));
    $('#pgrid').innerHTML = list.map((p) => { const pr = progress(p), lead = userById(p.lead_id), late = p.status === 'active' && p.end_date && p.end_date < todayStr();
      return `<a class="card pcard" href="#/projekte/${p.id}"><div class="ptop"><span class="chip">${esc(p.number)}</span>${late ? `<span class="chip late">${icon('alert', 13)}Termin überschritten</span>` : ''}<span class="sp"></span><span class="muted" style="font-size:12.5px">${ago(p.last_activity)}</span></div>
        <h3>${esc(p.name)}</h3><div class="muted pcust">${esc(p.customer || 'Kein Kunde eingetragen')}</div>
        ${pr === null ? '<div class="pprog none">Noch keine Aufgaben</div>' : `<div class="pprog"><div class="bar wide"><i style="width:${pr}%"></i></div><span>${p.tasks_done}/${p.tasks_total} Aufgaben</span></div>`}
        <div class="pmeta"><span title="Dokumente">${icon('doc', 15)}${p.docs}</span><span title="Bilder">${icon('image', 15)}${p.images}</span><span title="Kommentare">${icon('chat', 15)}${p.comments}</span><span class="sp"></span>${rangeText(p) ? `<span class="muted">${rangeText(p)}</span>` : ''}${avatar(lead, 26)}</div></a>`; }).join('')
      || `<div class="card empty" style="grid-column:1/-1">${icon('projects', 30)}${q ? 'Keine Treffer.' : S.projTab === 'active' ? 'Noch kein aktives Projekt – lege das erste an.' : 'Noch keine abgeschlossenen Projekte.'}</div>`;
  };
  $('#new').onclick = guard(() => projectModal());
  $$('#seg button').forEach((b) => b.onclick = () => { S.projTab = b.dataset.t; paint(); });
  $('#q').oninput = (e) => { S.projQ = e.target.value; paint(); };
  paint();
}

/** Großansicht einer Datei: Vorschau links, Kommentare zu genau dieser Datei rechts. */
function fileViewer(ctx, f) {
  const { project, feed } = ctx;
  const d = document.createElement('dialog'); d.className = 'modal viewer';
  const isImg = IMG_RE.test(f.name);
  const mine = () => feed.filter((k) => k.file_id === f.id && k.kind === 'comment').slice().reverse();
  const paintComments = () => {
    const list = mine();
    $('#vfeed', d).innerHTML = list.length ? list.map((k) => { const u = userById(k.user_id);
      return `<div class="fi">${avatar(u, 30)}<div class="fb"><div class="fh"><b>${esc(u ? u.name : 'Gelöscht')}</b><span>${ago(k.created_at)}</span></div><div class="ft2">${esc(k.body)}</div></div></div>`; }).join('')
      : `<div class="empty" style="padding:30px 10px">${icon('chat', 26)}Noch keine Kommentare zu ${isImg ? 'diesem Bild' : 'dieser Datei'}.</div>`;
    $('#vfeed', d).scrollTop = $('#vfeed', d).scrollHeight;
  };
  d.innerHTML = `<div class="vw"><div class="vmain">${isImg ? `<img src="/api/files/${f.id}/view" alt="${esc(f.name)}">` : /\.pdf$/i.test(f.name) ? `<iframe src="/api/files/${f.id}/view" title="${esc(f.name)}"></iframe>`
      : `<div class="empty">${icon('doc', 40)}Für diesen Dateityp gibt es keine Vorschau.<br><a class="btn" style="margin-top:14px" href="/api/files/${f.id}/download">${icon('down', 16)}Herunterladen</a></div>`}</div>
    <aside class="vside"><header><div class="t"><b>${esc(f.name)}</b><small>${catLabel(f.category)} · ${fmtSize(f.size)} · ${esc(userById(f.uploader_id)?.name || '')} · ${ago(f.created_at)}</small></div><button class="icon-btn" data-close aria-label="Schließen">${icon('x')}</button></header>
      <div class="vacts"><a class="btn sm" href="/api/files/${f.id}/download">${icon('down', 14)}Herunterladen</a>
        ${f.category !== 'image' ? `<select id="vcat" class="sm" aria-label="Art">${options(CATS.map((c) => [c[0], c[1]]), f.category)}</select>` : ''}
        <button class="btn sm danger" id="vdel">${icon('trash', 14)}Löschen</button></div>
      <div class="vfeed" id="vfeed"></div>
      <form class="vcomp" id="vcomp"><textarea rows="2" placeholder="Kommentar zu ${isImg ? 'diesem Bild' : 'dieser Datei'} …"></textarea><button class="btn primary sm">Senden</button></form></aside></div>`;
  document.body.appendChild(d); d.showModal();
  d.addEventListener('close', () => { d.remove(); refresh(); });
  d.addEventListener('mousedown', (e) => { if (e.target === d) d.close(); });
  $('[data-close]', d).onclick = () => d.close();
  paintComments();
  const ta = $('textarea', d);
  ta.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); $('#vcomp', d).requestSubmit(); } });
  $('#vcomp', d).addEventListener('submit', guard(async (e) => {
    e.preventDefault(); const body = ta.value.trim(); if (!body) return;
    feed.unshift(await api('POST', `/api/projects/${project.id}/comments`, { body, file_id: f.id })); ta.value = ''; paintComments();
  }));
  if ($('#vcat', d)) $('#vcat', d).onchange = guard(async (e) => { await api('PUT', `/api/files/${f.id}/assign`, { project_id: project.id, category: e.target.value }); f.category = e.target.value; toast('Art geändert'); });
  $('#vdel', d).onclick = async () => { if (await confirmBox(`„${f.name}“ wird endgültig gelöscht.`)) { await guard(() => api('DELETE', `/api/projects/${project.id}/files/${f.id}`))(); d.close(); } };
}

async function pageProjectDetail(main, id, tab) {
  const [data] = await Promise.all([api('GET', `/api/projects/${id}`), loadProjects()]); // Projektliste frisch halten (Auswahl bei Aufgaben)
  const { project: p, files, feed, tasks, contact, can_manage: canManage } = data;
  const docs = files.filter((f) => f.category !== 'image'), images = files.filter((f) => f.category === 'image');
  tab = ['dokumente', 'bilder', 'aufgaben'].includes(tab) ? tab : 'uebersicht';
  const lead = userById(p.lead_id), pr = progress(p);
  const fact = (ico, label, value) => `<div class="fact"><span class="ico">${icon(ico, 18)}</span><div><small>${label}</small><b>${value}</b></div></div>`;
  const fileRowHtml = (f) => `<div class="frow" data-file="${f.id}"><span class="ft">${esc(ext(f.name))}</span><div class="t"><b>${esc(f.name)}</b><small>${catLabel(f.category)} · ${esc(userById(f.uploader_id)?.name || '')} · ${ago(f.created_at)} · ${fmtSize(f.size)}</small></div>
    ${f.comments ? `<span class="chip accent">${icon('chat', 13)}${f.comments}</span>` : ''}<a class="icon-btn" href="/api/files/${f.id}/download" title="Herunterladen" data-stop>${icon('down')}</a></div>`;

  let body = '';
  if (tab === 'uebersicht') {
    body = `<div class="facts">
        ${fact('team', 'Kunde / Auftraggeber', esc(p.customer || '—'))}
        ${fact('book', 'Kontakt', contact ? `<a href="#" id="pcontact">${esc(contact.company)}</a>${contact.phone ? ` · <a href="${esc(telHref(contact.phone))}">${esc(contact.phone)}</a>` : ''}` : '—')}
        ${fact('check', 'Projektleitung', lead ? esc(lead.name) : '—')}
        ${fact('cal', 'Zeitraum', esc(rangeText(p) || '—'))}
        ${fact('pin', 'Ort / Baustelle', esc(p.address || '—'))}
        ${fact('tasks', 'Fortschritt', pr === null ? 'Noch keine Aufgaben' : `${p.tasks_done} von ${p.tasks_total} Aufgaben erledigt (${pr} %)`)}
      </div>
      ${p.description ? `<section class="card"><div class="card-h"><h3>Beschreibung</h3></div><div class="card-b"><p class="pdesc">${esc(p.description)}</p></div></section>` : ''}
      <section class="card"><div class="card-h"><h3>Zuletzt hinzugefügt</h3><a href="#/projekte/${p.id}/dokumente">Alle Dokumente</a></div><div class="card-b">
        ${files.slice(0, 5).map(fileRowHtml).join('') || `<div class="empty">${icon('doc', 28)}Noch keine Dokumente oder Bilder. Lade Lieferscheine, Rechnungen und Fotos hoch – sie bleiben beim Projekt.</div>`}</div></section>`;
  } else if (tab === 'dokumente') {
    S.docCat = S.docCat || 'all';
    const list = docs.filter((f) => S.docCat === 'all' || f.category === S.docCat);
    body = `<div class="toolbar"><div class="seg" id="dseg"><button data-c="all" class="${S.docCat === 'all' ? 'on' : ''}">Alle (${docs.length})</button>${CATS.map((c) => `<button data-c="${c[0]}" class="${S.docCat === c[0] ? 'on' : ''}">${c[2]} (${docs.filter((f) => f.category === c[0]).length})</button>`).join('')}</div></div>
      <div class="drop" id="drop">${icon('upload', 26)}<div><b>Dokumente hierher ziehen</b><br>oder <button class="link" id="pick">Dateien auswählen</button> – werden abgelegt als</div>
        <select id="upcat" style="width:auto">${options(CATS.map((c) => [c[0], c[1]]), S.docCat === 'all' ? 'delivery' : S.docCat)}</select><input type="file" id="fi" multiple hidden></div>
      <section class="card"><div class="card-b" style="padding-top:10px">${list.map(fileRowHtml).join('') || `<div class="empty">${icon('doc', 28)}Hier liegt noch nichts.</div>`}</div></section>`;
  } else if (tab === 'bilder') {
    body = `<div class="drop" id="drop">${icon('image', 26)}<div><b>Bilder hierher ziehen</b><br>oder <button class="link" id="pick">Bilder auswählen</button> – z. B. Fotos vom Baufortschritt</div><input type="file" id="fi" multiple accept="image/*" hidden></div>
      <div class="gallery">${images.map((f) => `<button class="thumb" data-file="${f.id}"><img src="/api/files/${f.id}/view" alt="${esc(f.name)}" loading="lazy">${f.comments ? `<span class="chip accent">${icon('chat', 13)}${f.comments}</span>` : ''}<small>${esc(f.name)}</small></button>`).join('')
        || `<div class="card empty" style="grid-column:1/-1">${icon('image', 28)}Noch keine Bilder. Jedes Bild kann einzeln kommentiert werden.</div>`}</div>`;
  } else {
    body = `<div class="toolbar"><button class="btn primary" id="tnew">${icon('plus', 16)}Aufgabe zum Projekt</button></div>
      <section class="card"><div class="card-b" style="padding-top:10px">${tasks.map((t) => `<div class="li" data-task="${t.id}"><button class="circle ${t.status === 'done' ? 'done' : ''}" data-toggle="${t.id}">${icon('check', 13)}</button>
        <div class="t"><b style="${t.status === 'done' ? 'text-decoration:line-through;color:var(--muted)' : ''}">${esc(t.title)}</b><small>${esc(firstName(userById(t.assignee_id)))}${t.status === 'progress' ? ' · in Arbeit' : ''}</small></div>${dueChip(t.due, t.status)}</div>`).join('')
        || `<div class="empty">${icon('tasks', 28)}Noch keine Aufgaben zu diesem Projekt.</div>`}</div></section>`;
  }

  const feedHtml = () => feed.map((k) => { const u = userById(k.user_id);
    if (k.kind === 'event') return `<div class="fe"><span class="dotline"></span><span><b>${esc(u ? firstName(u) : 'Jemand')}</b> ${esc(k.body)}</span><time>${ago(k.created_at)}</time></div>`;
    return `<div class="fi">${avatar(u, 30)}<div class="fb"><div class="fh"><b>${esc(u ? u.name : 'Gelöscht')}</b><span>${ago(k.created_at)}</span>${k.user_id === S.me.id || S.me.role === 'admin' ? `<button class="icon-btn mini" data-delc="${k.id}" title="Kommentar löschen">${icon('x', 13)}</button>` : ''}</div>
      ${k.file_id && k.file_name ? `<button class="fref" data-file="${k.file_id}">${icon(k.file_category === 'image' ? 'image' : 'doc', 13)}${esc(k.file_name)}</button>` : ''}<div class="ft2">${esc(k.body)}</div></div></div>`; }).join('');

  main.innerHTML = `<div class="page pdetail-page"><a class="back" href="#/projekte">${icon('left', 16)}Alle Projekte</a>
    <div class="page-head"><div><h1>${esc(p.name)}</h1><p><span class="chip">${esc(p.number)}</span> <span class="chip ${p.status === 'done' ? 'ok' : 'accent'}">${p.status === 'done' ? 'Abgeschlossen' : 'Aktiv'}</span>${p.customer ? ` &nbsp;${esc(p.customer)}` : ''}</p></div>
      ${canManage ? `<div class="actions"><button class="btn" id="pedit">${icon('edit', 16)}Bearbeiten</button>${p.status === 'active' ? `<button class="btn primary" id="pdone">${icon('check', 16)}Projekt abschließen</button>` : `<button class="btn" id="popen">Wieder öffnen</button>`}</div>` : ''}</div>
    <div class="pdetail"><div class="pmain">
      <nav class="tabs">${[['uebersicht', 'Übersicht', ''], ['dokumente', 'Dokumente', docs.length], ['bilder', 'Bilder', images.length], ['aufgaben', 'Aufgaben', tasks.length]].map(([k, l, n]) => `<a href="#/projekte/${p.id}/${k}" class="${tab === k ? 'on' : ''}">${l}${n !== '' ? `<span>${n}</span>` : ''}</a>`).join('')}</nav>
      ${body}</div>
    <aside class="card pfeed"><div class="card-h"><h3>Verlauf &amp; Kommentare</h3></div>
      <form class="vcomp" id="pcomp"><textarea rows="2" placeholder="Kommentar zum Projekt schreiben …"></textarea><button class="btn primary sm">Senden</button></form>
      <div class="feed" id="feed">${feedHtml()}</div></aside></div></div>`;

  const openFile = (fid) => { const f = files.find((x) => x.id === +fid); if (f) fileViewer(data, f); };
  // Wichtig: am Seiteninhalt anmelden (wird bei jedem Aufbau neu erzeugt), nicht am dauerhaften Rahmen
  $('.pdetail-page', main).addEventListener('click', (e) => { if (e.target.closest('[data-stop]')) return; const el = e.target.closest('[data-file]'); if (el) { e.preventDefault(); openFile(el.dataset.file); } });
  if ($('#pedit')) $('#pedit').onclick = guard(() => projectModal(p));
  if ($('#pdone')) $('#pdone').onclick = guard(async () => { const open = p.tasks_total - p.tasks_done;
    if (await confirmBox(open ? `Es sind noch ${open} Aufgabe(n) offen. Projekt trotzdem abschließen?` : 'Das Projekt wird als abgeschlossen markiert. Du kannst es jederzeit wieder öffnen.', 'Abschließen')) { await api('PUT', `/api/projects/${p.id}`, { status: 'done' }); toast('Projekt abgeschlossen'); refresh(); } });
  if ($('#popen')) $('#popen').onclick = guard(async () => { await api('PUT', `/api/projects/${p.id}`, { status: 'active' }); refresh(); });
  if ($('#pcontact')) $('#pcontact').onclick = (e) => { e.preventDefault(); contactView(contact); };
  const pta = $('#pcomp textarea');
  pta.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); $('#pcomp').requestSubmit(); } });
  $('#pcomp').addEventListener('submit', guard(async (e) => { e.preventDefault(); const b = pta.value.trim(); if (!b) return; await api('POST', `/api/projects/${p.id}/comments`, { body: b }); refresh(); }));
  $('#feed').addEventListener('click', guard(async (e) => { const b = e.target.closest('[data-delc]'); if (!b) return; e.stopPropagation(); await api('DELETE', `/api/projects/${p.id}/comments/${b.dataset.delc}`); refresh(); }));
  // Hochladen (Dokumente / Bilder)
  const drop = $('#drop');
  if (drop) {
    const send = guard(async (list) => {
      for (const f of list) {
        const category = tab === 'bilder' ? 'image' : IMG_RE.test(f.name) && $('#upcat').value === 'other' ? 'other' : $('#upcat').value;
        toast(`„${f.name}“ wird hochgeladen …`);
        await uploadTo(f, { ctx: 'project', project_id: p.id, category });
      }
      toast('Hochgeladen'); refresh();
    });
    $('#pick').onclick = (e) => { e.preventDefault(); $('#fi').click(); };
    $('#fi').onchange = (e) => { send([...e.target.files]); };
    ['dragenter', 'dragover'].forEach((n) => drop.addEventListener(n, (e) => { e.preventDefault(); drop.classList.add('over'); }));
    ['dragleave', 'drop'].forEach((n) => drop.addEventListener(n, (e) => { e.preventDefault(); drop.classList.remove('over'); }));
    drop.addEventListener('drop', (e) => send([...e.dataTransfer.files]));
  }
  $$('#dseg button').forEach((b) => b.onclick = () => { S.docCat = b.dataset.c; refresh(); });
  if ($('#tnew')) $('#tnew').onclick = () => taskModal(undefined, { project_id: p.id });
  $$('[data-task]', main).forEach((el) => el.addEventListener('click', (e) => { if (e.target.closest('[data-toggle]')) return; taskModal(tasks.find((t) => t.id === +el.dataset.task)); }));
  $$('[data-toggle]', main).forEach((b) => b.addEventListener('click', guard(async () => { const t = tasks.find((x) => x.id === +b.dataset.toggle); await api('PUT', `/api/tasks/${t.id}`, { status: t.status === 'done' ? 'open' : 'done' }); refresh(); })));
  // Verlauf aktuell halten, solange niemand tippt oder ein Dialog offen ist
  const lastId = feed.length ? feed[0].id : 0;
  const timer = setInterval(async () => {
    if ($('dialog[open]') || pta.value.trim()) return;
    const fresh = await api('GET', `/api/projects/${p.id}`).catch(() => null);
    if (fresh && (fresh.feed[0]?.id || 0) !== lastId) refresh();
  }, 7000);
  S.cleanup.push(() => clearInterval(timer));
}
PAGES.projekte = (main) => { const [, id, tab] = hashParts(); return id ? pageProjectDetail(main, Number(id), tab) : pageProjectList(main); };

/** Datei aus der allgemeinen Ablage einem Projekt zuordnen (z. B. ein Beleg). */
async function assignModal(file, done) {
  const projects = (await loadProjects()).filter((p) => p.status === 'active');
  if (!projects.length) { toast('Es gibt noch kein aktives Projekt', true); return; }
  modal({
    title: 'Projekt zuordnen', submit: 'Zuordnen',
    body: `<p class="muted" style="margin:0 0 14px">„${esc(file.name)}“ wird aus der allgemeinen Ablage in das Projekt verschoben.</p>
      ${field('Projekt', `<select name="project_id">${options(projects.map((p) => [p.id, `${p.number} · ${p.name}`]), '')}</select>`)}
      ${field('Art', `<select name="category">${options([...CATS.map((c) => [c[0], c[1]]), ['image', 'Bild']], IMG_RE.test(file.name) ? 'image' : 'invoice')}</select>`)}`,
    onSubmit: async (fd) => { await api('PUT', `/api/files/${file.id}/assign`, { project_id: Number(fd.get('project_id')), category: fd.get('category') }); toast('Zugeordnet'); done(); },
  });
}

/* ============ Einstellungen (nur Administratoren) ============ */
PAGES.einstellungen = async function pageSettings(main) {
  if (S.me.role !== 'admin') { location.hash = '#/'; return; }
  const [backup, upd] = await Promise.all([api('GET', '/api/admin/backup'), api('GET', '/api/admin/update')]);
  const b = S.brand || {};
  const lastB = backup.last;
  // Ordner-Auswahl über Explorer/Finder: nur im installierten Programm direkt am Hauptrechner (der Pfad gilt für diesen Computer)
  const canPick = !!(window.portalApp && typeof portalApp.pickFolder === 'function') && ['localhost', '127.0.0.1'].includes(location.hostname);
  main.innerHTML = `<div class="page" style="max-width:860px"><div class="page-head"><div><h1>Einstellungen</h1><p>Firma, Sicherung und Software-Updates.</p></div></div>
    <section class="card set"><div class="set-h"><span class="ico">${icon('image', 20)}</span><div><h3>Firma</h3><p class="muted">Name und Logo erscheinen in der Seitenleiste und auf dem Anmeldebildschirm.</p></div></div>
      <div class="set-b"><div class="logo-row"><div class="logo-prev">${b.logo ? `<img src="${esc(b.logo)}" alt="Logo">` : icon('image', 28)}</div>
        <div><button class="btn" id="logoup">${icon('upload', 16)}Logo hochladen</button> ${b.logo ? `<button class="btn danger" id="logorm">Entfernen</button>` : ''}<input type="file" id="logofi" accept="image/png,image/jpeg,image/gif,image/webp" hidden>
        <p class="muted" style="margin:8px 0 0;font-size:13px">PNG, JPG, GIF oder WebP, bis 3 MB. Am besten mit transparentem Hintergrund.</p></div></div>
        <form class="row" id="namef" style="align-items:flex-end;margin-top:16px">${field('Firmenname', `<input type="text" name="name" value="${esc(b.name || '')}" maxlength="80" placeholder="z. B. Muster GmbH">`)}<button class="btn primary" style="flex:none;margin-bottom:14px">Speichern</button></form></div></section>

    <section class="card set"><div class="set-h"><span class="ico">${icon('shield', 20)}</span><div><h3>Sicherung</h3><p class="muted">Jede Stunde wird automatisch eine Kopie aller Daten und Dateien abgelegt.</p></div>
        <label class="check"><input type="checkbox" id="bon" ${backup.enabled ? 'checked' : ''}>Eingeschaltet</label></div>
      <div class="set-b"><div class="notice ${!lastB ? '' : lastB.ok ? 'ok' : 'bad'}">${!lastB ? 'Es wurde noch keine Sicherung erstellt.' : lastB.ok
          ? `Letzte Sicherung: <b>${new Date(lastB.at).toLocaleString('de-DE', { dateStyle: 'medium', timeStyle: 'short' })}</b> · ${lastB.snapshots} Stände vorhanden`
          : `Die letzte Sicherung ist fehlgeschlagen (${new Date(lastB.at).toLocaleString('de-DE', { dateStyle: 'medium', timeStyle: 'short' })}): ${esc(lastB.error || '')}`}</div>
        <form id="bf"><label class="f"><span>Ordner für die Sicherung</span><span class="dirrow"><input type="text" name="dir" value="${esc(backup.dir)}" spellcheck="false" ${canPick ? 'readonly title="Klicken, um einen Ordner auszuwählen"' : ''}>
          ${canPick ? `<button type="button" class="btn" id="bpick">${icon('folder', 16)}Ordner wählen …</button><button type="button" class="btn" id="bopen">Ordner öffnen</button>` : ''}</span></label>
          <p class="muted" style="margin:-6px 0 14px;font-size:13px">Tipp: Wähle einen Ordner, der <b>nicht</b> auf derselben Festplatte liegt – z. B. den Ordner deines Cloud-Speichers (OneDrive, Dropbox, Google Drive), ein Netzlaufwerk oder eine USB-Festplatte. Der Pfad gilt für den Hauptrechner.</p>
          <div class="row" style="align-items:flex-end">${field('Stände aufbewahren (stündlich)', `<input type="text" name="keep" value="${backup.keep}" inputmode="numeric" style="max-width:120px">`)}
            <span style="flex:none;display:flex;gap:10px;margin-bottom:14px"><button type="button" class="btn" id="brun">Jetzt sichern</button><button class="btn primary">Speichern</button></span></div></form></div></section>

    <section class="card set"><div class="set-h"><span class="ico">${icon('down', 20)}</span><div><h3>Software-Updates</h3><p class="muted">Installiert ist <b>Version ${esc(upd.version)}</b>. ${
        !upd.supervised ? 'Updates gibt es nur im installierten Programm.' : upd.pending ? `<b style="color:var(--accent)">Version ${esc(upd.pending)} liegt bereit.</b>`
        : !upd.last ? 'Es wurde noch nicht nach Updates gesucht.' : !upd.last.configured ? 'Für diese Installation ist keine Update-Adresse hinterlegt.'
        : upd.last.ok ? `Das Programm ist aktuell (zuletzt geprüft ${ago(upd.last.at)}).` : `Die letzte Suche ist fehlgeschlagen: ${esc(upd.last.error || '')}`}</p></div></div>
      ${upd.supervised ? `<div class="set-b"><div class="row" style="align-items:center"><label class="check" style="flex:1"><input type="checkbox" id="updauto" ${upd.mode === 'auto' ? 'checked' : ''}>Updates nachts automatisch installieren <span class="muted">(sonst nur nach Klick auf „Jetzt installieren“)</span></label>
        <span style="flex:none">${upd.pending ? `<button class="btn primary" id="updnow">Jetzt installieren</button>` : `<button class="btn" id="updcheck">Jetzt nach Updates suchen</button>`}</span></div></div>` : ''}</section></div>`;

  const reloadBrand = async () => { S.brand = await api('GET', '/api/branding'); renderShell(); paintBadge(); route(); };
  $('#logoup').onclick = () => $('#logofi').click();
  $('#logofi').onchange = guard(async (e) => {
    const f = e.target.files[0]; if (!f) return;
    const r = await fetch('/api/admin/logo', { method: 'POST', headers: { 'Content-Type': 'application/octet-stream' }, body: f });
    const j = await r.json().catch(() => ({})); if (!r.ok) throw new Error(j.error || 'Upload fehlgeschlagen');
    toast('Logo gespeichert'); await reloadBrand();
  });
  if ($('#logorm')) $('#logorm').onclick = guard(async () => { await api('DELETE', '/api/admin/logo'); await reloadBrand(); });
  $('#namef').addEventListener('submit', guard(async (e) => { e.preventDefault(); await api('PUT', '/api/admin/branding', { name: new FormData(e.target).get('name') }); toast('Gespeichert'); await reloadBrand(); }));
  if (canPick) {
    const dirInput = $('#bf [name=dir]');
    const pick = guard(async () => {
      const p = await portalApp.pickFolder(dirInput.value); if (!p) return;
      dirInput.value = p;
      await api('PUT', '/api/admin/backup', { dir: p, keep: Number(new FormData($('#bf')).get('keep')) });
      toast('Sicherungsordner gespeichert'); refresh();
    });
    $('#bpick').onclick = pick; dirInput.onclick = pick;
    $('#bopen').onclick = guard(async () => { if (!(await portalApp.openFolder(dirInput.value))) toast('Der Ordner existiert noch nicht – er wird bei der ersten Sicherung angelegt', true); });
  }
  $('#bon').onchange = guard(async (e) => { await api('PUT', '/api/admin/backup', { enabled: e.target.checked }); toast(e.target.checked ? 'Sicherung eingeschaltet' : 'Sicherung ausgeschaltet'); });
  $('#bf').addEventListener('submit', guard(async (e) => { e.preventDefault(); const fd = new FormData(e.target); await api('PUT', '/api/admin/backup', { dir: fd.get('dir'), keep: Number(fd.get('keep')) }); toast('Gespeichert'); refresh(); }));
  $('#brun').onclick = guard(async () => { const btn = $('#brun'); btn.disabled = true; btn.textContent = 'Sichere …';
    const fd = new FormData($('#bf')); await api('PUT', '/api/admin/backup', { dir: fd.get('dir'), keep: Number(fd.get('keep')) });
    const r = await api('POST', '/api/admin/backup/run'); toast(r.last && r.last.ok ? 'Sicherung erstellt' : 'Sicherung fehlgeschlagen', !(r.last && r.last.ok)); refresh(); });
  if ($('#updauto')) {
    $('#updauto').onchange = guard(async (e) => { await api('PUT', '/api/admin/update', { mode: e.target.checked ? 'auto' : 'manual' }); toast(e.target.checked ? 'Updates werden nachts automatisch installiert' : 'Updates werden nur noch per Klick installiert'); });
    if ($('#updcheck')) $('#updcheck').onclick = guard(async () => { const btn = $('#updcheck'); btn.disabled = true; btn.textContent = 'Suche läuft …';
      try { const r = await api('POST', '/api/update/check'); toast(r.pending ? `Version ${r.pending} gefunden` : r.last?.ok === false ? 'Suche fehlgeschlagen' : 'Das Programm ist aktuell', r.last?.ok === false); } finally { pollSummary(); refresh(); } });
    if ($('#updnow')) $('#updnow').onclick = guard(async () => { $('#updnow').disabled = true; await api('POST', '/api/update/apply'); toast('Update wird installiert …'); setTimeout(() => location.reload(), 4000); });
  }
};

/* ============ Übersicht: aktive Projekte ============ */
const dashboardBase = PAGES[''];
PAGES[''] = async function (main) {
  await dashboardBase(main);
  const projects = (await loadProjects().catch(() => [])).filter((p) => p.status === 'active').slice(0, 5);
  const stack = $('.grid2 .stack', main); if (!stack) return;
  stack.insertAdjacentHTML('beforeend', `<section class="card"><div class="card-h"><h3>Aktive Projekte</h3><a href="#/projekte">Alle Projekte</a></div><div class="card-b">
    ${projects.map((p) => { const pr = progress(p); return `<a class="li" href="#/projekte/${p.id}" style="text-decoration:none;color:inherit"><span class="ft">${icon('projects', 18)}</span><div class="t"><b>${esc(p.name)}</b><small>${esc([p.number, p.customer].filter(Boolean).join(' · '))}</small></div>
      ${pr === null ? '' : `<span class="muted" style="font-size:13px">${pr} %</span><span class="bar"><i style="width:${pr}%"></i></span>`}</a>`; }).join('') || `<div class="empty">${icon('projects', 28)}Noch keine Projekte.</div>`}</div></section>`);
};
