'use strict';
/* Ab Version 1.8: Baustelle – eigene Startseite, Foto-Dokumentation mit Mappen, Tagesberichte, Zeiten je Projekt. */

Object.assign(ICONS, {
  camera: '<path d="M4 8.500A1.500 1.500 0 0 1 5.500 7h2l1.500-2.500h6L16.500 7h2A1.500 1.500 0 0 1 20 8.500v9a1.500 1.500 0 0 1-1.500 1.500h-13A1.500 1.500 0 0 1 4 17.500Z"/><circle cx="12" cy="13" r="3.500"/>',
  report: '<path d="M7 3.500h10A1.500 1.500 0 0 1 18.500 5v14a1.500 1.500 0 0 1-1.500 1.500H7A1.500 1.500 0 0 1 5.500 19V5A1.500 1.500 0 0 1 7 3.500Z"/><path d="M9 8h6M9 11.500h6M9 15h3.500"/>',
  w_sun: '<circle cx="12" cy="12" r="4"/><path d="M12 3v2M12 19v2M3 12h2M19 12h2M5.600 5.600 7 7M17 17l1.400 1.400M5.600 18.400 7 17M17 7l1.400-1.400"/>',
  w_partly: '<circle cx="8.500" cy="9" r="3"/><path d="M8.500 3.500v1M3 9h1M4.600 5.100l.700.700M9.500 19h8a3 3 0 0 0 .300-6 4.500 4.500 0 0 0-8.600 1.200A2.500 2.500 0 0 0 9.500 19Z"/>',
  w_cloud: '<path d="M7 18.500a4 4 0 0 1-.600-7.950 5.500 5.500 0 0 1 10.700 1.200A3.400 3.400 0 0 1 17 18.500Z"/>',
  w_storm: '<path d="M7 16a4 4 0 0 1-.600-7.950 5.500 5.500 0 0 1 10.700 1.200A3.400 3.400 0 0 1 17 16"/><path d="m12.500 13-2.500 4h3.500l-2 4"/>',
  w_rain: '<path d="M7 15.500a4 4 0 0 1-.600-7.950 5.500 5.500 0 0 1 10.700 1.200A3.400 3.400 0 0 1 17 15.500Z"/><path d="M8.500 18.500l-.700 2M12.300 18.500l-.700 2M16 18.500l-.700 2"/>',
  w_snow: '<path d="M7 15.500a4 4 0 0 1-.600-7.950 5.500 5.500 0 0 1 10.700 1.200A3.400 3.400 0 0 1 17 15.500Z"/><path d="M8.500 19v.100M12 20.500v.100M15.500 19v.100"/>',
});
const WEATHER = [['sun', 'Sonne'], ['partly', 'Heiter'], ['cloud', 'Bewölkt'], ['storm', 'Gewitter'], ['rain', 'Regen'], ['snow', 'Schnee']];
const isSite = () => S.me && S.me.kind === 'site';
const dayLabel = (d) => (d === todayStr() ? 'Heute' : d === addDays(todayStr(), -1) ? 'Gestern' : parseD(d).toLocaleDateString('de-DE', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }));
const takenAt = (f) => f.taken_at || f.created_at;
const mapUrl = (f) => `https://www.openstreetmap.org/?mlat=${f.lat}&mlon=${f.lng}#map=18/${f.lat}/${f.lng}`;
const decimal = (s) => Number(String(s || '').replace(',', '.')) || 0;
const fmtH = (n) => n.toFixed(2).replace('.', ',');

/* ---------- Baustellen-Mitarbeiter: Navigation für das Handy sortieren ---------- */
const renderShellBeforeSite = renderShell;
renderShell = function () {
  if (isSite()) { const order = ['', 'zeit', 'projekte', 'nachrichten', 'aufgaben', 'kalender', 'dateien', 'telefonbuch', 'team']; NAV.sort((a, b) => (order.indexOf(a[0]) + 100) % 100 - (order.indexOf(b[0]) + 100) % 100 || 0); }
  renderShellBeforeSite();
};

/* ---------- Foto aufnehmen / hochladen ---------- */
/** Große Handy-Fotos vor dem Hochladen verkleinern (spart Zeit und Datenvolumen auf der Baustelle). */
async function shrinkImage(file, max = 2400) {
  if (!/^image\/(jpeg|png|webp)$/.test(file.type) || file.size < 900 * 1024) return file;
  try {
    const bmp = await createImageBitmap(file, { imageOrientation: 'from-image' });
    const k = Math.min(1, max / Math.max(bmp.width, bmp.height));
    const cv = Object.assign(document.createElement('canvas'), { width: Math.round(bmp.width * k), height: Math.round(bmp.height * k) });
    cv.getContext('2d').drawImage(bmp, 0, 0, cv.width, cv.height);
    const blob = await new Promise((r) => cv.toBlob(r, 'image/jpeg', 0.85));
    if (!blob || blob.size >= file.size) return file;
    return new File([blob], file.name.replace(/\.[a-z0-9]+$/i, '') + '.jpg', { type: 'image/jpeg', lastModified: file.lastModified });
  } catch { return file; }
}
const getPosition = () => new Promise((res) => {
  if (!navigator.geolocation || !window.isSecureContext) return res(null);
  navigator.geolocation.getCurrentPosition((p) => res({ lat: p.coords.latitude.toFixed(6), lng: p.coords.longitude.toFixed(6) }), () => res(null), { enableHighAccuracy: true, timeout: 8000, maximumAge: 60000 });
});
/** Dialog nach der Aufnahme: Beschreibung, Mappe, Standort – dann hochladen. */
function photoDialog(files, project, folders, folderId, done = refresh) {
  files = [...files]; if (!files.length) return;
  const imgs = files.filter((f) => f.type.startsWith('image/'));
  const urls = imgs.slice(0, 6).map((f) => URL.createObjectURL(f));
  const canGeo = !!navigator.geolocation && window.isSecureContext;
  const { d } = modal({
    title: `${files.length === 1 ? (imgs.length ? 'Foto' : 'Datei') : files.length + ' Dateien'} – ${project.name}`, submit: 'Hochladen',
    body: `${urls.length ? `<div class="pprev">${urls.map((u) => `<img src="${u}" alt="">`).join('')}${imgs.length > 6 ? `<span>+${imgs.length - 6}</span>` : ''}</div>` : ''}
      ${field('Was wurde gemacht? (Beschreibung)', '<textarea name="note" maxlength="2000" placeholder="z. B. Graben ausgehoben, Leitung verlegt, Asphalt eingebaut …" style="min-height:84px"></textarea>')}
      ${field('Mappe', `<select name="folder"><option value="">— Ohne Mappe —</option>${options(folders.map((f) => [f.id, f.name]), folderId || (folders[0] && imgs.length ? folders[0].id : ''))}</select>`)}
      <label class="check"><input type="checkbox" name="geo" ${canGeo ? 'checked' : 'disabled'}>Standort mitspeichern${canGeo ? '' : ' <span class="muted">(nur über die sichere Adresse des Portals möglich)</span>'}</label>
      <p class="muted" style="font-size:12.5px;margin:10px 0 0">Datum, Uhrzeit und dein Name werden automatisch festgehalten.</p>`,
    onSubmit: async (fd) => {
      const pos = fd.get('geo') ? await getPosition() : null;
      let n = 0;
      for (const raw of files) {
        toast(`Lade hoch … ${++n} von ${files.length}`);
        const f = await shrinkImage(raw), isImg = IMG_RE.test(f.name);
        await uploadTo(f, { ctx: 'project', project_id: project.id, category: isImg ? 'image' : 'other', note: fd.get('note') || '', folder: fd.get('folder') || '', taken: new Date(raw.lastModified || Date.now()).toISOString(), ...(pos && isImg ? pos : {}) });
      }
      toast(files.length === 1 ? 'Gespeichert' : `${files.length} Dateien gespeichert`); done();
    },
  });
  d.addEventListener('close', () => urls.forEach((u) => URL.revokeObjectURL(u)));
}
/** Kamera bzw. Dateiauswahl öffnen. */
function pickPhotos(camera, cb) {
  const inp = Object.assign(document.createElement('input'), { type: 'file', multiple: !camera });
  inp.accept = camera ? 'image/*' : ''; if (camera) inp.capture = 'environment';
  inp.onchange = () => { if (inp.files.length) cb(inp.files); };
  inp.click();
}
/** Projekt auswählen (für Foto oder Tagesbericht von der Startseite aus). */
function chooseProject(title, preferred = []) {
  return new Promise((res) => {
    const active = (S.projects || []).filter((p) => p.status === 'active');
    const list = [...preferred.map((id) => active.find((p) => p.id === id)).filter(Boolean), ...active.filter((p) => !preferred.includes(p.id))];
    if (!list.length) { toast('Es gibt noch kein aktives Projekt', true); return res(null); }
    let picked = null;
    const { d } = modal({ title, readonly: true, body: `<div class="search" style="margin-bottom:10px">${icon('search', 16)}<input type="search" id="cpq" placeholder="Baustelle suchen …"></div><div id="cpl" style="max-height:52vh;overflow:auto"></div>` });
    const paint = (q = '') => { $('#cpl', d).innerHTML = list.filter((p) => !q || (p.name + p.number + (p.customer || '')).toLowerCase().includes(q)).map((p) => `<div class="li" data-p="${p.id}"><span class="ft">${icon('projects', 18)}</span><div class="t"><b>${esc(p.name)}</b><small>${esc([p.number, p.customer, p.address].filter(Boolean).join(' · '))}</small></div>${icon('right', 16)}</div>`).join('') || '<div class="empty">Keine Treffer.</div>'; };
    paint();
    $('#cpq', d).oninput = (e) => paint(e.target.value.trim().toLowerCase());
    $('#cpl', d).addEventListener('click', (e) => { const el = e.target.closest('[data-p]'); if (el) { picked = list.find((p) => p.id === +el.dataset.p); d.close(); } });
    d.addEventListener('close', () => res(picked));
  });
}

/* ---------- Projekt: Fotos & Mappen ---------- */
PROJECT_TABS.fotos = async function (el, data, openFile) {
  const p = data.project, site = await api('GET', `/api/projects/${p.id}/site`);
  S.folderSel ||= {};
  let sel = S.folderSel[p.id] ?? 'photos';
  if (typeof sel === 'number' && !site.folders.some((f) => f.id === sel)) sel = 'photos';
  const files = site.files, images = files.filter((f) => f.category === 'image');
  const list = sel === 'photos' ? images : sel === 'none' ? files.filter((f) => !f.folder_id && f.category === 'image') : files.filter((f) => f.folder_id === sel);
  const folder = typeof sel === 'number' ? site.folders.find((f) => f.id === sel) : null;
  const groups = {};
  for (const f of list) (groups[ymd(new Date(takenAt(f)))] ||= []).push(f);
  const card = (f) => (f.category === 'image'
    ? `<button class="shot" data-file="${f.id}"><img src="/api/files/${f.id}/view" alt="" loading="lazy"><span class="sn ${f.note ? '' : 'none'}">${esc(f.note || 'Keine Beschreibung')}</span>
        <span class="sm">${esc(firstName(userById(f.uploader_id)))} · ${fmtClock(takenAt(f))}${f.lat !== null ? ` · ${icon('pin', 12)}` : ''}${f.comments ? ` · ${icon('chat', 12)}${f.comments}` : ''}</span></button>`
    : `<button class="shot doc" data-file="${f.id}"><span class="ft">${esc(ext(f.name))}</span><span class="sn">${esc(f.name)}</span><span class="sm">${esc(firstName(userById(f.uploader_id)))} · ${fmtClock(takenAt(f))} · ${fmtSize(f.size)}</span></button>`);
  el.innerHTML = `<div class="ptools"><button class="btn primary big" id="cam">${icon('camera', 18)}Foto aufnehmen</button><button class="btn big" id="gal">${icon('upload', 18)}Dateien wählen</button></div>
    <div class="fchips"><button data-f="photos" class="${sel === 'photos' ? 'on' : ''}">${icon('image', 14)}Alle Fotos<span>${images.length}</span></button>
      ${site.folders.map((f) => `<button data-f="${f.id}" class="${sel === f.id ? 'on' : ''}">${icon('folder', 14)}${esc(f.name)}<span>${f.count}</span></button>`).join('')}
      ${images.some((f) => !f.folder_id) ? `<button data-f="none" class="${sel === 'none' ? 'on' : ''}">Ohne Mappe<span>${images.filter((f) => !f.folder_id).length}</span></button>` : ''}
      <button id="fnew" class="add">${icon('plus', 14)}Neue Mappe</button></div>
    ${folder ? `<div class="fbar"><b>${icon('folder', 16)}${esc(folder.name)}</b><span class="sp"></span><button class="btn sm" id="fren">${icon('edit', 14)}Umbenennen</button>${site.can_manage ? `<button class="btn sm danger" id="fdel">${icon('trash', 14)}Mappe löschen</button>` : ''}</div>` : ''}
    ${Object.keys(groups).sort().reverse().map((d) => `<div class="daylabel">${dayLabel(d)} · ${groups[d].length}</div><div class="shots">${groups[d].map(card).join('')}</div>`).join('')
      || `<div class="card empty">${icon('camera', 30)}${folder ? 'In dieser Mappe liegt noch nichts.' : 'Noch keine Fotos. Mit „Foto aufnehmen“ hältst du fest, was auf der Baustelle gemacht wurde – mit Beschreibung, Uhrzeit und Standort.'}</div>`}`;
  const go = (files2) => photoDialog(files2, p, site.folders, folder ? folder.id : null);
  $('#cam', el).onclick = () => pickPhotos(true, go);
  $('#gal', el).onclick = () => pickPhotos(false, go);
  $$('[data-f]', el).forEach((b) => b.onclick = () => { S.folderSel[p.id] = /^\d+$/.test(b.dataset.f) ? +b.dataset.f : b.dataset.f; refresh(); });
  const nameModal = (title, value, save) => modal({ title, body: field('Name der Mappe', `<input type="text" name="name" maxlength="60" value="${esc(value)}" placeholder="z. B. Aufmaß, Mängel, Abnahme">`), onSubmit: async (fd) => { await save(fd.get('name')); refresh(); } });
  $('#fnew', el).onclick = () => nameModal('Neue Mappe', '', async (name) => { const f = await api('POST', `/api/projects/${p.id}/folders`, { name }); S.folderSel[p.id] = f.id; });
  if ($('#fren', el)) $('#fren', el).onclick = () => nameModal('Mappe umbenennen', folder.name, (name) => api('PUT', `/api/projects/${p.id}/folders/${folder.id}`, { name }));
  if ($('#fdel', el)) $('#fdel', el).onclick = async () => { if (await confirmBox(`Die Mappe „${folder.name}“ wird gelöscht. Fotos und Dateien darin bleiben im Projekt erhalten.`)) { await guard(() => api('DELETE', `/api/projects/${p.id}/folders/${folder.id}`))(); S.folderSel[p.id] = 'photos'; refresh(); } };
  if (S.autoCamera === p.id) { S.autoCamera = null; }
};
/** Großansicht: Beschreibung, Aufnahmezeit, Standort und Mappe eines Fotos. */
async function viewerMeta(d, ctx, f) {
  const box = $('#vmeta', d); if (!box) return;
  const p = ctx.project, site = await api('GET', `/api/projects/${p.id}/site`).catch(() => null); if (!site) return;
  const canEdit = f.uploader_id === S.me.id || site.can_manage;
  const paint = () => {
    box.innerHTML = `<div class="vnote ${f.note ? '' : 'none'}">${esc(f.note || 'Keine Beschreibung')}${canEdit ? `<button class="icon-btn mini" id="vnedit" title="Beschreibung ändern">${icon('edit', 14)}</button>` : ''}</div>
      <div class="vfacts"><span>${icon('clock', 13)}${new Date(takenAt(f)).toLocaleString('de-DE', { dateStyle: 'medium', timeStyle: 'short' })} Uhr</span>
        ${f.lat !== null && f.lat !== undefined ? `<a href="${mapUrl(f)}" target="_blank" rel="noopener">${icon('pin', 13)}Standort auf der Karte</a>` : ''}
        <label>${icon('folder', 13)}<select id="vfolder"><option value="">Ohne Mappe</option>${options(site.folders.map((x) => [x.id, x.name]), f.folder_id || '')}</select></label></div>`;
    if ($('#vnedit', box)) $('#vnedit', box).onclick = () => modal({ title: 'Beschreibung', body: `<textarea name="note" maxlength="2000" style="min-height:120px">${esc(f.note || '')}</textarea>`,
      onSubmit: async (fd) => { await api('PUT', `/api/projects/${p.id}/files/${f.id}`, { note: fd.get('note') }); f.note = String(fd.get('note')).trim(); paint(); } });
    $('#vfolder', box).onchange = guard(async (e) => { await api('PUT', `/api/projects/${p.id}/files/${f.id}`, { folder_id: e.target.value || null }); f.folder_id = e.target.value ? +e.target.value : null; toast('Verschoben'); });
  };
  paint();
}

/* ---------- Tagesberichte ---------- */
function signaturePad(canvas) {
  const ctx = canvas.getContext('2d'); let drawing = false, dirty = false;
  const size = () => { const r = canvas.getBoundingClientRect(), k = window.devicePixelRatio || 1; canvas.width = r.width * k; canvas.height = r.height * k; ctx.scale(k, k); ctx.lineWidth = 2.2; ctx.lineCap = 'round'; ctx.lineJoin = 'round'; ctx.strokeStyle = '#1b2a6b'; };
  size();
  const pos = (e) => { const r = canvas.getBoundingClientRect(); return [e.clientX - r.left, e.clientY - r.top]; };
  canvas.addEventListener('pointerdown', (e) => { e.preventDefault(); canvas.setPointerCapture(e.pointerId); drawing = true; dirty = true; ctx.beginPath(); ctx.moveTo(...pos(e)); });
  canvas.addEventListener('pointermove', (e) => { if (!drawing) return; ctx.lineTo(...pos(e)); ctx.stroke(); });
  ['pointerup', 'pointercancel'].forEach((n) => canvas.addEventListener(n, () => { drawing = false; }));
  return { dirty: () => dirty, clear: () => { ctx.clearRect(0, 0, canvas.width, canvas.height); dirty = false; }, data: () => canvas.toDataURL('image/png') };
}
async function reportForm(project, rep = null, done = refresh) {
  const isNew = !rep;
  if (rep && rep.signature === undefined) rep = await api('GET', `/api/reports/${rep.id}`);
  const pre = isNew ? await api('GET', `/api/projects/${project.id}/reports/prefill?date=${todayStr()}`) : null;
  const r = rep || { date: todayStr(), client: pre.client, site: pre.site, weather: [], temp: '', staff: pre.staff.length ? pre.staff : pre.last ? pre.last.staff : [], machines: pre.last ? pre.last.machines : [], materials: [], notes: '', signature: '', signature2: '', signer: S.me.name, signer2: '' };
  const rowsHtml = (key, list, min, cols) => Array.from({ length: Math.max(min, list.length + 1) }, (_, i) => `<div class="rrow">${cols.map(([k, ph, cls]) => `<input type="text" class="${cls || ''}" data-${key}="${k}" value="${esc(list[i] ? list[i][k] || '' : '')}" placeholder="${ph}" ${k === 'name' && key === 'staff' ? 'list="rnames"' : ''} ${k === 'hours' || k === 'qty' ? 'inputmode="decimal"' : ''}>`).join('')}</div>`).join('');
  const sigHtml = (key, label, nameKey) => `<div class="sigbox"><span class="lbl">${label}</span>${r[key] ? `<img src="${r[key]}" alt="Unterschrift" data-sigimg="${key}">` : ''}<canvas data-sig="${key}" ${r[key] ? 'hidden' : ''}></canvas>
      <div class="sigrow"><input type="text" name="${nameKey}" value="${esc(r[nameKey] || '')}" placeholder="Name"><button type="button" class="btn sm" data-sigclear="${key}">${r[key] ? 'Neu unterschreiben' : 'Löschen'}</button></div></div>`;
  const { d, form } = modal({
    title: isNew ? `Neuer Tagesbericht – ${project.name}` : `Tagesbericht Nr. ${r.number} – ${project.name}`, submit: 'Speichern',
    extra: isNew ? '' : `<button type="button" class="btn danger" id="rdel">${icon('trash', 16)}</button><button type="button" class="btn" id="rprint">${icon('print', 16)}Drucken / PDF</button>`,
    body: `<datalist id="rnames">${activeUsers().map((u) => `<option value="${esc(u.name)}">`).join('')}</datalist>
      <div class="row">${field('Datum', `<input type="date" name="date" value="${esc(r.date)}">`)}${field('Temperatur (°C)', `<input type="text" name="temp" value="${esc(r.temp)}" inputmode="numeric" placeholder="z. B. 12">`)}</div>
      <div class="row">${field('Auftraggeber', `<input type="text" name="client" value="${esc(r.client)}" maxlength="200">`)}${field('Bauvorhaben', `<input type="text" name="site" value="${esc(r.site)}" maxlength="200">`)}</div>
      <label class="f"><span>Wetter</span><div class="wpick">${WEATHER.map(([k, l]) => `<label title="${l}"><input type="checkbox" name="weather" value="${k}" ${r.weather.includes(k) ? 'checked' : ''}>${icon('w_' + k, 24)}<small>${l}</small></label>`).join('')}</div></label>
      <div class="rsec"><div class="rhead"><b>Personal</b><span>Std.</span></div><div id="r-staff">${rowsHtml('staff', r.staff, 4, [['name', 'Name oder Funktion'], ['hours', '0,0', 'n']])}</div>
        <div class="rfoot"><button type="button" class="link" data-more="staff">+ Zeile</button>${isNew ? '' : `<button type="button" class="link" id="rtimes">Aus den Stempelzeiten übernehmen</button>`}<span class="sp"></span>Gesamt: <b id="rsum-staff">0,00</b></div></div>
      <div class="rsec"><div class="rhead"><b>Maschinen, Geräte, LKW</b><span>Std.</span></div><div id="r-machines">${rowsHtml('machines', r.machines, 2, [['name', 'Bezeichnung'], ['hours', '0,0', 'n']])}</div>
        <div class="rfoot"><button type="button" class="link" data-more="machines">+ Zeile</button><span class="sp"></span>Gesamt: <b id="rsum-machines">0,00</b></div></div>
      <div class="rsec"><div class="rhead"><b>Material</b><span>Menge · Einheit</span></div><div id="r-materials">${rowsHtml('materials', r.materials, 3, [['name', 'Bezeichnung'], ['qty', 'Menge', 'n'], ['unit', 'Einheit', 'n']])}</div>
        <div class="rfoot"><button type="button" class="link" data-more="materials">+ Zeile</button></div></div>
      ${field('Leistungsergebnisse / Sonstiges', `<textarea name="notes" maxlength="5000" style="min-height:96px" placeholder="Was wurde heute gemacht? Besonderheiten, Behinderungen, Absprachen …">${esc(r.notes)}</textarea>`)}
      <div class="row">${sigHtml('signature', 'Unterschrift Monteur / Bauleiter', 'signer')}${sigHtml('signature2', 'Unterschrift Auftraggeber (optional)', 'signer2')}</div>`,
    onSubmit: async () => { const saved = await save(); toast('Tagesbericht gespeichert'); done(saved); },
  });
  d.classList.add('wide', 'rform');
  const pads = {};
  $$('canvas[data-sig]', d).forEach((cv) => { if (!cv.hidden) pads[cv.dataset.sig] = signaturePad(cv); });
  $$('[data-sigclear]', d).forEach((b) => b.onclick = () => { const k = b.dataset.sigclear, cv = $(`canvas[data-sig="${k}"]`, d), img = $(`[data-sigimg="${k}"]`, d);
    if (img) { img.remove(); cv.hidden = false; r[k] = ''; pads[k] = signaturePad(cv); b.textContent = 'Löschen'; } else pads[k].clear(); });
  const collect = (key, cols) => $$(`#r-${key} .rrow`, d).map((row) => Object.fromEntries(cols.map((k) => [k, $(`[data-${key}="${k}"]`, row).value.trim()]))).filter((x) => Object.values(x).some(Boolean));
  const sums = () => { for (const k of ['staff', 'machines']) $(`#rsum-${k}`, d).textContent = fmtH(collect(k, ['name', 'hours']).reduce((n, x) => n + decimal(x.hours), 0)); };
  d.addEventListener('input', sums); sums();
  const COLS = { staff: [['name', 'Name oder Funktion'], ['hours', '0,0', 'n']], machines: [['name', 'Bezeichnung'], ['hours', '0,0', 'n']], materials: [['name', 'Bezeichnung'], ['qty', 'Menge', 'n'], ['unit', 'Einheit', 'n']] };
  $$('[data-more]', d).forEach((b) => b.onclick = () => { const k = b.dataset.more; $(`#r-${k}`, d).insertAdjacentHTML('beforeend', rowsHtml(k, [], 1, COLS[k])); });
  const fillStaff = (list) => { $('#r-staff', d).innerHTML = rowsHtml('staff', list, 4, COLS.staff); sums(); };
  if ($('#rtimes', d)) $('#rtimes', d).onclick = guard(async () => { const pf = await api('GET', `/api/projects/${project.id}/reports/prefill?date=${$('[name=date]', d).value}`); if (!pf.staff.length) return toast('Für diesen Tag hat niemand auf dieses Projekt gestempelt', true); fillStaff(pf.staff); });
  if (isNew) $('[name=date]', d).onchange = guard(async (e) => { const pf = await api('GET', `/api/projects/${project.id}/reports/prefill?date=${e.target.value}`); if (pf.staff.length) fillStaff(pf.staff); });
  async function save() {
    const fd = new FormData(form);
    const body = { date: fd.get('date'), temp: fd.get('temp'), client: fd.get('client'), site: fd.get('site'), weather: fd.getAll('weather'), notes: fd.get('notes'), signer: fd.get('signer'), signer2: fd.get('signer2'),
      staff: collect('staff', ['name', 'hours']), machines: collect('machines', ['name', 'hours']), materials: collect('materials', ['name', 'qty', 'unit']) };
    for (const k of ['signature', 'signature2']) body[k] = pads[k] ? (pads[k].dirty() ? pads[k].data() : '') : r[k];
    return isNew ? api('POST', `/api/projects/${project.id}/reports`, body) : api('PUT', `/api/reports/${r.id}`, body);
  }
  if ($('#rprint', d)) $('#rprint', d).onclick = guard(async () => { const saved = await save(); printReport(project, saved); });
  if ($('#rdel', d)) $('#rdel', d).onclick = async () => { if (await confirmBox(`Der Tagesbericht Nr. ${r.number} wird gelöscht.`)) { await guard(() => api('DELETE', `/api/reports/${r.id}`))(); d.close(); done(null); } };
}
/** Druckansicht nach dem Muster des Bau-Tagesberichts (Drucken oder „Als PDF speichern“). */
function printReport(project, r) {
  let box = $('#printbox'); if (box) box.remove();
  box = document.createElement('div'); box.id = 'printbox'; box.className = 'report';
  const b = S.brand || {}, lines = (list, n, cells) => Array.from({ length: Math.max(n, list.length) }, (_, i) => `<tr>${cells(list[i] || {})}</tr>`).join('');
  const total = (list) => fmtH(list.reduce((n, x) => n + decimal(x.hours), 0));
  box.innerHTML = `<div class="rp-head"><h1>BAU-TAGESBERICHT</h1>${b.logo ? `<img src="${esc(b.logo)}" alt="">` : `<b>${esc(b.name || '')}</b>`}</div>
    <div class="rp-top"><table class="rp"><tr><th>Auftraggeber</th><td>${esc(r.client)}</td></tr><tr><th>Bauvorhaben</th><td>${esc(r.site)}</td></tr><tr><th>Projekt</th><td>${esc([project.number, project.name].filter(Boolean).join(' · '))}</td></tr></table>
      <table class="rp sm"><tr><th>Nr.</th><td>${r.number}</td></tr><tr><th>Datum</th><td>${dmy(r.date)}</td></tr><tr><th>Temperatur</th><td>${esc(r.temp)}${r.temp ? ' °C' : ''}</td></tr></table></div>
    <div class="rp-weather">${WEATHER.map(([k, l]) => `<span><i>${r.weather.includes(k) ? '☒' : '☐'}</i>${l}</span>`).join('')}</div>
    <div class="rp-two"><table class="rp"><tr><th>Personal</th><th class="n">Std.</th></tr>${lines(r.staff, 7, (x) => `<td>${esc(x.name || '')}</td><td class="n">${esc(x.hours || '')}</td>`)}<tr class="sum"><td>Gesamt</td><td class="n">${total(r.staff)}</td></tr></table>
      <table class="rp"><tr><th>Maschinen, Geräte, LKW</th><th class="n">Std.</th></tr>${lines(r.machines, 7, (x) => `<td>${esc(x.name || '')}</td><td class="n">${esc(x.hours || '')}</td>`)}<tr class="sum"><td>Gesamt</td><td class="n">${total(r.machines)}</td></tr></table></div>
    <table class="rp"><tr><th>Material</th><th class="n">Menge</th><th class="n">Einheit</th></tr>${lines(r.materials, 9, (x) => `<td>${esc(x.name || '')}</td><td class="n">${esc(x.qty || '')}</td><td class="n">${esc(x.unit || '')}</td>`)}</table>
    <table class="rp"><tr><th>Leistungsergebnisse / Sonstiges</th></tr><tr><td class="notes">${esc(r.notes).replace(/\n/g, '<br>')}</td></tr></table>
    <div class="rp-sign"><div>${r.signature ? `<img src="${r.signature}" alt="">` : ''}<span>${dmy(r.date)} · ${esc(r.signer || '')}<br>Datum / Unterschrift Monteur / Bauleiter</span></div>
      <div>${r.signature2 ? `<img src="${r.signature2}" alt="">` : ''}<span>${esc(r.signer2 || '')}<br>Datum / Unterschrift Auftraggeber</span></div></div>
    <div class="rp-foot">${esc(b.name || '')}</div>`;
  document.body.appendChild(box);
  const imgs = $$('img', box); let left = imgs.length;
  const go = () => window.print();
  if (!left) return go();
  imgs.forEach((i) => { const ok = () => { if (--left === 0) go(); }; if (i.complete) ok(); else { i.onload = ok; i.onerror = ok; } });
}
PROJECT_TABS.berichte = async function (el, data) {
  const p = data.project, site = await api('GET', `/api/projects/${p.id}/site`);
  el.innerHTML = `<div class="ptools"><button class="btn primary big" id="rnew">${icon('report', 18)}Neuer Tagesbericht</button></div>
    <section class="card"><div class="card-b" style="padding-top:10px">${site.reports.map((r) => `<div class="li" data-rep="${r.id}"><span class="ft">${icon('report', 18)}</span>
      <div class="t"><b>Nr. ${r.number} · ${fmtLong(r.date)} ${r.date.slice(0, 4)}</b><small>${r.staff.length} ${r.staff.length === 1 ? 'Person' : 'Personen'} · ${fmtH(r.hours)} Std.${r.materials.length ? ` · ${r.materials.length} Material` : ''} · ${esc(userById(r.created_by)?.name || '')}${r.notes ? ' · ' + esc(r.notes.slice(0, 80)) : ''}</small></div>
      ${r.signed ? '<span class="chip ok">unterschrieben</span>' : '<span class="chip soon">ohne Unterschrift</span>'}<button class="icon-btn" data-print="${r.id}" title="Drucken / PDF">${icon('print')}</button></div>`).join('')
      || `<div class="empty">${icon('report', 30)}Noch kein Tagesbericht. Personal und Stunden werden aus den Stempelzeiten vorgeschlagen.</div>`}</div></section>`;
  $('#rnew', el).onclick = guard(() => reportForm(p));
  $$('[data-rep]', el).forEach((row) => row.addEventListener('click', guard(async (e) => {
    const rep = site.reports.find((x) => x.id === +row.dataset.rep);
    if (e.target.closest('[data-print]')) return printReport(p, await api('GET', `/api/reports/${rep.id}`));
    return reportForm(p, rep);
  })));
};

/* ---------- Projekt: Zeiten ---------- */
PROJECT_TABS.zeiten = async function (el, data) {
  const { hours: h } = await api('GET', `/api/projects/${data.project.id}/site`);
  el.innerHTML = `<div class="facts"><div class="fact"><span class="ico">${icon('clock', 18)}</span><div><small>Gestempelte Stunden gesamt</small><b>${hm(h.total)} Std.</b></div></div>
      <div class="fact"><span class="ico">${icon('team', 18)}</span><div><small>Mitarbeiter</small><b>${h.users.length}</b></div></div><div class="fact"><span class="ico">${icon('cal', 18)}</span><div><small>Arbeitstage</small><b>${h.days.length}</b></div></div></div>
    <div class="grid2"><section class="card"><div class="card-h"><h3>Je Mitarbeiter</h3></div><div class="card-b">${h.users.map((u) => `<div class="li plain">${avatar(userById(u.user_id) || u, 30)}<div class="t"><b>${esc(u.name)}</b><small>${u.days} ${u.days === 1 ? 'Tag' : 'Tage'}</small></div><b>${hm(u.minutes)}</b></div>`).join('')
      || `<div class="empty">${icon('clock', 28)}Noch keine Zeiten. Sie entstehen, wenn Mitarbeiter über den QR-Code dieses Projekts stempeln oder beim Stempeln diese Baustelle wählen.</div>`}</div></section>
    <section class="card"><div class="card-h"><h3>Je Tag</h3></div><div class="card-b">${h.days.map((d) => `<div class="li plain"><div class="t"><b>${fmtShort(d.date)}</b><small>${d.people.map((x) => `${esc(x.name.split(' ')[0])} ${hm(x.minutes)}`).join(' · ')}</small></div><b>${hm(d.minutes)}</b></div>`).join('') || '<div class="empty">—</div>'}</div></section></div>`;
};
/** Projekt-Übersicht: Fotos, Tagesberichte und Zeiten auf einen Blick. */
async function projectOverviewExtra(main, data) {
  const p = data.project, site = await api('GET', `/api/projects/${p.id}/site`);
  const facts = $('.pmain .facts', main); if (!facts) return;
  const imgs = site.files.filter((f) => f.category === 'image'), last = site.reports[0];
  facts.insertAdjacentHTML('afterend', `<div class="plinks">
    <a class="card" href="#/projekte/${p.id}/fotos"><div class="ph"><b>${icon('camera', 16)}Fotos</b><span>${imgs.length}</span></div><div class="pthumbs">${imgs.slice(0, 4).map((f) => `<img src="/api/files/${f.id}/view" alt="" loading="lazy">`).join('') || '<small class="muted">Noch keine Fotos</small>'}</div></a>
    <a class="card" href="#/projekte/${p.id}/berichte"><div class="ph"><b>${icon('report', 16)}Tagesberichte</b><span>${site.reports.length}</span></div><small class="muted">${last ? `Zuletzt: Nr. ${last.number} vom ${dmy(last.date)}` : 'Noch kein Bericht'}</small></a>
    <a class="card" href="#/projekte/${p.id}/zeiten"><div class="ph"><b>${icon('clock', 16)}Zeiten</b><span>${hm(site.hours.total)} Std.</span></div><small class="muted">${site.hours.users.length ? site.hours.users.slice(0, 3).map((u) => esc(u.name.split(' ')[0])).join(', ') : 'Noch nichts gestempelt'}</small></a></div>`);
}

/* ---------- Startseite ---------- */
const dashboardBeforeSite = PAGES[''];
PAGES[''] = async function (main) {
  if (!isSite()) {
    await dashboardBeforeSite(main);
    // Büro: Was passiert gerade auf den Baustellen?
    const feed = await api('GET', '/api/site/feed').catch(() => null), stacks = $$('.grid2 .stack', main);
    if (!feed || !stacks[1] || !(feed.photos.length || feed.reports.length || feed.present.length)) return;
    stacks[1].insertAdjacentHTML('afterbegin', `<section class="card"><div class="card-h"><h3>Von den Baustellen</h3><a href="#/projekte">Projekte</a></div><div class="card-b">
      ${feed.present.length ? `<div class="presence">${feed.present.map((e) => `<span class="chip ok" title="seit ${fmtClock(e.start)} Uhr">${esc(e.name.split(' ')[0])}${e.project ? ' · ' + esc(e.project) : ''}</span>`).join('')}</div>` : ''}
      ${feed.photos.length ? `<div class="pthumbs big">${feed.photos.slice(0, 4).map((f) => `<a href="#/projekte/${f.project_id}/fotos" title="${esc(f.project)}${f.note ? ' – ' + esc(f.note) : ''}"><img src="/api/files/${f.id}/view" alt="" loading="lazy"><small>${esc(f.project)}</small></a>`).join('')}</div>` : ''}
      ${feed.reports.map((r) => `<a class="li" href="#/projekte/${r.project_id}/berichte" style="text-decoration:none;color:inherit"><span class="ft">${icon('report', 18)}</span><div class="t"><b>Tagesbericht Nr. ${r.number} · ${esc(r.project)}</b><small>${dmy(r.date)} · ${esc(userById(r.created_by)?.name || '')}</small></div></a>`).join('')}</div></section>`);
    return;
  }
  const [st, home, tasks] = await Promise.all([api('GET', '/api/time/me'), api('GET', '/api/site/home'), api('GET', '/api/tasks'), loadProjects().catch(() => [])]);
  const active = (S.projects || []).filter((p) => p.status === 'active');
  const mine = [...home.recent.map((id) => active.find((p) => p.id === id)).filter(Boolean), ...active.filter((p) => !home.recent.includes(p.id))].slice(0, 8);
  const todo = tasks.filter((t) => t.assignee_id === S.me.id && t.status !== 'done').sort((a, b) => (a.due || '9').localeCompare(b.due || '9')).slice(0, 5);
  const h = new Date().getHours();
  main.innerHTML = `<div class="page sitehome"><div class="page-head"><div><h1>${h < 11 ? 'Guten Morgen' : h < 18 ? 'Hallo' : 'Guten Abend'}, ${esc(firstName(S.me))}</h1><p>${fmtLong(todayStr())}</p></div></div>
    ${stampCard(st)}
    ${st.open ? `<label class="f sitewhere"><span>Ich arbeite gerade auf dieser Baustelle</span><select id="where"><option value="">— Bitte wählen —</option>${options(active.map((p) => [p.id, [p.number, p.name].filter(Boolean).join(' · ')]), st.open.project_id || '')}</select></label>` : ''}
    <div class="tiles"><button class="tile a" id="t-photo">${icon('camera', 30)}<b>Foto aufnehmen</b><small>mit Beschreibung und Standort</small></button>
      <button class="tile" id="t-report">${icon('report', 30)}<b>Tagesbericht</b><small>Personal, Material, Unterschrift</small></button>
      <a class="tile" href="#/zeit/abwesenheit">${icon('sun', 30)}<b>Urlaub &amp; Krank</b><small>${num(st.vacation.remaining)} Tage Resturlaub</small></a>
      <a class="tile" href="#/zeit">${icon('clock', 30)}<b>Meine Stunden</b><small>Konto ${hmSigned(st.balance)} Std.</small></a></div>
    <section class="card"><div class="card-h"><h3>Meine Baustellen</h3><a href="#/projekte">Alle</a></div><div class="card-b">${mine.map((p) => `<a class="li" href="#/projekte/${p.id}/fotos" style="text-decoration:none;color:inherit"><span class="ft">${icon('projects', 18)}</span><div class="t"><b>${esc(p.name)}</b><small>${esc([p.number, p.customer, p.address].filter(Boolean).join(' · '))}</small></div>${home.current === p.id ? '<span class="chip ok">jetzt</span>' : ''}${icon('right', 16)}</a>`).join('') || `<div class="empty">${icon('projects', 28)}Noch keine aktiven Projekte.</div>`}</div></section>
    <section class="card" style="margin-top:20px"><div class="card-h"><h3>Meine Aufgaben</h3><a href="#/aufgaben">Alle</a></div><div class="card-b">${todo.map((t) => `<div class="li" data-task="${t.id}"><button class="circle" data-done="${t.id}">${icon('check', 13)}</button><div class="t"><b>${esc(t.title)}</b></div>${dueChip(t.due, t.status)}</div>`).join('') || `<div class="empty">${icon('check', 28)}Keine offenen Aufgaben.</div>`}</div></section></div>`;
  bindStamp(main);
  const pref = [...(home.current ? [home.current] : []), ...home.recent];
  if ($('#where')) $('#where').onchange = guard(async (e) => { await api('PUT', '/api/time/project', { project_id: e.target.value || null }); toast('Baustelle gespeichert'); refresh(); });
  $('#t-photo').onclick = guard(async () => {
    const p = home.current ? active.find((x) => x.id === home.current) : await chooseProject('Für welche Baustelle ist das Foto?', pref); if (!p) return;
    const site = await api('GET', `/api/projects/${p.id}/site`);
    pickPhotos(true, (files) => photoDialog(files, p, site.folders, null, () => { location.hash = `#/projekte/${p.id}/fotos`; }));
  });
  $('#t-report').onclick = guard(async () => { const p = await chooseProject('Tagesbericht für welche Baustelle?', pref); if (p) reportForm(p, null, () => { location.hash = `#/projekte/${p.id}/berichte`; }); });
  $$('[data-task]', main).forEach((el) => el.addEventListener('click', (e) => { if (e.target.closest('[data-done]')) return; taskModal(tasks.find((t) => t.id === +el.dataset.task)); }));
  $$('[data-done]', main).forEach((b) => b.addEventListener('click', guard(async () => { await api('PUT', `/api/tasks/${b.dataset.done}`, { status: 'done' }); toast('Aufgabe erledigt'); refresh(); })));
};
