'use strict';
/* Ab Version 1.9: Reinsprechen mit Übersetzung. Neben passenden Textfeldern erscheint ein Mikrofon-Knopf. */
Object.assign(ICONS, { mic: '<rect x="9" y="3.500" width="6" height="11" rx="3"/><path d="M5.500 11.500a6.500 6.500 0 0 0 13 0M12 18v2.500"/>' });

let speechReady = null;                                                     // null = noch nicht gefragt
async function speechAvailable() { if (speechReady === null) { try { speechReady = (await api('GET', '/api/speech')).available; } catch { speechReady = false; } } return speechReady; }

/** Aufnahme starten/stoppen, an das Portal schicken, Ergebnis in das Textfeld setzen: erst Deutsch, darunter das Original. */
function micFor(ta) {
  if (ta.dataset.micOn) return; ta.dataset.micOn = '1';
  const btn = document.createElement('button'); btn.type = 'button'; btn.className = 'micbtn';
  const idle = () => { btn.className = 'micbtn'; btn.innerHTML = `${icon('mic', 18)}<span>Reinsprechen</span>`; btn.disabled = false; };
  idle(); ta.insertAdjacentElement('afterend', btn);
  let rec = null, chunks = [], timer = null, started = 0, stream = null;
  const stop = () => { if (rec && rec.state !== 'inactive') rec.stop(); };
  btn.onclick = async () => {
    if (rec && rec.state === 'recording') return stop();
    if (!(await speechAvailable())) return toast(S.me.role === 'admin' ? 'Die Spracheingabe ist noch nicht eingerichtet – unter Einstellungen → Spracheingabe den Schlüssel hinterlegen.' : 'Die Spracheingabe ist noch nicht eingerichtet. Bitte im Büro Bescheid sagen.', true);
    if (!navigator.mediaDevices || !window.MediaRecorder || !window.isSecureContext) return toast('Die Aufnahme geht nur über die sichere Adresse des Portals (https) und in einem aktuellen Browser.', true);
    try { stream = await navigator.mediaDevices.getUserMedia({ audio: true }); }
    catch { return toast('Das Mikrofon ist nicht freigegeben. Bitte in den Einstellungen des Handys für diese Seite erlauben.', true); }
    const type = ['audio/webm;codecs=opus', 'audio/webm', 'audio/mp4', 'audio/ogg'].find((t) => MediaRecorder.isTypeSupported(t)) || '';
    rec = new MediaRecorder(stream, type ? { mimeType: type } : undefined); chunks = [];
    rec.ondataavailable = (e) => { if (e.data && e.data.size) chunks.push(e.data); };
    rec.onstop = async () => {
      clearInterval(timer); stream.getTracks().forEach((t) => t.stop());
      const blob = new Blob(chunks, { type: (rec.mimeType || type || 'audio/webm').split(';')[0] });
      btn.className = 'micbtn busy'; btn.disabled = true; btn.innerHTML = `${icon('mic', 18)}<span>Wird übersetzt …</span>`;
      try {
        const r = await fetch('/api/speech', { method: 'POST', headers: { 'Content-Type': blob.type }, body: blob });
        const d = await r.json().catch(() => ({}));
        if (!r.ok) throw new Error(d.error || 'Das hat nicht geklappt');
        const text = d.same ? d.german : `${d.german}\n[${d.language || 'Original'}] ${d.original}`;
        ta.value = (ta.value.trim() ? ta.value.replace(/\s+$/, '') + '\n\n' : '') + text;
        ta.dispatchEvent(new Event('input', { bubbles: true })); ta.scrollTop = ta.scrollHeight;
        toast(d.same ? 'Text eingefügt' : 'Übersetzt und eingefügt');
      } catch (e) { toast(e.message, true); }
      idle();
    };
    rec.start(); started = Date.now();
    btn.className = 'micbtn rec';
    const tick = () => { const s = Math.floor((Date.now() - started) / 1000); btn.innerHTML = `<i></i><span>Aufnahme läuft ${Math.floor(s / 60)}:${pad(s % 60)} – tippen zum Beenden</span>`; if (s >= 120) stop(); };
    tick(); timer = setInterval(tick, 500);
  };
}
// Textfelder mit data-mic bekommen den Knopf, sobald sie erscheinen (Dialoge werden erst beim Öffnen gebaut)
new MutationObserver(() => { for (const ta of document.querySelectorAll('textarea[data-mic]:not([data-mic-on])')) micFor(ta); }).observe(document.documentElement, { childList: true, subtree: true });

/* ---------- Einstellungen: Schlüssel und Sprache ---------- */
const settingsBeforeSpeech = PAGES.einstellungen;
PAGES.einstellungen = async function (main) {
  await settingsBeforeSpeech(main);
  const page = $('.page', main); if (!page || S.me.role !== 'admin') return;
  const c = await api('GET', '/api/admin/speech').catch(() => null); if (!c) return;
  const card = document.createElement('section'); card.className = 'card set';
  card.innerHTML = `<div class="set-h"><span class="ico">${icon('mic', 20)}</span><div><h3>Spracheingabe &amp; Übersetzung</h3><p class="muted">Mitarbeiter sprechen den Tagesbericht oder die Foto-Beschreibung in ihrer Sprache ein. Das Portal schreibt den Text auf Deutsch und setzt das Original darunter.</p></div></div>
    <div class="set-b"><div class="notice ${c.configured ? 'ok' : ''}">${c.configured ? `Eingerichtet. Verwendet werden die OpenAI-Modelle <b>${esc(c.stt || '?')}</b> (Sprache → Text) und <b>${esc(c.text || '?')}</b> (Übersetzung).` : 'Noch nicht eingerichtet. Dafür ist ein Schlüssel von OpenAI nötig (platform.openai.com → API keys), dazu etwas Guthaben. Eine Aufnahme kostet etwa einen Cent.'}</div>
      <form id="spf"><div class="row">${field(c.configured ? 'Neuen Schlüssel eintragen (leer lassen = unverändert)' : 'OpenAI-Schlüssel', '<input type="password" name="key" placeholder="sk-…" autocomplete="off" spellcheck="false">')}
        ${field('Sprache der Mitarbeiter', `<select name="language">${options(Object.entries(c.languages), c.language)}</select>`)}</div>
        <p class="muted" style="font-size:13px;margin:-4px 0 14px">Die Aufnahmen werden zur Verarbeitung an OpenAI (USA) geschickt und vom Portal nicht gespeichert. Der Schlüssel bleibt auf dem Server und wird hier nicht wieder angezeigt.</p>
        <div style="display:flex;gap:10px;flex-wrap:wrap"><button class="btn primary">Speichern</button>${c.configured ? '<button type="button" class="btn" id="sptest">Verbindung testen</button><button type="button" class="btn danger" id="sprm">Schlüssel entfernen</button>' : ''}</div></form></div>`;
  page.appendChild(card);
  $('#spf').addEventListener('submit', guard(async (e) => { e.preventDefault(); const fd = new FormData(e.target), body = { language: fd.get('language') }; if (String(fd.get('key')).trim()) body.key = fd.get('key');
    const b = $('button', e.target); b.disabled = true; try { await api('PUT', '/api/admin/speech', body); speechReady = null; toast('Gespeichert'); refresh(); } finally { b.disabled = false; } }));
  if ($('#sptest')) $('#sptest').onclick = guard(async () => { const b = $('#sptest'); b.disabled = true; b.textContent = 'Teste …'; try { const r = await api('POST', '/api/admin/speech/test'); modal({ title: 'Verbindung funktioniert', readonly: true, body: `<p style="margin:0 0 8px" class="muted">Probe (Albanisch → Deutsch):</p><p style="margin:0 0 6px">„Sot kemi hapur kanalin dhe kemi vendosur tubat.“</p><p style="margin:0"><b>${esc(r.sample)}</b></p>` }); } finally { b.disabled = false; b.textContent = 'Verbindung testen'; } });
  if ($('#sprm')) $('#sprm').onclick = async () => { if (await confirmBox('Der Schlüssel wird entfernt. Die Spracheingabe ist danach ausgeschaltet.', 'Entfernen')) { await guard(() => api('PUT', '/api/admin/speech', { key: '' }))(); speechReady = null; refresh(); } };
};
