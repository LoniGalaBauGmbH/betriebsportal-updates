'use strict';
/* Ab Version 1.7: Betrieb auf einem Server – Umzug vom Hauptrechner und Sicherung zurück auf einen Büro-Rechner. */
Object.assign(ICONS, { cloud: '<path d="M7 18.500a4 4 0 0 1-.600-7.950 5.500 5.500 0 0 1 10.700 1.200A3.400 3.400 0 0 1 17 18.500Z"/>' });
const settingsBeforeRemote = PAGES.einstellungen;
PAGES.einstellungen = async function (main) {
  await settingsBeforeRemote(main);
  const page = $('.page', main); if (!page || S.me.role !== 'admin') return;
  const [backup, move] = await Promise.all([api('GET', '/api/admin/backup'), api('GET', '/api/admin/move').catch(() => null)]);
  const app = window.portalApp || {}, when = (iso) => new Date(iso).toLocaleString('de-DE', { dateStyle: 'medium', timeStyle: 'short' });

  if (backup.server) {
    /* ----- Portal läuft auf dem Server: Sicherung liegt dort; dieser Computer kann sie sich zusätzlich holen ----- */
    const dirLabel = $('#bf label.f'); if (dirLabel) { dirLabel.hidden = true; const tip = dirLabel.nextElementSibling; if (tip && tip.tagName === 'P') tip.hidden = true; }
    const m = typeof app.mirrorState === 'function' ? await app.mirrorState() : null;
    const card = document.createElement('section'); card.className = 'card set';
    card.innerHTML = `<div class="set-h"><span class="ico">${icon('down', 20)}</span><div><h3>Sicherung auf diesen Computer</h3><p class="muted">Das Portal läuft auf dem Server und wird dort stündlich gesichert. Zusätzlich kann sich ein Computer im Büro diese Sicherung stündlich holen – so liegt immer eine Kopie bei euch.</p></div></div><div class="set-b">${
      !m ? '<div class="notice">Das geht im installierten Programm (ab Version 1.7) auf dem Computer, der die Kopie bekommen soll – z. B. der bisherige Hauptrechner.</div>'
      : !m.dir ? `<button class="btn primary" id="mpick">${icon('folder', 16)}Ordner wählen und einschalten</button><p class="muted" style="font-size:13px;margin:10px 0 0">Der Computer sollte regelmäßig eingeschaltet sein. Die Kopie enthält die Datenbank, alle Dateien und die lesbare Ordner-Ansicht.</p>`
      : `<div class="notice ${m.last && !m.last.ok ? 'bad' : 'ok'}">${!m.last ? 'Eingeschaltet – der erste Abgleich läuft in Kürze.' : m.last.ok ? `Letzter Abgleich: <b>${when(m.last.at)}</b> · ${m.last.files} Dateien, ${m.last.fetched} neu geholt` : `Der letzte Abgleich ist fehlgeschlagen (${when(m.last.at)}): ${esc(m.last.error || '')}`}</div>
        <label class="f"><span>Ordner auf diesem Computer</span><span class="dirrow"><input type="text" readonly value="${esc(m.dir)}"><button type="button" class="btn" id="mpick">${icon('folder', 16)}Ändern …</button><button type="button" class="btn" id="mopen">Ordner öffnen</button></span></label>
        <div style="display:flex;gap:10px;margin-bottom:8px"><button class="btn" id="mrun">Jetzt abgleichen</button><button class="btn danger" id="moff">Ausschalten</button></div>`}</div>`;
    $('#bf').closest('section').after(card);
    const set = async (dir) => { const { token } = await api('GET', '/api/admin/backup/token'); await app.mirrorSet({ dir, token }); };
    if ($('#mpick')) $('#mpick').onclick = guard(async () => { const dir = await app.mirrorPick(m.dir || ''); if (!dir) return; await set(dir); toast('Eingeschaltet – der Abgleich startet'); setTimeout(refresh, 1500); });
    if ($('#mopen')) $('#mopen').onclick = () => app.mirrorOpen();
    if ($('#mrun')) $('#mrun').onclick = guard(async () => { const b = $('#mrun'); b.disabled = true; b.textContent = 'Gleiche ab …'; const r = await app.mirrorRun(); toast(r && r.ok ? 'Abgleich fertig' : 'Abgleich fehlgeschlagen', !(r && r.ok)); refresh(); });
    if ($('#moff')) $('#moff').onclick = guard(async () => { if (!(await confirmBox('Die Sicherung wird nicht mehr auf diesen Computer geholt. Vorhandene Dateien bleiben liegen.', 'Ausschalten'))) return; await app.mirrorSet({ dir: '' }); refresh(); });
    return;
  }

  /* ----- Portal läuft noch auf dem Hauptrechner: Umzug auf einen Server anbieten ----- */
  if (!move || !['localhost', '127.0.0.1'].includes(location.hostname)) return;
  const card = document.createElement('section'); card.className = 'card set';
  card.innerHTML = `<div class="set-h"><span class="ico">${icon('cloud', 20)}</span><div><h3>Umzug auf einen Server</h3><p class="muted">Damit das Portal auch von unterwegs, zu Hause und auf dem Handy erreichbar ist, zieht es auf einen Server im Internet um. Dieser Computer wird danach ein normaler Arbeitsplatz und holt sich stündlich eine Sicherung.</p></div></div>
    <div class="set-b"><form id="mvf"><div class="row">${field('Adresse des Servers', '<input type="text" name="url" placeholder="portal.deine-firma.de" spellcheck="false">')}${field('Einrichtungscode des Servers', '<input type="text" name="code" placeholder="XXXX-XXXX-XXXX" autocomplete="off" style="text-transform:uppercase;letter-spacing:.1em">')}</div>
      <p class="muted" style="font-size:13px;margin:-4px 0 14px">Am besten umziehen, wenn gerade niemand arbeitet: Was während der Übertragung noch eingetragen wird, kommt nicht mit. Die Daten auf diesem Computer bleiben als Kopie erhalten.</p>
      <button class="btn primary">Umzug starten</button></form></div>`;
  page.appendChild(card);
  $('#mvf').addEventListener('submit', guard(async (e) => {
    e.preventDefault(); const fd = new FormData(e.target);
    if (!(await confirmBox('Alle Daten werden jetzt auf den Server übertragen. Danach arbeitet die ganze Firma über den Server.', 'Umzug starten'))) return;
    await api('POST', '/api/admin/move', { url: fd.get('url'), code: fd.get('code') });
    moveProgress(backup.dir);
  }));
};
/** Fortschritt des Umzugs; am Ende verbindet sich das Programm mit dem Server. */
function moveProgress(backupDir) {
  const o = document.createElement('div'); o.className = 'uov';
  o.innerHTML = `<div class="uov-card"><div class="uov-ico">${icon('cloud', 26)}</div><h3>Umzug auf den Server</h3><p id="mv-t">Verbindung wird hergestellt …</p><div class="uov-bar"><i id="mv-b"></i></div><small id="mv-s">Bitte das Fenster nicht schließen.</small></div>`;
  document.body.appendChild(o);
  const tick = async () => {
    let j; try { j = await api('GET', '/api/admin/move'); } catch { return setTimeout(tick, 1500); }
    if (j.state === 'error') { o.remove(); modal({ title: 'Der Umzug hat nicht geklappt', readonly: true, body: `<p style="margin:0 0 10px">${esc(j.error)}</p><p class="muted" style="margin:0">Es wurde nichts verändert – das Portal läuft weiter auf diesem Computer. Du kannst es jederzeit erneut versuchen.</p>` }); return; }
    const pct = j.totalBytes ? (j.bytes / j.totalBytes) * 100 : j.total ? (j.done / j.total) * 100 : 3;
    $('#mv-b', o).style.width = Math.max(3, Math.round(pct)) + '%';
    $('#mv-t', o).textContent = j.state === 'upload' ? `Datei ${Math.min(j.done + 1, j.total)} von ${j.total} wird übertragen (${fmtSize(j.bytes)} von ${fmtSize(j.totalBytes)})` : j.state === 'finish' ? 'Der Server übernimmt die Daten …' : j.state === 'done' ? 'Fertig! Das Programm verbindet sich mit dem Server …' : 'Daten werden vorbereitet …';
    if (j.state !== 'done') return setTimeout(tick, 700);
    const app = window.portalApp || {};
    if (typeof app.moveToServer === 'function') { setTimeout(() => app.moveToServer({ url: j.url, token: j.token, dir: backupDir }), 2500); return; }
    o.remove();
    modal({ title: 'Umzug abgeschlossen', readonly: true, body: `<p style="margin:0 0 10px">Alle Daten liegen jetzt auf dem Server: <b>${esc(j.url)}</b></p><p class="muted" style="margin:0">Bitte das Programm auf die neueste Version aktualisieren und dann über das Symbol neben der Uhr mit dieser Adresse verbinden.</p>` });
  };
  tick();
}
