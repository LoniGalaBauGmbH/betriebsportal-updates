'use strict';
/* ============ Grundlagen ============ */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const S = { me: null, users: [], conv: 'all', taskFilter: 'mine', taskPerson: '', taskQ: '', calMode: 'all', calMonth: null, unread: null, cleanup: [] };

const ICONS = {
  home: '<path d="M3 11.5 12 4l9 7.5"/><path d="M5 10v10h14V10"/>',
  tasks: '<rect x="3.5" y="3.5" width="17" height="17" rx="4"/><path d="m8 12 3 3 5-6"/>',
  chat: '<path d="M21 12a8 8 0 0 1-11.6 7.1L4 20.5l1.4-4.6A8 8 0 1 1 21 12Z"/>',
  cal: '<rect x="3.5" y="5" width="17" height="15.5" rx="3"/><path d="M3.5 10h17M8 3v4M16 3v4"/>',
  folder: '<path d="M3.5 7.5a2.5 2.5 0 0 1 2.5-2.5h3.6l2 2.5H18a2.5 2.5 0 0 1 2.5 2.5v7.5a2.5 2.5 0 0 1-2.5 2.5H6a2.5 2.5 0 0 1-2.5-2.5Z"/>',
  team: '<circle cx="9" cy="8.5" r="3.5"/><path d="M2.5 20c.6-3.6 3.2-5.5 6.5-5.5s5.9 1.9 6.5 5.5"/><path d="M16 5.2a3.5 3.5 0 0 1 0 6.6M18 14.8c2 .6 3.2 2.3 3.5 5.2"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  x: '<path d="M6 6l12 12M18 6 6 18"/>',
  search: '<circle cx="11" cy="11" r="6.5"/><path d="m20 20-4.2-4.2"/>',
  clip: '<path d="m20 11-8.2 8.2a5 5 0 0 1-7-7l8.5-8.5a3.3 3.3 0 0 1 4.7 4.7l-8.6 8.6a1.7 1.7 0 0 1-2.4-2.4l7.9-7.9"/>',
  send: '<path d="M21 3 10.5 13.5"/><path d="M21 3 14.5 21l-4-7.5L3 9.5Z"/>',
  down: '<path d="M12 4v11"/><path d="m7 11 5 5 5-5"/><path d="M5 20h14"/>',
  trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 12a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2l1-12M9 7V4h6v3"/>',
  left: '<path d="m15 5-7 7 7 7"/>', right: '<path d="m9 5 7 7-7 7"/>',
  out: '<path d="M14 4h4a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2h-4M10 16l-4-4 4-4M6 12h10"/>',
  moon: '<path d="M20 14.5A8.5 8.5 0 0 1 9.5 4a8.5 8.5 0 1 0 10.5 10.5Z"/>',
  key: '<circle cx="8" cy="15" r="4"/><path d="m11 12 8-8M16 7l3 3"/>',
  alert: '<path d="M12 4 2.8 19.5h18.4Z"/><path d="M12 10v4.5M12 17.2v.1"/>',
  clock: '<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>',
  hash: '<path d="M5 9h14M5 15h14M10 4 8 20M16 4l-2 16"/>',
  check: '<path d="m5 12.5 4.5 4.5L19 7.5"/>',
  edit: '<path d="M4 20h4L19 9a2.8 2.8 0 0 0-4-4L4 16Z"/>',
  upload: '<path d="M12 16V5"/><path d="m7 9 5-5 5 5"/><path d="M5 20h14"/>',
  inbox: '<path d="M3.5 13 6 5.5h12L20.5 13M3.5 13v5a2 2 0 0 0 2 2h13a2 2 0 0 0 2-2v-5M3.5 13H9a3 3 0 0 0 6 0h5.5"/>',
};
const icon = (n, s = 18) => `<svg class="ic" width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[n] || ''}</svg>`;

async function api(method, url, body) {
  const r = await fetch(url, { method, headers: body ? { 'Content-Type': 'application/json' } : {}, body: body ? JSON.stringify(body) : undefined });
  let data = null; try { data = await r.json(); } catch { /* leer */ }
  if (!r.ok) {
    if (r.status === 401 && S.me && !url.includes('/login')) { location.reload(); }
    const err = new Error(data?.error || `Fehler (${r.status})`); err.data = data || {}; throw err;
  }
  return data;
}
function toast(msg, err = false) {
  const t = document.createElement('div');
  t.className = 'toast' + (err ? ' err' : ''); t.textContent = msg;
  const box = $('#toasts');
  while (box.children.length >= 3) box.firstChild.remove(); // höchstens drei Hinweise gleichzeitig
  box.appendChild(t);
  setTimeout(() => t.remove(), err ? 5000 : 3200);
}
const guard = (fn) => async (...a) => { try { return await fn(...a); } catch (e) { toast(e.message, true); } };

/* ---- Datum/Zeit ---- */
const pad = (n) => String(n).padStart(2, '0');
const ymd = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const parseD = (s) => { const [y, m, d] = s.split('-').map(Number); return new Date(y, m - 1, d); };
const todayStr = () => ymd(new Date());
const addDays = (s, n) => { const d = parseD(s); d.setDate(d.getDate() + n); return ymd(d); };
const fmtShort = (s) => parseD(s).toLocaleDateString('de-DE', { weekday: 'short', day: 'numeric', month: 'short' });
const fmtLong = (s) => parseD(s).toLocaleDateString('de-DE', { weekday: 'long', day: 'numeric', month: 'long' });
const fmtTime = (iso) => { const d = new Date(iso); return ymd(d) === todayStr() ? d.toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' }) : d.toLocaleDateString('de-DE', { day: 'numeric', month: 'short' }); };
const fmtClock = (iso) => new Date(iso).toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' });
const fmtSize = (n) => n < 1024 ? n + ' B' : n < 1048576 ? Math.round(n / 1024) + ' KB' : (n / 1048576).toFixed(1).replace('.', ',') + ' MB';
const daysDiff = (s) => Math.round((parseD(s) - parseD(todayStr())) / 864e5);
function dueChip(due, status) {
  if (!due) return '';
  if (status === 'done') return `<span class="chip">${icon('cal', 13)}${fmtShort(due)}</span>`;
  const d = daysDiff(due);
  if (d < 0) return `<span class="chip late">${icon('alert', 13)}${d === -1 ? 'Gestern fällig' : `${-d} Tage überfällig`}</span>`;
  if (d === 0) return `<span class="chip soon">${icon('clock', 13)}Heute</span>`;
  if (d === 1) return `<span class="chip soon">${icon('clock', 13)}Morgen</span>`;
  return `<span class="chip">${icon('cal', 13)}${fmtShort(due)}</span>`;
}

/* ---- Personen ---- */
const userById = (id) => S.users.find((u) => u.id === id);
const activeUsers = () => S.users.filter((u) => u.active);
const initials = (n) => n.split(/\s+/).filter(Boolean).slice(0, 2).map((p) => p[0]).join('').toUpperCase();
const hue = (n) => { let h = 0; for (const c of n) h = (h * 31 + c.charCodeAt(0)) % 360; return h; };
const avatar = (u, s = 28) => u && u.avatar
  ? `<img class="av" style="--s:${s}px" src="${esc(u.avatar)}" alt="" title="${esc(u.name)}">`
  : u
  ? `<span class="av" style="--s:${s}px;background:hsl(${hue(u.name)} 48% 44%)" title="${esc(u.name)}">${esc(initials(u.name))}</span>`
  : `<span class="av" style="--s:${s}px;background:var(--faint)" title="Nicht zugewiesen">?</span>`;
const firstName = (u) => (u ? u.name.split(' ')[0] : 'Niemand');

/* ============ Modale ============ */
function modal({ title, body, submit = 'Speichern', extra = '', onSubmit, readonly = false, locked = false }) {
  const d = document.createElement('dialog');
  d.className = 'modal';
  d.innerHTML = `<form class="mf" novalidate><header><h3>${esc(title)}</h3>${locked ? '' : `<button type="button" class="icon-btn" data-close aria-label="Schließen">${icon('x')}</button>`}</header>
    <div class="mb">${body}</div><div class="err" hidden></div>
    <footer>${extra}<span class="sp"></span>${locked ? '' : `<button type="button" class="btn" data-close>${readonly ? 'Schließen' : 'Abbrechen'}</button>`}${readonly ? '' : `<button class="btn primary" type="submit">${esc(submit)}</button>`}</footer></form>`;
  document.body.appendChild(d);
  d.showModal();
  d.addEventListener('close', () => d.remove());
  if (locked) d.addEventListener('cancel', (e) => e.preventDefault());
  d.addEventListener('mousedown', (e) => { if (e.target === d && !locked) d.close(); });
  $$('[data-close]', d).forEach((b) => b.addEventListener('click', () => d.close()));
  const form = $('form', d);
  const errBox = $('.err', d);
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = $('button[type=submit]', d);
    if (btn) btn.disabled = true;
    errBox.hidden = true;
    try { await onSubmit(new FormData(form), form); d.close(); }
    catch (err) { errBox.textContent = err.message; errBox.hidden = false; if (btn) btn.disabled = false; }
  });
  const first = $('input[type=text],textarea', d); if (first && !readonly) first.focus();
  return { d, form };
}
const field = (label, inner) => `<label class="f"><span>${esc(label)}</span>${inner}</label>`;
const options = (list, sel) => list.map(([v, l]) => `<option value="${esc(v)}"${String(v) === String(sel) ? ' selected' : ''}>${esc(l)}</option>`).join('');
const userOptions = (sel, withNone = true) => (withNone ? '<option value="">— Niemand —</option>' : '') + options(activeUsers().map((u) => [u.id, u.name + (u.position ? ` · ${u.position}` : '')]), sel);
async function confirmBox(text, label = 'Löschen') {
  return new Promise((res) => {
    let done = false;
    const { d } = modal({ title: 'Bist du sicher?', body: `<p style="margin:6px 0 14px">${esc(text)}</p>`, submit: label, onSubmit: async () => { done = true; } });
    $('button[type=submit]', d).classList.add('danger');
    d.addEventListener('close', () => res(done));
  });
}

/* ============ Start ============ */
function applyTheme() {
  const t = localStorage.getItem('theme');
  if (t) document.documentElement.dataset.theme = t; else delete document.documentElement.dataset.theme;
}
function isDark() { return document.documentElement.dataset.theme === 'dark' || (!document.documentElement.dataset.theme && matchMedia('(prefers-color-scheme: dark)').matches); }

async function boot() {
  applyTheme();
  S.brand = await api('GET', '/api/branding').catch(() => ({}));
  try { S.me = await api('GET', '/api/me'); }
  catch {
    SETUP = await api('GET', '/api/setup').catch(() => ({ needed: false, local: false, registration: true }));
    const inv = /^#\/einladung\/([A-Za-z0-9]{4,12})$/.exec(location.hash);
    return SETUP.needed ? AUTH.setup() : inv ? AUTH.invite(inv[1].toUpperCase()) : AUTH.login();
  }
  S.users = await api('GET', '/api/users');
  await loadProjects().catch(() => { S.projects = []; });
  renderShell();
  window.addEventListener('hashchange', route);
  route();
  pollSummary();
  setInterval(pollSummary, 8000);
  if (S.me.must_change) forcePasswordModal();
}

/* ============ Anmeldung, Registrierung, Passwort vergessen ============ */
const EYE = '<path d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12Z"/><circle cx="12" cy="12" r="2.8"/>';
const pwField = (label, name, auto = 'new-password') => `<label class="f"><span>${esc(label)}</span><span class="pw"><input type="password" name="${name}" autocomplete="${auto}"><button type="button" class="icon-btn eye" tabindex="-1" aria-label="Passwort anzeigen"><svg class="ic" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${EYE}</svg></button></span></label>`;
document.addEventListener('click', (e) => { // Auge: Passwort ein-/ausblenden
  const b = e.target.closest('.eye'); if (!b) return;
  const i = b.parentElement.querySelector('input'); i.type = i.type === 'password' ? 'text' : 'password'; b.classList.toggle('on', i.type === 'text');
});
/** Rahmen für alle Bildschirme vor der Anmeldung. onSubmit darf werfen → Meldung wird angezeigt. */
function authView({ title, text, body, submit, links = '', wide = false, onSubmit }) {
  $('#app').innerHTML = `<div class="login"><form class="card login-card" id="af" novalidate style="${wide ? 'width:min(480px,100%)' : ''}">
    ${brandHtml(18)}
    <h1>${esc(title)}</h1><p>${text}</p>${body}
    <div class="err" id="le" hidden style="margin:0 0 12px"></div>
    ${submit ? `<button class="btn primary" type="submit">${esc(submit)}</button>` : ''}
    ${links ? `<div class="auth-links">${links}</div>` : ''}</form></div>`;
  const form = $('#af'), err = $('#le');
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = $('button[type=submit]', form); if (btn) btn.disabled = true; err.hidden = true;
    try { await onSubmit(new FormData(form)); } catch (er) { err.textContent = er.message; err.hidden = false; }
    if (btn) btn.disabled = false;
  });
  $$('[data-go]', form).forEach((a) => a.addEventListener('click', (e) => { e.preventDefault(); AUTH[a.dataset.go](); }));
  const first = $('input', form); if (first) first.focus();
}
const samePw = (fd) => { if (fd.get('password') !== fd.get('password2')) throw new Error('Die beiden Passwörter stimmen nicht überein'); return fd.get('password'); };
const loginAndEnter = async (username, password, hash = '#/') => { await api('POST', '/api/login', { username, password }); if (!location.hash.startsWith('#/stempeln/')) location.hash = hash; location.reload(); }; // nach dem Scannen eines QR-Codes: nach der Anmeldung gleich stempeln
let SETUP = { local: false, registration: true };
const AUTH = {
  login(msg = '') {
    authView({
      title: 'Willkommen zurück', text: 'Melde dich mit deinem Zugang an.', submit: 'Anmelden',
      body: `${msg ? `<div class="notice ok">${esc(msg)}</div>` : ''}${field('Benutzername oder E-Mail', '<input type="text" name="username" autocomplete="username">')}${pwField('Passwort', 'password', 'current-password')}`,
      links: `<a href="#" data-go="forgot">Passwort vergessen?</a>${SETUP.registration ? '<a href="#" data-go="register">Konto erstellen</a>' : ''}${SETUP.local ? '<a href="#" data-go="local" class="full">Dieser Computer ist der Hauptrechner · Administrator-Zugang wiederherstellen</a>' : ''}`,
      onSubmit: async (fd) => {
        try { await loginAndEnter(fd.get('username'), fd.get('password')); }
        catch (e) { if (e.data?.can_claim) return AUTH.claim(fd.get('username'), fd.get('password')); throw e; }
      },
    });
  },
  /** Am Hauptrechner: wartendes Konto selbst freischalten (wird Administrator). */
  claim(username, password) {
    authView({
      title: 'Konto freischalten', submit: 'Als Administrator freischalten und starten',
      text: `Dein Konto <b>${esc(username)}</b> ist angelegt. Weil du direkt am <b>Hauptrechner</b> sitzt, kannst du es selbst freischalten – du wirst Administrator und kannst danach deine Mitarbeiter einladen und freigeben.`,
      body: '<div class="notice ok">An den Arbeitsplätzen der Kollegen gibt es diese Möglichkeit nicht – dort gibt immer ein Administrator frei.</div>',
      links: '<a href="#" data-go="login">← Zurück zur Anmeldung</a>',
      onSubmit: async () => { await api('POST', '/api/local/claim', { username, password }); await loginAndEnter(username, password, '#/team'); },
    });
  },
  setup() {
    if (!SETUP.local && !SETUP.code_setup) {
      return authView({ title: 'Noch nicht eingerichtet', text: 'Das Portal wird gerade zum ersten Mal gestartet. Bitte richte es direkt am Hauptrechner ein – danach kannst du dich hier anmelden.', body: '', submit: 'Erneut versuchen', onSubmit: async () => location.reload() });
    }
    authView({
      title: 'Willkommen!', wide: true, submit: 'Konto anlegen und starten',
      text: 'Lege zuerst dein eigenes Konto an. Du wirst Administrator und kannst danach deine Mitarbeiter einladen.',
      body: `${SETUP.local ? '' : '<div class="notice">Dieser Server ist neu. Bisherige Daten übernimmst du am alten Hauptrechner unter <b>Einstellungen → Umzug auf einen Server</b> – dann hier nichts anlegen.</div>' + field('Einrichtungscode des Servers', '<input type="text" name="code" placeholder="XXXX-XXXX-XXXX" autocomplete="off" style="text-transform:uppercase;letter-spacing:.12em;font-weight:600">')}${field('Dein Name', '<input type="text" name="name" placeholder="Vor- und Nachname">')}
        <div class="row">${field('Benutzername', '<input type="text" name="username" placeholder="z. B. anna" autocomplete="username">')}${field('Position', '<input type="text" name="position" placeholder="z. B. Geschäftsführung">')}</div>
        ${field('E-Mail (optional)', '<input type="text" name="email" placeholder="name@firma.de" autocomplete="email">')}
        <div class="row">${pwField('Passwort (mind. 8 Zeichen)', 'password')}${pwField('Passwort wiederholen', 'password2')}</div>`,
      onSubmit: async (fd) => {
        const password = samePw(fd);
        await api('POST', '/api/setup', { name: fd.get('name'), username: fd.get('username'), position: fd.get('position'), email: fd.get('email'), password, code: fd.get('code') || undefined });
        await loginAndEnter(fd.get('username'), password, '#/team');
      },
    });
  },
  /** Einladungs-Link: am Computer das Programm verbinden, sonst gleich hier im Browser (Handy) weitermachen. */
  invite(code) {
    if (window.portalApp || !SETUP.registration) return AUTH.register(code);
    const host = location.host, secure = location.protocol === 'https:';
    authView({
      title: 'Du bist eingeladen', wide: true, body: '', text: `Willkommen bei <b>${esc((S.brand && S.brand.name) || 'unserem Betriebsportal')}</b>. Wie möchtest du das Portal benutzen?`,
      links: `<a class="btn primary" style="flex-basis:100%;justify-content:center;height:44px" href="#" id="inv-web">Hier weiter – am Handy oder im Browser</a>
        ${secure ? `<a class="btn" style="flex-basis:100%;justify-content:center;height:44px" href="betriebsportal://verbinden/${esc(host)}/${esc(code)}">Am Computer: mit dem Programm öffnen</a>
        <span class="full muted" style="font-size:13px">Das Programm ist noch nicht installiert? <a href="${esc(SETUP.releases || '#')}" target="_blank" rel="noopener">Hier herunterladen</a>, installieren und danach noch einmal auf diesen Einladungs-Link klicken – es verbindet sich dann von selbst.</span>` : ''}
        <a href="#" data-go="login" class="full">Ich habe schon ein Konto · Anmelden</a>`,
      onSubmit: async () => {},
    });
    $('#inv-web').addEventListener('click', (e) => { e.preventDefault(); AUTH.register(code); });
  },
  register(code = '') {
    authView({
      title: 'Konto erstellen', wide: true, submit: 'Registrieren',
      text: 'Mit dem Einladungscode deiner Firma kannst du sofort loslegen. Ohne Code gibt ein Administrator dein Konto frei.',
      body: `${field('Dein Name', '<input type="text" name="name" placeholder="Vor- und Nachname">')}
        <div class="row">${field('Benutzername', '<input type="text" name="username" placeholder="z. B. markus" autocomplete="username">')}${field('Position', '<input type="text" name="position" placeholder="z. B. Vertrieb">')}</div>
        ${field('E-Mail (optional)', '<input type="text" name="email" placeholder="name@firma.de" autocomplete="email">')}
        <div class="row">${pwField('Passwort (mind. 8 Zeichen)', 'password')}${pwField('Passwort wiederholen', 'password2')}</div>
        ${field('Einladungscode (falls vorhanden)', `<input type="text" name="code" value="${esc(typeof code === 'string' ? code : '')}" placeholder="z. B. K7M29Q" autocomplete="off" style="text-transform:uppercase;letter-spacing:.12em">`)}`,
      links: '<a href="#" data-go="login">← Zurück zur Anmeldung</a>',
      onSubmit: async (fd) => {
        const password = samePw(fd);
        const r = await api('POST', '/api/register', { name: fd.get('name'), username: fd.get('username'), position: fd.get('position'), email: fd.get('email'), code: fd.get('code'), password });
        if (r.status === 'active') return loginAndEnter(fd.get('username'), password);
        if (r.can_claim) return AUTH.claim(fd.get('username'), password);
        authView({ title: 'Fast geschafft', submit: 'Zur Anmeldung', body: '',
          text: `Dein Konto wurde angelegt und wartet jetzt auf die Freigabe durch ${r.admins.length ? `<b>${esc(r.admins.join(' oder '))}</b>` : 'einen Administrator'}. Danach kannst du dich mit deinem Benutzernamen und Passwort anmelden.`,
          onSubmit: async () => AUTH.login() });
      },
    });
  },
  forgot() {
    authView({
      title: 'Passwort vergessen', submit: 'Rücksetzung anfordern',
      text: 'Gib deinen Benutzernamen ein. Dein Administrator wird benachrichtigt und gibt dir einen Einmal-Code, mit dem du ein neues Passwort festlegst.',
      body: field('Benutzername oder E-Mail', '<input type="text" name="username" autocomplete="username">'),
      links: `<a href="#" data-go="login">← Zurück zur Anmeldung</a><a href="#" data-go="code">Ich habe schon einen Code</a>${SETUP.local ? '<a href="#" data-go="local" class="full">Du bist Administrator und sitzt am Hauptrechner? Passwort hier direkt zurücksetzen</a>' : ''}`,
      onSubmit: async (fd) => {
        if (!String(fd.get('username')).trim()) throw new Error('Bitte gib deinen Benutzernamen ein');
        const r = await api('POST', '/api/password/request', { username: fd.get('username') });
        AUTH.code(fd.get('username'), r.admins);
      },
    });
  },
  code(username = '', admins = null) {
    authView({
      title: 'Neues Passwort festlegen', submit: 'Passwort speichern und anmelden',
      text: admins ? `Die Anfrage ist raus. ${admins.length ? `<b>${esc(admins.join(' oder '))}</b>` : 'Dein Administrator'} sieht sie im Portal und gibt dir einen Einmal-Code (24 Stunden gültig).` : 'Gib den Einmal-Code ein, den du von deinem Administrator bekommen hast.',
      body: `${field('Benutzername oder E-Mail', `<input type="text" name="username" value="${esc(username)}" autocomplete="username">`)}
        ${field('Einmal-Code', '<input type="text" name="code" placeholder="XXXX-XXXX" autocomplete="off" style="text-transform:uppercase;letter-spacing:.14em;font-weight:600">')}
        ${pwField('Neues Passwort (mind. 8 Zeichen)', 'password')}${pwField('Neues Passwort wiederholen', 'password2')}`,
      links: '<a href="#" data-go="login">← Zurück zur Anmeldung</a>',
      onSubmit: async (fd) => {
        const password = samePw(fd);
        await api('POST', '/api/password/reset', { username: fd.get('username'), code: fd.get('code'), password });
        await loginAndEnter(fd.get('username'), password);
      },
    });
    if (username) $('[name=code]').focus();
  },
  async local() {
    let admins = [];
    try { admins = await api('GET', '/api/local/admins'); } catch (e) { return AUTH.login(); }
    authView({
      title: 'Administrator-Passwort zurücksetzen', submit: 'Passwort speichern und anmelden',
      text: 'Das geht nur direkt an diesem Computer (dem Hauptrechner). Wähle dein Administrator-Konto und vergib ein neues Passwort.',
      body: `${field('Administrator-Konto', `<select name="user_id">${admins.map((a) => `<option value="${a.id}">${esc(a.name)} (${esc(a.username)})</option>`).join('')}</select>`)}
        ${pwField('Neues Passwort (mind. 8 Zeichen)', 'password')}${pwField('Neues Passwort wiederholen', 'password2')}`,
      links: '<a href="#" data-go="login">← Zurück zur Anmeldung</a>',
      onSubmit: async (fd) => {
        const password = samePw(fd);
        const r = await api('POST', '/api/local/reset', { user_id: Number(fd.get('user_id')), password });
        await loginAndEnter(r.username, password);
      },
    });
  },
};
/** Nach einem Start- oder Rücksetz-Passwort: erst ein eigenes Passwort vergeben. */
function forcePasswordModal() {
  modal({
    title: 'Bitte vergib dein eigenes Passwort', submit: 'Passwort speichern', locked: true,
    body: `<p class="muted" style="margin:0 0 14px">Du hast dich mit einem Passwort angemeldet, das dir jemand anderes gegeben hat. Lege jetzt ein eigenes fest, das nur du kennst.</p>${pwField('Neues Passwort (mind. 8 Zeichen)', 'password')}${pwField('Neues Passwort wiederholen', 'password2')}`,
    onSubmit: async (fd) => { await api('POST', '/api/me/password', { password: samePw(fd) }); S.me.must_change = false; toast('Passwort gespeichert'); },
  });
}

const NAV = [['', 'Übersicht', 'home'], ['aufgaben', 'Aufgaben', 'tasks'], ['nachrichten', 'Nachrichten', 'chat'], ['kalender', 'Kalender', 'cal'], ['dateien', 'Dateien', 'folder'], ['team', 'Team', 'team']];
function renderShell() {
  $('#app').innerHTML = `<div class="app">
    <div class="topbar">${brandHtml(16)}<button class="icon-btn" id="tb-menu" aria-label="Menü">${avatar(S.me, 30)}</button></div>
    <aside class="side">
      ${brandHtml(16)}
      <nav class="nav">${NAV.filter((n) => !n[3] || S.me.role === 'admin').map(([h, l, i]) => `<a href="#/${h}" data-nav="${h}">${icon(i, 20)}<span>${l}</span>${h === 'nachrichten' ? '<span class="badge" id="badge" hidden></span>' : h === 'team' ? '<span class="badge" id="tbadge" hidden></span>' : ''}</a>`).join('')}</nav>
      <div class="me"><button class="me-btn" id="me-btn">${avatar(S.me, 34)}<span><b>${esc(S.me.name)}</b><small>${esc(S.me.position || (S.me.role === 'admin' ? 'Administrator' : 'Mitarbeiter'))}</small></span></button></div>
    </aside>
    <main class="main" id="main"></main></div>`;
  const openMenu = (anchor) => {
    const old = $('.menu'); if (old) { old.remove(); return; }
    const m = document.createElement('div'); m.className = 'menu';
    m.innerHTML = `<div class="ver">Version ${esc(S.version || '')}</div><button data-a="pw">${icon('edit')}Mein Profil & Passwort</button><button data-a="theme">${icon('moon')}${isDark() ? 'Helles Design' : 'Dunkles Design'}</button><button data-a="sound">${icon('bell')}Ton bei Nachrichten: ${soundOn() ? 'an' : 'aus'}</button><hr><button data-a="out">${icon('out')}Abmelden</button>`;
    if (anchor === 'top') Object.assign(m.style, { position: 'fixed', top: '54px', right: '12px', left: 'auto', bottom: 'auto', width: '220px' });
    (anchor === 'top' ? document.body : $('.me')).appendChild(m);
    m.addEventListener('click', async (e) => {
      const a = e.target.closest('button')?.dataset.a; if (!a) return;
      m.remove();
      if (a === 'out') { await api('POST', '/api/logout'); location.reload(); }
      if (a === 'theme') { localStorage.setItem('theme', isDark() ? 'light' : 'dark'); applyTheme(); }
      if (a === 'pw') profileModal();
      if (a === 'sound') { const on = !soundOn(); try { localStorage.setItem('sound', on ? 'on' : 'off'); } catch { /* egal */ } if (on) chime(); toast(on ? 'Ton eingeschaltet' : 'Ton ausgeschaltet'); try { if (window.portalApp && portalApp.prefs) portalApp.prefs({ sound: on }); } catch { /* egal */ } }
    });
    setTimeout(() => document.addEventListener('click', function h(ev) { if (!m.contains(ev.target)) { m.remove(); document.removeEventListener('click', h); } }), 0);
  };
  $('#me-btn').addEventListener('click', (e) => { e.stopPropagation(); openMenu('side'); });
  $('#tb-menu').addEventListener('click', (e) => { e.stopPropagation(); openMenu('top'); });
}
async function pollSummary() {
  try {
    const sum = await api('GET', '/api/summary'), { unread, version, update, todo, latest } = sum;
    if (typeof timeSummary === 'function') timeSummary(sum);
    const tb = $('#tbadge'); if (tb) { if (todo > (S.todo || 0)) toast('Neue Anfrage im Bereich Team'); S.todo = todo; tb.textContent = todo; tb.hidden = !todo; }
    if (S.version && version !== S.version) { // Server wurde aktualisiert → neue Oberfläche laden
      if (!$('dialog[open]')) { location.reload(); return; }
      if (!S.reloadHint) { S.reloadHint = true; toast('Neue Version installiert – bitte Seite neu laden'); }
    }
    S.version = version; paintUpdate(update);
    notifyMessage(unread, latest, S.unread === null);
    S.unread = unread; paintBadge();
  } catch { /* offline */ }
}
function paintUpdate(v) {
  let box = $('#upd');
  if (!v) { if (box) box.remove(); return; }
  if (box && box.dataset.v === v) return;
  if (box) box.remove();
  box = document.createElement('div'); box.id = 'upd'; box.className = 'upd'; box.dataset.v = v;
  box.innerHTML = `<b>Update ${esc(v)} bereit</b><span>Dauert nur wenige Sekunden.</span><button class="btn primary sm">Jetzt installieren</button>`;
  $('.me').before(box);
  $('button', box).onclick = guard(() => runUpdate(v));
}
function paintBadge() {
  const b = $('#badge'); if (b) { b.textContent = S.unread; b.hidden = !S.unread; }
  document.title = (S.unread ? `(${S.unread}) ` : '') + 'Betriebsportal';
}
const currentPage = () => (location.hash.replace(/^#\/?/, '').split('/')[0] || '');

const PAGES = { '': pageDashboard, aufgaben: pageTasks, nachrichten: pageMessages, kalender: pageCalendar, dateien: pageFiles, team: pageTeam };
async function route() {
  S.cleanup.forEach((f) => f()); S.cleanup = [];
  const p = currentPage();
  $$('[data-nav]').forEach((a) => a.classList.toggle('on', a.dataset.nav === (PAGES[p] ? p : '')));
  const main = $('#main'); main.scrollTop = 0;
  try { await (PAGES[p] || pageDashboard)(main); } catch (e) { main.innerHTML = `<div class="page"><div class="empty">${esc(e.message)}</div></div>`; }
}
const refresh = () => route();

/* ============ Übersicht ============ */
async function pageDashboard(main) {
  const t0 = todayStr();
  const [tasks, events, convs, files] = await Promise.all([
    api('GET', '/api/tasks'), api('GET', `/api/events?from=${t0}&to=${addDays(t0, 14)}`), api('GET', '/api/conversations'), api('GET', '/api/files'),
  ]);
  const mine = tasks.filter((t) => t.assignee_id === S.me.id && t.status !== 'done');
  const sorted = [...mine].sort((a, b) => (a.due || '9') .localeCompare(b.due || '9') || ({ high: 0, normal: 1, low: 2 }[a.priority] - { high: 0, normal: 1, low: 2 }[b.priority]));
  const late = mine.filter((t) => t.due && t.due < t0).length;
  const todayEv = events.filter((e) => e.date_start <= t0 && e.date_end >= t0);
  const unread = convs.reduce((n, c) => n + c.unread, 0);
  const h = new Date().getHours();
  const greet = h < 11 ? 'Guten Morgen' : h < 18 ? 'Guten Tag' : 'Guten Abend';

  // Termine nach Tag gruppieren
  const days = {};
  for (const e of events) for (let d = e.date_start < t0 ? t0 : e.date_start; d <= e.date_end && d <= addDays(t0, 14); d = addDays(d, 1)) (days[d] ||= []).push(e);
  const dayKeys = Object.keys(days).sort().slice(0, 6);

  const openCounts = (id) => tasks.filter((t) => t.assignee_id === id && t.status !== 'done').length;
  const maxOpen = Math.max(1, ...activeUsers().map((u) => openCounts(u.id)));
  const recentConvs = convs.filter((c) => c.last).sort((a, b) => b.last.created_at.localeCompare(a.last.created_at)).slice(0, 4);

  main.innerHTML = `<div class="page">
    <div class="page-head"><div><h1>${greet}, ${esc(firstName(S.me))}</h1><p>${fmtLong(t0)}</p></div>
      <div class="actions"><button class="btn" id="n-ev">${icon('cal', 16)}Termin</button><button class="btn primary" id="n-task">${icon('plus', 16)}Neue Aufgabe</button></div></div>
    <div class="stats">
      <a class="card stat" href="#/aufgaben"><span class="ico">${icon('tasks', 22)}</span><span><b>${mine.length}</b><small>Meine offenen Aufgaben</small></span></a>
      <a class="card stat ${late ? 'late' : 'ok'}" href="#/aufgaben"><span class="ico">${icon(late ? 'alert' : 'check', 22)}</span><span><b>${late}</b><small>${late === 1 ? 'Überfällig' : 'Überfällig'}</small></span></a>
      <a class="card stat warn" href="#/kalender"><span class="ico">${icon('cal', 22)}</span><span><b>${todayEv.length}</b><small>Termine heute</small></span></a>
      <a class="card stat" href="#/nachrichten"><span class="ico">${icon('chat', 22)}</span><span><b>${unread}</b><small>Ungelesene Nachrichten</small></span></a>
    </div>
    <div class="grid2">
      <div class="stack">
        <section class="card"><div class="card-h"><h3>Meine Aufgaben</h3><a href="#/aufgaben">Alle ansehen</a></div><div class="card-b">
          ${sorted.length ? sorted.slice(0, 8).map((t) => `<div class="li" data-task="${t.id}"><button class="circle" data-done="${t.id}" title="Als erledigt markieren">${icon('check', 13)}</button>
            <div class="t"><b>${esc(t.title)}</b>${t.priority === 'high' ? '<small style="color:var(--danger)">Hohe Priorität</small>' : ''}</div>${dueChip(t.due, t.status)}</div>`).join('')
            : `<div class="empty">${icon('check', 28)}Alles erledigt – keine offenen Aufgaben.</div>`}
        </div></section>
        <section class="card"><div class="card-h"><h3>Team-Auslastung</h3><a href="#/team">Team</a></div><div class="card-b">
          ${activeUsers().map((u) => `<a class="li" href="#/aufgaben" data-person="${u.id}" style="text-decoration:none;color:inherit">${avatar(u, 34)}<div class="t"><b>${esc(u.name)}</b><small>${esc(u.position || '—')}</small></div>
            <span class="muted" style="font-size:13px">${openCounts(u.id)} offen</span><span class="bar"><i style="width:${(openCounts(u.id) / maxOpen) * 100}%"></i></span></a>`).join('')}
        </div></section>
      </div>
      <div class="stack">
        <section class="card"><div class="card-h"><h3>Anstehende Termine</h3><a href="#/kalender">Kalender</a></div><div class="card-b">
          ${dayKeys.length ? dayKeys.map((d) => `<div class="daylabel">${d === t0 ? 'Heute' : d === addDays(t0, 1) ? 'Morgen' : fmtShort(d)}</div>${days[d].map((e) => `<div class="li k-${esc(e.kind)}" data-event="${e.id}"><span class="dot"></span><div class="t"><b>${esc(e.title)}</b><small>${e.time_start ? e.time_start + (e.time_end ? '–' + e.time_end : '') + ' Uhr' : 'Ganztägig'}${e.attendees.length ? ' · ' + e.attendees.length + ' Teilnehmer' : ''}</small></div></div>`).join('')}`).join('')
            : `<div class="empty">${icon('cal', 28)}In den nächsten 14 Tagen stehen keine Termine an.</div>`}
        </div></section>
        <section class="card"><div class="card-h"><h3>Nachrichten</h3><a href="#/nachrichten">Öffnen</a></div><div class="card-b">
          ${recentConvs.length ? recentConvs.map((c) => { const u = c.key === 'all' ? null : userById(+c.key); const l = c.last; const sender = userById(l.sender_id);
            return `<a class="li" href="#/nachrichten" data-conv="${c.key}" style="text-decoration:none;color:inherit">${c.key === 'all' ? `<span class="hash" style="--s:34px">${icon('hash', 17)}</span>` : avatar(u, 34)}
            <div class="t"><b>${c.key === 'all' ? 'Alle Mitarbeiter' : esc(u?.name)}</b><small>${l.sender_id === S.me.id ? 'Du: ' : c.key === 'all' ? esc(firstName(sender)) + ': ' : ''}${esc(l.body || l.file_name || '')}</small></div>${c.unread ? `<span class="badge">${c.unread}</span>` : `<span class="muted" style="font-size:12px">${fmtTime(l.created_at)}</span>`}</a>`; }).join('')
            : `<div class="empty">${icon('inbox', 28)}Noch keine Nachrichten.</div>`}
        </div></section>
        <section class="card"><div class="card-h"><h3>Neueste Dateien</h3><a href="#/dateien">Alle Dateien</a></div><div class="card-b">
          ${files.length ? files.slice(0, 4).map((f) => `<a class="li" href="/api/files/${f.id}/download" data-fname="${esc(f.name)}" data-fsize="${f.size}" style="text-decoration:none;color:inherit"><span class="ft">${esc(ext(f.name))}</span><div class="t"><b>${esc(f.name)}</b><small>${esc(userById(f.uploader_id)?.name || '')} · ${fmtSize(f.size)}</small></div></a>`).join('')
            : `<div class="empty">${icon('folder', 28)}Noch keine Dateien hochgeladen.</div>`}
        </div></section>
      </div>
    </div></div>`;
  $('#n-task').onclick = () => taskModal();
  $('#n-ev').onclick = () => eventModal({ date_start: t0 });
  $$('[data-task]', main).forEach((el) => el.addEventListener('click', (e) => { if (e.target.closest('[data-done]')) return; taskModal(tasks.find((t) => t.id === +el.dataset.task)); }));
  $$('[data-done]', main).forEach((b) => b.addEventListener('click', guard(async () => { await api('PUT', `/api/tasks/${b.dataset.done}`, { status: 'done' }); toast('Aufgabe erledigt'); refresh(); })));
  $$('[data-event]', main).forEach((el) => el.addEventListener('click', () => eventModal(events.find((e) => e.id === +el.dataset.event))));
  $$('[data-person]', main).forEach((el) => el.addEventListener('click', () => { S.taskFilter = 'all'; S.taskPerson = el.dataset.person; }));
  $$('[data-conv]', main).forEach((el) => el.addEventListener('click', () => { S.conv = el.dataset.conv; }));
}
const ext = (n) => { const m = /\.([a-z0-9]{1,5})$/i.exec(n); return m ? m[1] : 'Datei'.slice(0, 3); };

/* ============ Aufgaben ============ */
const STATUS = [['open', 'Offen'], ['progress', 'In Arbeit'], ['done', 'Erledigt']];
const PRIO = [['low', 'Niedrig'], ['normal', 'Normal'], ['high', 'Hoch']];

function taskModal(task, defaults = {}) {
  const isNew = !task;
  const t = task || { title: '', description: '', status: 'open', priority: 'normal', assignee_id: S.me.id, due: '', ...defaults };
  const canEdit = isNew || S.me.role === 'admin' || t.creator_id === S.me.id || t.assignee_id === S.me.id;
  const canDelete = !isNew && (S.me.role === 'admin' || t.creator_id === S.me.id);
  const creator = userById(t.creator_id);
  const { d } = modal({
    title: isNew ? 'Neue Aufgabe' : 'Aufgabe', readonly: !canEdit, submit: isNew ? 'Aufgabe erstellen' : 'Speichern',
    extra: canDelete ? `<button type="button" class="btn danger" id="del">${icon('trash', 16)}Löschen</button>` : '',
    body: `<fieldset ${canEdit ? '' : 'disabled'} style="border:0;padding:0;margin:0;min-width:0">
      ${field('Titel', `<input type="text" name="title" value="${esc(t.title)}" maxlength="200" placeholder="Was ist zu tun?">`)}
      ${field('Beschreibung', `<textarea name="description" placeholder="Details, Hinweise, Links …">${esc(t.description)}</textarea>`)}
      <div class="row">${field('Zuständig', `<select name="assignee_id">${userOptions(t.assignee_id)}</select>`)}${field('Fällig am', `<input type="date" name="due" value="${esc(t.due || '')}">`)}</div>
      <div class="row">${field('Status', `<select name="status">${options(STATUS, t.status)}</select>`)}${field('Priorität', `<select name="priority">${options(PRIO, t.priority)}</select>`)}</div>
      ${field('Projekt', `<select name="project_id"><option value="">— Kein Projekt —</option>${options((S.projects || []).filter((p) => p.status === 'active' || p.id === t.project_id).map((p) => [p.id, `${p.number} · ${p.name}`]), t.project_id || '')}</select>`)}</fieldset>
      ${!isNew ? `<p class="muted" style="margin:0 0 10px;font-size:12.5px">Erstellt von ${esc(creator?.name || 'unbekannt')} am ${new Date(t.created_at).toLocaleDateString('de-DE')}</p>` : ''}`,
    onSubmit: async (fd) => {
      const body = { title: fd.get('title'), description: fd.get('description'), assignee_id: fd.get('assignee_id') || null, due: fd.get('due') || null, status: fd.get('status'), priority: fd.get('priority'), project_id: fd.get('project_id') || null };
      if (isNew) await api('POST', '/api/tasks', body); else await api('PUT', `/api/tasks/${t.id}`, body);
      toast(isNew ? 'Aufgabe erstellt' : 'Gespeichert'); refresh();
    },
  });
  const del = $('#del', d);
  if (del) del.onclick = async () => { if (await confirmBox(`„${t.title}“ wird endgültig gelöscht.`)) { await guard(() => api('DELETE', `/api/tasks/${t.id}`))(); d.close(); refresh(); } };
}

async function pageTasks(main) {
  const tasks = await api('GET', '/api/tasks');
  const render = () => {
    const q = S.taskQ.toLowerCase();
    let list = tasks.filter((t) => (S.taskFilter === 'mine' ? t.assignee_id === S.me.id : S.taskFilter === 'created' ? t.creator_id === S.me.id : true)
      && (!S.taskPerson || String(t.assignee_id) === S.taskPerson)
      && (!q || t.title.toLowerCase().includes(q) || t.description.toLowerCase().includes(q)));
    const pr = { high: 0, normal: 1, low: 2 };
    const cmp = (a, b) => (a.due || '9').localeCompare(b.due || '9') || pr[a.priority] - pr[b.priority] || b.id - a.id;
    $('#board').innerHTML = STATUS.map(([k, label]) => {
      const col = list.filter((t) => t.status === k).sort(k === 'done' ? (a, b) => (b.done_at || '').localeCompare(a.done_at || '') : cmp);
      return `<div class="col" data-status="${k}"><div class="col-h"><span>${label}</span><span class="n">${col.length}</span></div>
        ${col.map((t) => `<div class="tcard ${t.status === 'done' ? 'is-done' : ''}" draggable="true" data-id="${t.id}"><span class="prio ${t.priority}"></span>
          <div class="top"><button class="circle ${t.status === 'done' ? 'done' : ''}" data-toggle="${t.id}" title="${t.status === 'done' ? 'Wieder öffnen' : 'Erledigt'}">${icon('check', 13)}</button><div class="ttl">${esc(t.title)}</div></div>
          ${t.description ? `<div class="desc">${esc(t.description)}</div>` : ''}
          <div class="meta">${dueChip(t.due, t.status)}${t.priority === 'high' && t.status !== 'done' ? '<span class="chip late">Hoch</span>' : ''}<span class="who">${avatar(userById(t.assignee_id), 22)}${esc(firstName(userById(t.assignee_id)))}</span></div></div>`).join('') || `<div class="col-empty">Keine Aufgaben</div>`}</div>`;
    }).join('');
    bindBoard();
  };
  const bindBoard = () => {
    $$('.tcard').forEach((el) => {
      el.addEventListener('click', (e) => { if (e.target.closest('[data-toggle]')) return; taskModal(tasks.find((t) => t.id === +el.dataset.id)); });
      el.addEventListener('dragstart', (e) => { e.dataTransfer.setData('text/plain', el.dataset.id); e.dataTransfer.effectAllowed = 'move'; setTimeout(() => el.classList.add('dragging'), 0); });
      el.addEventListener('dragend', () => el.classList.remove('dragging'));
    });
    $$('[data-toggle]').forEach((b) => b.addEventListener('click', guard(async () => {
      const t = tasks.find((x) => x.id === +b.dataset.toggle);
      await api('PUT', `/api/tasks/${t.id}`, { status: t.status === 'done' ? 'open' : 'done' }); refresh();
    })));
    $$('.col').forEach((col) => {
      col.addEventListener('dragover', (e) => { e.preventDefault(); col.classList.add('over'); });
      col.addEventListener('dragleave', (e) => { if (!col.contains(e.relatedTarget)) col.classList.remove('over'); });
      col.addEventListener('drop', guard(async (e) => {
        e.preventDefault(); col.classList.remove('over');
        const t = tasks.find((x) => x.id === +e.dataTransfer.getData('text/plain'));
        if (!t || t.status === col.dataset.status) return;
        await api('PUT', `/api/tasks/${t.id}`, { status: col.dataset.status }); refresh();
      }));
    });
  };
  const counts = { mine: tasks.filter((t) => t.assignee_id === S.me.id && t.status !== 'done').length };
  main.innerHTML = `<div class="page"><div class="page-head"><div><h1>Aufgaben</h1><p>Wer macht was bis wann – ziehe Karten, um den Status zu ändern.</p></div>
    <div class="actions"><button class="btn primary" id="new">${icon('plus', 16)}Neue Aufgabe</button></div></div>
    <div class="toolbar"><div class="seg" id="seg">${[['mine', `Meine (${counts.mine})`], ['created', 'Von mir erstellt'], ['all', 'Alle']].map(([k, l]) => `<button data-f="${k}" class="${S.taskFilter === k ? 'on' : ''}">${l}</button>`).join('')}</div>
      <select id="person" aria-label="Person"><option value="">Alle Personen</option>${activeUsers().map((u) => `<option value="${u.id}" ${S.taskPerson === String(u.id) ? 'selected' : ''}>${esc(u.name)}</option>`).join('')}</select>
      <div class="search">${icon('search', 16)}<input type="search" id="q" placeholder="Aufgaben suchen …" value="${esc(S.taskQ)}"></div></div>
    <div class="board" id="board"></div></div>`;
  $('#new').onclick = () => taskModal();
  $$('#seg button').forEach((b) => b.onclick = () => { S.taskFilter = b.dataset.f; $$('#seg button').forEach((x) => x.classList.toggle('on', x === b)); render(); });
  $('#person').onchange = (e) => { S.taskPerson = e.target.value; render(); };
  $('#q').oninput = (e) => { S.taskQ = e.target.value; render(); };
  render();
}

/* ============ Nachrichten ============ */
function convHeader(key) {
  if (key === 'all') return { name: 'Alle Mitarbeiter', sub: 'Nachrichten an das gesamte Team', av: `<span class="hash">${icon('hash', 18)}</span>` };
  const u = userById(+key); return { name: u?.name || '?', sub: u?.position || '', av: avatar(u, 36) };
}
async function pageMessages(main) {
  S.users = await api('GET', '/api/users'); // frisch laden: neue Kollegen sollen sofort als Unterhaltung erscheinen
  let lastId = 0, pendingFile = null;
  main.innerHTML = `<div class="page chat-page" style="max-width:1240px"><div class="page-head" style="margin-bottom:16px"><div><h1>Nachrichten</h1></div></div>
    <div class="card chat" id="chat"><div class="convs" id="convs"></div>
    <div class="thread"><div class="thread-h" id="th"></div><div class="msgs" id="msgs"></div><div class="attach-row" id="att" hidden></div>
    <form class="composer" id="cf"><button type="button" class="icon-btn" id="clip" title="Datei anhängen">${icon('clip', 20)}</button><input type="file" id="fi" hidden>
    <textarea id="ta" rows="1" placeholder="Nachricht schreiben …" title="Enter = senden, Umschalt+Enter = neue Zeile"></textarea><button class="send" title="Senden">${icon('send', 19)}</button></form></div></div></div>`;
  const msgsEl = $('#msgs');

  const loadConvs = async () => {
    const convs = await api('GET', '/api/conversations');
    const order = [...convs].sort((a, b) => (a.key === 'all' ? -1 : b.key === 'all' ? 1 : (b.last?.created_at || '').localeCompare(a.last?.created_at || '') || (userById(+a.key)?.name || '').localeCompare(userById(+b.key)?.name || '')));
    S.unread = convs.reduce((n, c) => n + c.unread, 0); paintBadge();
    $('#convs').innerHTML = order.map((c) => {
      const h = convHeader(c.key); const l = c.last;
      const prefix = !l ? '' : l.sender_id === S.me.id ? 'Du: ' : c.key === 'all' ? firstName(userById(l.sender_id)) + ': ' : '';
      return `<div class="conv ${S.conv === c.key ? 'on' : ''} ${c.unread ? 'unread' : ''}" data-k="${c.key}">${h.av}<div class="t"><b><span>${esc(h.name)}</span>${l ? `<span class="time">${fmtTime(l.created_at)}</span>` : ''}</b>
        <small>${l ? esc(prefix + (l.body || '📎 ' + l.file_name)) : esc(h.sub || 'Noch keine Nachrichten')}</small></div>${c.unread ? `<span class="badge">${c.unread}</span>` : ''}</div>`;
    }).join('');
    $$('.conv').forEach((el) => el.onclick = () => { S.conv = el.dataset.k; $('#chat').classList.add('open'); openConv(); loadConvs(); });
  };

  const bubble = (m, prev) => {
    const mine = m.sender_id === S.me.id, u = userById(m.sender_id);
    const cont = prev && prev.sender_id === m.sender_id && ymd(new Date(prev.created_at)) === ymd(new Date(m.created_at));
    const head = !mine && S.conv === 'all' && !cont;
    return `<div class="m ${mine ? 'me' : ''} ${cont ? 'cont' : 'gap'}">${mine ? '' : (cont ? `<span class="av ph" style="--s:28px"></span>` : avatar(u, 28))}
      <div class="bub">${head ? `<div class="who">${esc(u?.name || 'Gelöscht')}</div>` : ''}${m.body ? `<div class="txt">${esc(m.body)}</div>` : ''}
      ${m.file_id ? `<a class="file-chip" href="/api/files/${m.file_id}/download" data-fname="${esc(m.file_name || '')}" data-fsize="${m.file_size || 0}"><span class="ft" style="width:32px;height:32px">${esc(ext(m.file_name || ''))}</span><span><b>${esc(m.file_name)}</b><small>${fmtSize(m.file_size || 0)} · ${canPreview(m.file_name || '') ? 'öffnen' : 'herunterladen'}</small></span></a>` : ''}
      <div class="ts">${fmtClock(m.created_at)}</div></div></div>`;
  };
  let all = [];
  const paint = () => {
    let html = '', lastDay = null, prev = null;
    all.forEach((m) => {
      const day = ymd(new Date(m.created_at));
      if (day !== lastDay) { html += `<div class="dsep">${day === todayStr() ? 'Heute' : fmtLong(day)}</div>`; lastDay = day; prev = null; }
      html += bubble(m, prev); prev = m;
    });
    if (!all.length) html = `<div class="empty" style="margin:auto">${icon('chat', 30)}Noch keine Nachrichten – schreib die erste.</div>`;
    msgsEl.innerHTML = html;
    msgsEl.scrollTop = msgsEl.scrollHeight;
  };
  const openConv = guard(async () => {
    const h = convHeader(S.conv);
    $('#th').innerHTML = `<button class="icon-btn back" id="back" aria-label="Zurück">${icon('left', 20)}</button>${h.av}<div><b>${esc(h.name)}</b><small>${esc(h.sub)}</small></div>`;
    $('#back').onclick = () => $('#chat').classList.remove('open');
    all = await api('GET', `/api/messages?with=${S.conv}`);
    lastId = all.length ? all[all.length - 1].id : 0;
    paint();
    api('POST', '/api/messages/read', { with: S.conv }).then(loadConvs).catch(() => {});
    $('#ta').focus({ preventScroll: true });
  });
  const poll = async () => {
    try {
      const key = S.conv;
      const fresh = await api('GET', `/api/messages?with=${key}&after=${lastId}`);
      if (key !== S.conv) return;
      if (fresh.length) {
        const wasEmpty = !all.length;
        const prevLast = all[all.length - 1];
        all = all.concat(fresh); lastId = all[all.length - 1].id;
        if (wasEmpty) paint(); else paintAppend(fresh, prevLast);
        api('POST', '/api/messages/read', { with: S.conv }).catch(() => {});
      }
      loadConvs();
    } catch { /* offline */ }
  };
  const paintAppend = (fresh, prev) => {
    const stick = msgsEl.scrollHeight - msgsEl.scrollTop - msgsEl.clientHeight < 120;
    let html = '', lastDay = prev ? ymd(new Date(prev.created_at)) : null;
    fresh.forEach((m, i) => {
      const day = ymd(new Date(m.created_at));
      if (day !== lastDay) { html += `<div class="dsep">${day === todayStr() ? 'Heute' : fmtLong(day)}</div>`; lastDay = day; prev = null; }
      html += bubble(m, i === 0 ? prev : fresh[i - 1]);
    });
    msgsEl.insertAdjacentHTML('beforeend', html);
    if (stick || fresh.some((m) => m.sender_id === S.me.id)) msgsEl.scrollTop = msgsEl.scrollHeight;
  };
  const timer = setInterval(poll, 3500); S.cleanup.push(() => clearInterval(timer));

  const ta = $('#ta');
  ta.addEventListener('input', () => { ta.style.height = 'auto'; ta.style.height = Math.min(ta.scrollHeight, 160) + 'px'; });
  ta.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); $('#cf').requestSubmit(); } });
  $('#clip').onclick = () => $('#fi').click();
  const showPending = () => {
    const a = $('#att'); a.hidden = !pendingFile;
    a.innerHTML = pendingFile ? `<span class="chip accent" style="height:28px">${icon('clip', 14)}${esc(pendingFile.name)} · ${fmtSize(pendingFile.size)}<button type="button" class="icon-btn" style="width:20px;height:20px" id="rm" aria-label="Anhang entfernen">${icon('x', 14)}</button></span>` : '';
    if (pendingFile) $('#rm').onclick = () => { pendingFile = null; showPending(); };
  };
  $('#fi').onchange = guard(async (e) => {
    const f = e.target.files[0]; e.target.value = ''; if (!f) return;
    toast('Datei wird hochgeladen …');
    pendingFile = await uploadFile(f, { ctx: 'message' }); showPending();
  });
  $('#cf').addEventListener('submit', guard(async (e) => {
    e.preventDefault();
    const body = ta.value.trim();
    if (!body && !pendingFile) return;
    await api('POST', '/api/messages', { to: S.conv, body, file_id: pendingFile?.id ?? null });
    ta.value = ''; ta.style.height = 'auto'; pendingFile = null; showPending();
    await poll();
  }));
  if (S.conv !== 'all' && !userById(+S.conv)) S.conv = 'all';
  await loadConvs();
  if (S.conv !== 'all' || innerWidth > 860) await openConv();
  if (S.conv !== 'all') $('#chat').classList.add('open');
}
async function uploadFile(file, { ctx = 'files', note = '' } = {}) {
  const r = await fetch(`/api/files?name=${encodeURIComponent(file.name)}&ctx=${ctx}&note=${encodeURIComponent(note)}`, { method: 'POST', headers: { 'Content-Type': 'application/octet-stream' }, body: file });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(data.error || 'Upload fehlgeschlagen');
  return data;
}

/* ============ Kalender ============ */
const KINDS = [['meeting', 'Besprechung'], ['absence', 'Abwesenheit'], ['deadline', 'Frist'], ['other', 'Sonstiges']];
function eventModal(ev) {
  const isNew = !ev?.id;
  const e = { title: '', description: '', kind: 'meeting', date_start: todayStr(), date_end: '', time_start: '', time_end: '', attendees: [], ...ev };
  const canEdit = isNew || S.me.role === 'admin' || e.creator_id === S.me.id;
  const { d } = modal({
    title: isNew ? 'Neuer Termin' : 'Termin', readonly: !canEdit, submit: isNew ? 'Termin erstellen' : 'Speichern',
    extra: !isNew && canEdit ? `<button type="button" class="btn danger" id="del">${icon('trash', 16)}Löschen</button>` : '',
    body: `<fieldset ${canEdit ? '' : 'disabled'} style="border:0;padding:0;margin:0;min-width:0">
      ${field('Titel', `<input type="text" name="title" value="${esc(e.title)}" maxlength="200" placeholder="z. B. Teambesprechung">`)}
      ${field('Art', `<select name="kind">${options(KINDS, e.kind)}</select>`)}
      <div class="row">${field('Beginn', `<input type="date" name="date_start" value="${esc(e.date_start)}">`)}<div id="t1">${field('Uhrzeit von', `<input type="time" name="time_start" value="${esc(e.time_start || '09:00')}">`)}</div></div>
      <div class="row">${field('Ende', `<input type="date" name="date_end" value="${esc(e.date_end || e.date_start)}">`)}<div id="t2">${field('Uhrzeit bis', `<input type="time" name="time_end" value="${esc(e.time_end || (isNew ? '10:00' : ''))}">`)}</div></div>
      <label class="check" style="margin:-4px 0 16px"><input type="checkbox" id="allday" ${isNew || e.time_start ? '' : 'checked'}>Ganztägig (ohne Uhrzeit)</label>
      <label class="f"><span>Teilnehmer</span><div class="pick">${activeUsers().map((u) => `<label>${avatar(u, 22)}<input type="checkbox" name="att" value="${u.id}" ${e.attendees.includes(u.id) ? 'checked' : ''}>${esc(u.name)}</label>`).join('')}</div></label>
      ${field('Beschreibung', `<textarea name="description" placeholder="Ort, Agenda, Hinweise …">${esc(e.description)}</textarea>`)}</fieldset>
      ${!isNew && userById(e.creator_id) ? `<p class="muted" style="margin:0 0 10px;font-size:12.5px">Erstellt von ${esc(userById(e.creator_id).name)}</p>` : ''}`,
    onSubmit: async (fd) => {
      const all = $('#allday', d).checked;
      const body = { title: fd.get('title'), kind: fd.get('kind'), description: fd.get('description'), date_start: fd.get('date_start'), date_end: fd.get('date_end') || fd.get('date_start'),
        time_start: all ? null : fd.get('time_start'), time_end: all ? null : fd.get('time_end') || null, attendees: fd.getAll('att').map(Number) };
      if (isNew) await api('POST', '/api/events', body); else await api('PUT', `/api/events/${e.id}`, body);
      toast(isNew ? 'Termin erstellt' : 'Gespeichert'); refresh();
    },
  });
  const sync = () => { const all = $('#allday', d).checked; $('#t1', d).hidden = $('#t2', d).hidden = all; };
  $('#allday', d).onchange = sync; sync();
  // Endzeit mitziehen: eine Stunde nach dem Beginn, solange sie nicht bewusst später gesetzt wurde
  const ts = $('[name=time_start]', d), te = $('[name=time_end]', d);
  ts.onchange = () => { if (!ts.value) return; if (!te.value || te.value <= ts.value) { const [h, m] = ts.value.split(':').map(Number); te.value = h >= 23 ? '23:59' : `${pad(h + 1)}:${pad(m)}`; } };
  const ds = $('[name=date_start]', d), de = $('[name=date_end]', d);
  ds.onchange = () => { if (!de.value || de.value < ds.value) de.value = ds.value; };
  const del = $('#del', d);
  if (del) del.onclick = async () => { if (await confirmBox(`„${e.title}“ wird gelöscht.`)) { await guard(() => api('DELETE', `/api/events/${e.id}`))(); d.close(); refresh(); } };
}

async function pageCalendar(main) {
  if (!S.calMonth) { const n = new Date(); S.calMonth = new Date(n.getFullYear(), n.getMonth(), 1); }
  const first = S.calMonth;
  const offset = (first.getDay() + 6) % 7;
  const start = new Date(first.getFullYear(), first.getMonth(), 1 - offset);
  const cells = Array.from({ length: 42 }, (_, i) => new Date(start.getFullYear(), start.getMonth(), start.getDate() + i));
  const from = ymd(cells[0]), to = ymd(cells[41]);
  const [events, tasks, away] = await Promise.all([api('GET', `/api/events?from=${from}&to=${to}`), api('GET', '/api/tasks'), api('GET', `/api/absences/calendar?from=${from}&to=${to}`).catch(() => [])]);
  for (const a of away) events.push({ id: 'a' + a.id, away: true, kind: 'absence', title: a.title, date_start: a.date_start, date_end: a.date_end, time_start: null, attendees: [a.user_id], creator_id: a.user_id }); // genehmigter Urlaub, Krankheit (ohne Grund)
  const mineOnly = S.calMode === 'mine';
  const evs = events.filter((e) => !mineOnly || e.creator_id === S.me.id || e.attendees.includes(S.me.id));
  const tks = tasks.filter((t) => t.due && t.status !== 'done' && (!mineOnly || t.assignee_id === S.me.id));
  const t0 = todayStr();
  const title = first.toLocaleDateString('de-DE', { month: 'long', year: 'numeric' });
  main.innerHTML = `<div class="page"><div class="page-head"><div><h1>Kalender</h1><p>Termine, Abwesenheiten und Fristen des gesamten Betriebs.</p></div>
    <div class="actions"><button class="btn primary" id="new">${icon('plus', 16)}Neuer Termin</button></div></div>
    <div class="cal-head"><h2>${esc(title)}</h2><button class="icon-btn" id="prev" aria-label="Vorheriger Monat">${icon('left', 20)}</button><button class="btn sm" id="now">Heute</button><button class="icon-btn" id="next" aria-label="Nächster Monat">${icon('right', 20)}</button>
      <span class="sp"></span><div class="seg" id="seg"><button data-m="all" class="${mineOnly ? '' : 'on'}">Alle</button><button data-m="mine" class="${mineOnly ? 'on' : ''}">Nur meine</button></div></div>
    <div class="card cal"><div class="cal-dow">${['Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa', 'So'].map((d) => `<div>${d}</div>`).join('')}</div>
    <div class="cal-grid">${cells.map((c) => {
      const s = ymd(c);
      const items = [
        ...evs.filter((e) => e.date_start <= s && e.date_end >= s).sort((a, b) => (a.time_start || '').localeCompare(b.time_start || '')).map((e) => ({ type: 'e', e })),
        ...tks.filter((t) => t.due === s).map((t) => ({ type: 't', t })),
      ];
      const shown = items.slice(0, 3);
      return `<div class="cell ${c.getMonth() !== first.getMonth() ? 'other' : ''} ${s === t0 ? 'today' : ''}" data-day="${s}"><span class="dn">${c.getDate()}</span>
        ${shown.map((it) => it.type === 'e'
          ? `<button class="ev k-${esc(it.e.kind)}" data-ev="${it.e.id}" title="${esc(it.e.title)}"><span class="dot"></span><span>${it.e.time_start && s === it.e.date_start ? `<em>${it.e.time_start}</em> ` : ''}${esc(it.e.title)}</span></button>`
          : `<button class="ev task" data-tk="${it.t.id}" title="Aufgabe fällig: ${esc(it.t.title)}">${icon('check', 12)}<span>${esc(it.t.title)}</span></button>`).join('')}
        ${items.length > 3 ? `<div class="more">+${items.length - 3} weitere</div>` : ''}</div>`;
    }).join('')}</div></div>
    <div class="legend">${KINDS.map(([k, l]) => `<span class="k-${k}"><i class="dot"></i>${l}</span>`).join('')}<span>${icon('check', 14)}Aufgabe fällig</span></div></div>`;
  $('#prev').onclick = () => { S.calMonth = new Date(first.getFullYear(), first.getMonth() - 1, 1); refresh(); };
  $('#next').onclick = () => { S.calMonth = new Date(first.getFullYear(), first.getMonth() + 1, 1); refresh(); };
  $('#now').onclick = () => { S.calMonth = null; refresh(); };
  $('#new').onclick = () => eventModal({ date_start: t0 });
  $$('#seg button').forEach((b) => b.onclick = () => { S.calMode = b.dataset.m; refresh(); });
  $$('.cell').forEach((c) => c.addEventListener('click', (e) => {
    const evb = e.target.closest('[data-ev]'), tkb = e.target.closest('[data-tk]');
    if (evb) { const ev = events.find((x) => String(x.id) === evb.dataset.ev); return ev.away ? toast(ev.title) : eventModal(ev); }
    if (tkb) return taskModal(tasks.find((x) => x.id === +tkb.dataset.tk));
    eventModal({ date_start: c.dataset.day });
  }));
}

/* ============ Dateien ============ */
async function pageFiles(main) {
  let files = await api('GET', '/api/files'); let q = '';
  main.innerHTML = `<div class="page"><div class="page-head"><div><h1>Dateien</h1><p>Gemeinsame Ablage für alle Mitarbeiter.</p></div>
    <div class="actions"><button class="btn primary" id="up">${icon('upload', 16)}Datei hochladen</button><input type="file" id="fi" multiple hidden></div></div>
    <div class="drop" id="drop">${icon('upload', 26)}<div><b>Dateien hierher ziehen</b><br>oder oben auf „Datei hochladen“ klicken (bis 100 MB je Datei)</div></div>
    <div class="toolbar"><div class="search">${icon('search', 16)}<input type="search" id="q" placeholder="Dateien suchen …"></div></div>
    <div class="card" style="overflow:auto"><table class="tbl"><thead><tr><th>Name</th><th class="hide-m">Hochgeladen von</th><th class="hide-m">Datum</th><th class="hide-m">Größe</th><th style="width:140px"></th></tr></thead><tbody id="rows"></tbody></table></div></div>`;
  const paint = () => {
    const list = files.filter((f) => !q || (f.name + f.note).toLowerCase().includes(q));
    $('#rows').innerHTML = list.map((f) => {
      const canEdit = S.me.role === 'admin' || f.uploader_id === S.me.id;
      return `<tr><td><a class="nm" href="/api/files/${f.id}/download" data-fname="${esc(f.name)}" data-fsize="${f.size}" title="${canPreview(f.name) ? 'Im Programm öffnen' : 'Herunterladen'}"><span class="ft">${esc(ext(f.name))}</span><div><b>${esc(f.name)}</b>${f.note ? `<small>${esc(f.note)}</small>` : ''}</div></a></td>
      <td class="hide-m"><span style="display:inline-flex;gap:8px;align-items:center">${avatar(userById(f.uploader_id), 24)}${esc(userById(f.uploader_id)?.name || '—')}</span></td>
      <td class="hide-m muted">${new Date(f.created_at).toLocaleDateString('de-DE', { day: 'numeric', month: 'short', year: 'numeric' })}</td><td class="hide-m muted">${fmtSize(f.size)}</td>
      <td style="text-align:right;white-space:nowrap"><button class="icon-btn" data-assign="${f.id}" title="Einem Projekt zuordnen">${icon('projects')}</button><a class="icon-btn" href="/api/files/${f.id}/download" title="Herunterladen" style="display:inline-grid">${icon('down')}</a>${canEdit ? `<button class="icon-btn" data-del="${f.id}" title="Löschen">${icon('trash')}</button>` : ''}</td></tr>`;
    }).join('') || `<tr><td colspan="5"><div class="empty">${icon('folder', 30)}${q ? 'Keine Treffer.' : 'Noch keine Dateien – lade die erste hoch.'}</div></td></tr>`;
    $$('[data-assign]').forEach((b) => b.onclick = guard(() => { const f = files.find((x) => x.id === +b.dataset.assign); return assignModal(f, () => { files = files.filter((x) => x !== f); paint(); }); }));
    $$('[data-del]').forEach((b) => b.onclick = async () => {
      const f = files.find((x) => x.id === +b.dataset.del);
      if (await confirmBox(`„${f.name}“ wird endgültig gelöscht.`)) { await guard(() => api('DELETE', `/api/files/${f.id}`))(); files = files.filter((x) => x !== f); paint(); }
    });
  };
  const upload = guard(async (list) => {
    for (const f of list) {
      toast(`„${f.name}“ wird hochgeladen …`);
      files.unshift(await uploadFile(f)); paint();
    }
    toast('Upload abgeschlossen');
  });
  $('#up').onclick = () => $('#fi').click();
  $('#fi').onchange = (e) => { upload([...e.target.files]); e.target.value = ''; };
  const drop = $('#drop');
  ['dragenter', 'dragover'].forEach((n) => drop.addEventListener(n, (e) => { e.preventDefault(); drop.classList.add('over'); }));
  ['dragleave', 'drop'].forEach((n) => drop.addEventListener(n, (e) => { e.preventDefault(); drop.classList.remove('over'); }));
  drop.addEventListener('drop', (e) => upload([...e.dataTransfer.files]));
  $('#q').oninput = (e) => { q = e.target.value.toLowerCase(); paint(); };
  paint();
}

/* ============ Team ============ */
async function copyText(t) { try { await navigator.clipboard.writeText(t); toast('Kopiert'); } catch { toast('Kopieren nicht möglich – bitte abschreiben', true); } }
/** Zeigt einen frisch erzeugten Einmal-Code zum Weitergeben. */
async function resetCodeModal(u) {
  const r = await api('POST', `/api/users/${u.id}/reset-code`);
  const { d } = modal({
    title: 'Einmal-Code zum Zurücksetzen', readonly: true,
    body: `<p style="margin:0 0 14px">Gib diesen Code an <b>${esc(r.name)}</b> weiter (persönlich oder am Telefon). Damit legt ${esc(firstName(u))} auf dem Anmeldebildschirm unter <b>„Passwort vergessen“ → „Ich habe schon einen Code“</b> ein neues Passwort fest.</p>
      <div class="codebox"><span>${esc(r.code)}</span><button type="button" class="btn sm" id="cp">${icon('clip', 14)}Kopieren</button></div>
      <p class="muted" style="margin:12px 0 14px;font-size:13px">Benutzername: <b>${esc(r.username)}</b> · gültig 24 Stunden, nur einmal verwendbar. Der Code wird nicht noch einmal angezeigt.</p>`,
    onSubmit: async () => {},
  });
  $('#cp', d).onclick = () => copyText(r.code);
  d.addEventListener('close', refresh);
}
async function auditModal() {
  const rows = await api('GET', '/api/admin/audit');
  modal({
    title: 'Sicherheitsprotokoll', readonly: true, onSubmit: async () => {},
    body: rows.length ? `<div class="audit">${rows.map((r) => `<div><time>${new Date(r.at).toLocaleString('de-DE', { day: '2-digit', month: '2-digit', year: '2-digit', hour: '2-digit', minute: '2-digit' })}</time><span><b>${esc(r.actor)}</b> · ${esc(r.action)}${r.detail ? ` <i>(${esc(r.detail)})</i>` : ''}</span></div>`).join('')}</div>` : '<p class="muted">Noch keine Einträge.</p>',
  });
}
async function pageTeam(main) {
  const admin = S.me.role === 'admin';
  const [users, tasks, settings] = await Promise.all([api('GET', '/api/users'), api('GET', '/api/tasks'), admin ? api('GET', '/api/admin/settings') : null]);
  S.users = users;
  const pending = users.filter((u) => u.pending), resets = users.filter((u) => u.reset_requested && u.active);
  const members = users.filter((u) => !u.pending);
  main.innerHTML = `<div class="page"><div class="page-head"><div><h1>Team</h1><p>Wer ist wofür zuständig – und woran arbeitet gerade wer.</p></div>
    ${admin ? `<div class="actions"><button class="btn" id="audit">${icon('clock', 16)}Protokoll</button><button class="btn primary" id="add">${icon('plus', 16)}Mitarbeiter anlegen</button></div>` : ''}</div>
    ${admin && (pending.length || resets.length) ? `<section class="card todo"><div class="card-h"><h3>Offene Anfragen</h3><span class="badge">${pending.length + resets.length}</span></div><div class="card-b">
      ${pending.map((u) => `<div class="li plain">${avatar(u, 36)}<div class="t"><b>${esc(u.name)} möchte ein Konto</b><small>Benutzername ${esc(u.username)}${u.position ? ' · ' + esc(u.position) : ''}${u.email ? ' · ' + esc(u.email) : ''}</small></div>
        <button class="btn sm danger" data-reject="${u.id}">Ablehnen</button><button class="btn sm primary" data-approve="${u.id}">${icon('check', 14)}Freigeben</button></div>`).join('')}
      ${resets.map((u) => `<div class="li plain">${avatar(u, 36)}<div class="t"><b>${esc(u.name)} hat das Passwort vergessen</b><small>Erzeuge einen Einmal-Code und gib ihn persönlich weiter</small></div>
        <button class="btn sm" data-dismiss="${u.id}">Verwerfen</button><button class="btn sm primary" data-code="${u.id}">${icon('key', 14)}Code erzeugen</button></div>`).join('')}
    </div></section>` : ''}
    ${admin ? `<section class="card invite"><div><h3>Mitarbeiter einladen</h3><p class="muted">${settings.registration
        ? 'Kopiere die passende Einladung und schick sie per WhatsApp oder E-Mail. Mit <b>„Einladung Baustelle“</b> landet das neue Konto direkt im eigenen Baustellen-Bereich, mit <b>„Einladung Büro“</b> sieht es alles. Der angezeigte Code gehört zur Büro-Einladung.'
        : 'Die Selbst-Registrierung ist ausgeschaltet. Neue Konten kannst nur du über „Mitarbeiter anlegen“ erstellen.'}</p></div>
      ${settings.registration ? `<div class="codebox"><span>${esc(settings.invite_code)}</span><button class="btn sm primary" id="cpis">${icon('send', 14)}Einladung Baustelle</button><button class="btn sm" id="cpi">${icon('send', 14)}Einladung Büro</button><button class="btn sm" id="cpc">${icon('clip', 14)}Nur Code</button><button class="btn sm" id="newc" title="Alten Code ungültig machen">Neuer Code</button></div>` : ''}
      <label class="check"><input type="checkbox" id="regopen" ${settings.registration ? 'checked' : ''}>Registrierung erlauben</label></section>` : ''}
    <div class="people">${members.map((u) => { const n = tasks.filter((t) => t.assignee_id === u.id && t.status !== 'done').length;
      return `<div class="card person" style="${u.active ? '' : 'opacity:.6'}"><div class="head">${avatar(u, 48)}<div style="min-width:0"><b>${esc(u.name)}</b><span class="muted">${esc(u.position || 'Keine Position')}</span>${u.kind === 'site' && u.role !== 'admin' ? '<span class="chip soon" style="margin-top:4px">Baustelle</span>' : ''}</div>
        ${admin ? `<button class="icon-btn" style="margin-left:auto" data-edit="${u.id}" aria-label="Bearbeiten">${icon('edit')}</button>` : ''}</div>
        <div class="resp">${u.responsibility ? esc(u.responsibility) : '<span class="faint">Kein Verantwortungsbereich eingetragen</span>'}${u.email ? `<br><a href="mailto:${esc(u.email)}">${esc(u.email)}</a>` : ''}</div>
        <div class="foot">${u.active ? `<span class="chip accent">${n} offene Aufgabe${n === 1 ? '' : 'n'}</span>` : '<span class="chip">Deaktiviert</span>'}${u.role === 'admin' ? '<span class="chip">Admin</span>' : ''}
        ${u.id !== S.me.id && u.active ? `<a class="btn sm" style="margin-left:auto" href="#/nachrichten" data-msg="${u.id}">${icon('chat', 14)}Nachricht</a>` : ''}</div></div>`; }).join('')}</div></div>`;
  $$('[data-msg]').forEach((a) => a.onclick = () => { S.conv = a.dataset.msg; });
  if (!admin) return;
  $('#add').onclick = () => userModal();
  $('#audit').onclick = guard(auditModal);
  $$('[data-edit]').forEach((b) => b.onclick = () => userModal(userById(+b.dataset.edit)));
  $$('[data-approve]').forEach((b) => b.onclick = guard(async () => { await api('POST', `/api/users/${b.dataset.approve}/approve`); toast('Konto freigegeben'); pollSummary(); refresh(); }));
  $$('[data-reject]').forEach((b) => b.onclick = guard(async () => { if (await confirmBox('Die Registrierung wird abgelehnt und gelöscht.', 'Ablehnen')) { await api('DELETE', `/api/users/${b.dataset.reject}`); pollSummary(); refresh(); } }));
  $$('[data-code]').forEach((b) => b.onclick = guard(() => resetCodeModal(userById(+b.dataset.code))));
  $$('[data-dismiss]').forEach((b) => b.onclick = guard(async () => { await api('POST', `/api/users/${b.dataset.dismiss}/dismiss-reset`); pollSummary(); refresh(); }));
  $('#regopen').onchange = guard(async (e) => { await api('PUT', '/api/admin/settings', { registration: e.target.checked }); refresh(); });
  if ($('#cpc')) {
    $('#cpc').onclick = () => copyText(settings.invite_code);
    const invite = (code) => copyText(`Einladung zum Betriebsportal${S.brand && S.brand.name ? ' von ' + S.brand.name : ''}\n\nKlicke auf diesen Link und folge den Schritten – am Handy oder am Computer:\n${location.origin}/#/einladung/${code}`);
    $('#cpi').onclick = () => invite(settings.invite_code);
    $('#cpis').onclick = () => invite(settings.invite_code_site);
    $('#newc').onclick = guard(async () => { if (await confirmBox('Der bisherige Einladungscode wird ungültig. Bereits registrierte Konten bleiben bestehen.', 'Neuen Code erzeugen')) { await api('PUT', '/api/admin/settings', { new_code: true }); refresh(); } });
  }
}
function userModal(u) {
  const isNew = !u; u = u || { name: '', username: '', position: '', responsibility: '', email: '', role: 'user', active: true, kind: '' };
  const { d } = modal({
    title: isNew ? 'Mitarbeiter anlegen' : 'Mitarbeiter bearbeiten', submit: isNew ? 'Anlegen' : 'Speichern',
    extra: !isNew && u.active ? `<button type="button" class="btn" id="rc">${icon('key', 16)}Passwort zurücksetzen</button>` : '',
    body: `${field('Name', `<input type="text" name="name" value="${esc(u.name)}" maxlength="80">`)}
      ${field('Arbeitsbereich – bestimmt, was diese Person sieht', `<select name="kind">${isNew ? '<option value="">— Bitte wählen —</option>' : ''}${options([['site', 'Baustelle – eigener Bereich: Stempeln, Baustellen mit Fotos und Tagesberichten, Nachrichten, eigene Aufgaben'], ['office', 'Büro – alles: Projekte mit Rechnungen, Dateien, Telefonbuch, Kalender, Team']], u.kind)}</select>`)}
      <div class="row">${field('Benutzername', `<input type="text" name="username" value="${esc(u.username)}" ${isNew ? '' : 'disabled'} autocomplete="off">`)}${field('Rolle', `<select name="role">${options([['user', 'Mitarbeiter'], ['admin', 'Administrator']], u.role)}</select>`)}</div>
      <div class="row">${field('Position', `<input type="text" name="position" value="${esc(u.position)}" maxlength="80" placeholder="z. B. Vertriebsleiter">`)}${field('E-Mail (optional)', `<input type="text" name="email" value="${esc(u.email)}" maxlength="120">`)}</div>
      ${field('Verantwortungsbereich', `<textarea name="responsibility" maxlength="500" placeholder="Wofür ist diese Person zuständig?">${esc(u.responsibility)}</textarea>`)}
      ${isNew ? pwField('Startpasswort (mind. 8 Zeichen) – muss beim ersten Anmelden geändert werden', 'password') : `<label class="check" style="margin-bottom:12px"><input type="checkbox" name="active" ${u.active ? 'checked' : ''} ${u.id === S.me.id ? 'disabled' : ''}>Zugang aktiv</label>`}`,
    onSubmit: async (fd) => {
      if (!fd.get('kind')) throw new Error('Bitte den Arbeitsbereich wählen: Baustelle oder Büro');
      const body = { name: fd.get('name'), username: fd.get('username'), position: fd.get('position'), email: fd.get('email'), responsibility: fd.get('responsibility'), role: fd.get('role'), kind: fd.get('kind'), password: fd.get('password') || undefined };
      if (isNew) await api('POST', '/api/users', body); else await api('PUT', `/api/users/${u.id}`, { ...body, active: u.id === S.me.id ? true : fd.get('active') === 'on' });
      S.users = await api('GET', '/api/users'); toast(isNew ? 'Mitarbeiter angelegt' : 'Gespeichert'); refresh();
    },
  });
  const rc = $('#rc', d); if (rc) rc.onclick = guard(async () => { d.close(); await resetCodeModal(u); });
}
/** Eigenes Profil: Name, E-Mail, Passwort. */
function profileModal() {
  const { d } = modal({
    title: 'Mein Profil',
    body: `<div class="avrow"><span id="avprev">${avatar(S.me, 72)}</span><div><button type="button" class="btn" id="avup">${icon('upload', 16)}Profilbild hochladen</button> <button type="button" class="btn danger" id="avrm" ${S.me.avatar ? '' : 'hidden'}>Entfernen</button>
        <input type="file" id="avfi" accept="image/*" hidden><p class="muted" style="margin:8px 0 0;font-size:13px">Das Bild wird automatisch quadratisch zugeschnitten und für alle Kollegen sichtbar.</p></div></div>
      ${field('Name', `<input type="text" name="name" value="${esc(S.me.name)}" maxlength="80">`)}
      ${field('E-Mail (optional, auch zum Anmelden nutzbar)', `<input type="text" name="email" value="${esc(S.me.email || '')}" maxlength="120">`)}
      <p class="muted" style="margin:0 0 14px;font-size:13px">Benutzername: <b>${esc(S.me.username)}</b> · Position und Verantwortungsbereich pflegt ein Administrator.</p>
      <div class="daylabel" style="padding-left:0">Passwort ändern (optional)</div>
      ${pwField('Aktuelles Passwort', 'current', 'current-password')}<div class="row">${pwField('Neues Passwort', 'password')}${pwField('Wiederholen', 'password2')}</div>`,
    onSubmit: async (fd) => {
      if (fd.get('password') || fd.get('current')) await api('POST', '/api/me/password', { current: fd.get('current'), password: samePw(fd) });
      S.me = { ...S.me, ...(await api('PUT', '/api/me', { name: fd.get('name'), email: fd.get('email') })) };
      S.users = await api('GET', '/api/users'); toast('Profil gespeichert'); renderShell(); paintBadge(); refresh();
    },
  });  const applyAvatar = async (url) => {
    S.me.avatar = url; S.users = await api('GET', '/api/users');
    $('#avprev', d).innerHTML = avatar(S.me, 72); $('#avrm', d).hidden = !url;
    const mb = $('#me-btn .av'); if (mb) mb.outerHTML = avatar(S.me, 34);
    const tb = $('#tb-menu .av'); if (tb) tb.outerHTML = avatar(S.me, 30);
  };
  $('#avup', d).onclick = () => $('#avfi', d).click();
  $('#avfi', d).onchange = guard(async (e) => {
    const f = e.target.files[0]; e.target.value = ''; if (!f) return;
    const blob = await squareImage(f, 320);
    const r = await fetch('/api/me/avatar', { method: 'POST', headers: { 'Content-Type': 'application/octet-stream' }, body: blob });
    const j = await r.json().catch(() => ({})); if (!r.ok) throw new Error(j.error || 'Upload fehlgeschlagen');
    await applyAvatar(j.avatar); toast('Profilbild gespeichert');
  });
  $('#avrm', d).onclick = guard(async () => { await api('DELETE', '/api/me/avatar'); await applyAvatar(null); });
}
/** Bild mittig quadratisch zuschneiden und verkleinern (hält die Dateien klein und alle Bilder einheitlich). */
async function squareImage(file, size) {
  let img;
  try { img = await createImageBitmap(file); } catch { throw new Error('Diese Datei ist kein Bild, das sich öffnen lässt'); }
  const side = Math.min(img.width, img.height);
  const c = document.createElement('canvas'); c.width = c.height = size;
  const g = c.getContext('2d');
  g.fillStyle = '#fff'; g.fillRect(0, 0, size, size); // durchsichtige Bereiche weiß statt schwarz
  g.drawImage(img, (img.width - side) / 2, (img.height - side) / 2, side, side, 0, 0, size, size);
  return new Promise((res, rej) => c.toBlob((b) => (b ? res(b) : rej(new Error('Bild konnte nicht verarbeitet werden'))), 'image/jpeg', 0.9));
}
