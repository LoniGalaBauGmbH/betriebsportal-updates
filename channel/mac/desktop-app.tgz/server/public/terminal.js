'use strict';
/* Bildschirm am Eingang: zeigt einen QR-Code zum Ein- und Ausstempeln, der alle 30 Sekunden wechselt. */
(function () {
  var q = new URLSearchParams(location.search), box = document.getElementById('t'), last = '', built = false;
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function clock() { var el = document.getElementById('clock'); if (el) el.textContent = new Date().toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' }); }
  function load() {
    fetch('/api/time/display/' + encodeURIComponent(q.get('id')) + '?s=' + encodeURIComponent(q.get('s') || ''), { cache: 'no-store' })
      .then(function (r) { return r.json().then(function (d) { if (!r.ok) throw new Error(d.error || 'Fehler'); return d; }); })
      .then(function (d) {
        if (!built) {
          box.innerHTML = '<div class="t-head"><b>' + esc(d.company || 'Zeiterfassung') + '</b><span id="clock"></span></div><h1>' + esc(d.name) + '</h1>' + (d.project ? '<p class="t-proj">' + esc(d.project) + '</p>' : '')
            + '<div class="t-qr" id="qr"></div><p class="t-hint"><b>Kommen oder Gehen?</b> Einfach den Code mit der Handy-Kamera scannen.</p><p class="muted" id="state"></p>';
          built = true; clock();
        }
        if (d.url !== last) { var c = qrcode(0, 'M'); c.addData(d.url); c.make(); document.getElementById('qr').innerHTML = c.createSvgTag({ cellSize: 8, margin: 16, scalable: true }); last = d.url; }
        document.getElementById('state').textContent = d.mode === 'rotating' ? 'Der Code wechselt automatisch.' : '';
      })
      .catch(function (e) { if (!built) box.innerHTML = '<h1>Zeiterfassung</h1><p class="muted">' + esc(e.message) + '</p>'; else document.getElementById('state').textContent = 'Keine Verbindung zum Portal – neuer Versuch läuft …'; });
  }
  load(); setInterval(load, 5000); setInterval(clock, 10000);
}());
