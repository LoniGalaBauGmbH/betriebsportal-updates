'use strict';
/* Ab Version 1.6: Zeiterfassung – Stempeln (auch per QR-Code), Stundenkonto, Urlaub, Krankmeldung, persönliche Unterlagen. */

Object.assign(ICONS, {
  qr: '<rect x="4" y="4" width="6" height="6" rx="1"/><rect x="14" y="4" width="6" height="6" rx="1"/><rect x="4" y="14" width="6" height="6" rx="1"/><path d="M14 14h2.5v2.5H14zM17.5 17.5H20V20h-2.500zM20 14v1M14 20v-1"/>',
  play: '<path d="M8 5.500v13l10.500-6.500Z"/>',
  stop: '<rect x="6.500" y="6.500" width="11" height="11" rx="2"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 3v2M12 19v2M3 12h2M19 12h2M5.600 5.600 7 7M17 17l1.400 1.400M5.600 18.400 7 17M17 7l1.400-1.400"/>',
  print: '<path d="M7 9V4h10v5M7 17H5a1.500 1.500 0 0 1-1.500-1.500v-5A1.500 1.500 0 0 1 5 9h14a1.500 1.500 0 0 1 1.500 1.500v5A1.500 1.500 0 0 1 19 17h-2"/><rect x="7" y="14" width="10" height="6" rx="1"/>',
  copy: '<rect x="8.500" y="8.500" width="11" height="11" rx="2"/><path d="M15.500 8.500V6a1.500 1.500 0 0 0-1.500-1.500H6A1.500 1.500 0 0 0 4.500 6v8A1.500 1.500 0 0 0 6 15.500h2.500"/>',
});
NAV.splice(1, 0, ['zeit', 'Zeit', 'clock']);

/* ---------- Helfer ---------- */
const hm = (m) => { const a = Math.abs(Math.round(m)); return `${m < 0 ? '−' : ''}${Math.floor(a / 60)}:${pad(a % 60)}`; };
const hmSigned = (m) => (Math.round(m) > 0 ? '+' : '') + hm(m);
const num = (n) => String(Math.round(n * 100) / 100).replace('.', ',');
const dmy = (s) => s.split('-').reverse().join('.');
const monthStr = (d = new Date()) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}`;
const monthRange = (m) => { const [y, mo] = m.split('-').map(Number); return { from: `${m}-01`, to: ymd(new Date(y, mo, 0)), label: new Date(y, mo - 1, 1).toLocaleDateString('de-DE', { month: 'long', year: 'numeric' }) }; };
const monthShift = (m, n) => { const [y, mo] = m.split('-').map(Number); return monthStr(new Date(y, mo - 1 + n, 1)); };
const ABS = { vacation: ['Urlaub', 'ok'], sick: ['Krank', 'late'], other: ['Abwesenheit', 'accent'], comp: ['Überstunden-Ausgleich', 'soon'] };
const DOCCATS = [['sick', 'Krankmeldung'], ['payslip', 'Lohnabrechnung'], ['contract', 'Vertrag'], ['certificate', 'Bescheinigung / Nachweis'], ['other', 'Sonstiges']];
const docCat = (c) => (DOCCATS.find((d) => d[0] === c) || DOCCATS[4])[1];
const WDAYS = ['Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa', 'So'];
const isAdmin = () => S.me.role === 'admin';
function qrSvg(text) { const q = qrcode(0, 'M'); q.addData(text); q.make(); return q.createSvgTag({ cellSize: 6, margin: 12, scalable: true }); }
const projectOptions = (sel) => '<option value="">— Kein Projekt —</option>' + options((S.projects || []).filter((p) => p.status === 'active' || p.id === sel).map((p) => [p.id, [p.number, p.name].filter(Boolean).join(' · ')]), sel);

/* ---------- Hinweise in der Navigation ---------- */
function timeSummary(sum) {
  const a = $('[data-nav="zeit"]'); if (!a) return;
  let b = $('#zbadge'); if (!b) { a.insertAdjacentHTML('beforeend', '<span class="badge" id="zbadge" hidden></span>'); b = $('#zbadge'); }
  if (sum.requests > (S.requests || 0) && S.requests !== undefined) toast('Neuer Antrag im Bereich Zeit');
  S.requests = sum.requests || 0;
  b.textContent = S.requests; b.hidden = !S.requests;
  a.classList.toggle('stamped', !!sum.stamped);
}

/* ---------- Stempeln ---------- */
const stampText = (r) => (r.action === 'in' ? `Eingestempelt um ${fmtClock(r.at)} Uhr` : r.action === 'out' ? `Ausgestempelt um ${fmtClock(r.at)} Uhr` : 'Schon erfasst – nichts geändert');
async function doStamp() { const r = await api('POST', '/api/time/stamp', {}); toast(stampText(r)); refresh(); }
/** Karte „Kommen / Gehen“ – für die Zeit-Seite und die Übersicht. */
function stampCard(st, compact = false) {
  const o = st.open, t = st.today;
  const state = o ? `<b>Eingestempelt</b><span>seit ${o.stale ? dmy(ymd(new Date(o.start))) + ', ' : ''}${fmtClock(o.start)} Uhr${o.project ? ' · ' + esc(o.project) : ''}</span>`
    : t.absence ? `<b>${ABS[t.absence.type][0] === 'Krank' ? 'Krank gemeldet' : ABS[t.absence.type][0]}</b><span>Heute ist eine Abwesenheit eingetragen</span>`
    : t.holiday ? `<b>${esc(t.holiday)}</b><span>Heute ist ein Feiertag</span>` : `<b>Nicht eingestempelt</b><span>${t.worked ? `Heute bisher ${hm(t.worked)} Std.` : 'Guten Start in den Tag!'}</span>`;
  return `<section class="card stampcard ${o ? 'in' : ''} ${compact ? 'compact' : ''}"><span class="pulse">${icon('clock', compact ? 22 : 28)}</span><div class="st">${state}</div>
    <div class="today"><b data-live>${hm(t.worked)}</b><small>heute${t.target ? ` von ${hm(t.target)}` : ''} Std.${t.pause ? ` · ${t.pause} Min. Pause` : ''}</small></div>
    ${st.manual ? `<button class="btn ${o ? '' : 'primary'} big" data-stamp>${icon(o ? 'stop' : 'play', 16)}${o ? 'Ausstempeln' : 'Einstempeln'}</button>` : `<span class="chip">${icon('qr', 13)}Stempeln per QR-Code</span>`}</section>`;
}
function bindStamp(root) { $$('[data-stamp]', root).forEach((b) => b.addEventListener('click', guard(async () => { b.disabled = true; await doStamp(); }))); }

/** Seite nach dem Scannen eines QR-Codes: stempelt sofort und zeigt das Ergebnis groß an. */
PAGES.stempeln = async function pageStamp(main) {
  const [, station, token] = hashParts();
  history.replaceState(null, '', '#/zeit');            // Neuladen der Seite soll nicht noch einmal stempeln
  $$('[data-nav]').forEach((a) => a.classList.toggle('on', a.dataset.nav === 'zeit'));
  let r;
  try { r = await api('POST', '/api/time/stamp', { station: Number(station), token }); }
  catch (e) {
    main.innerHTML = `<div class="page"><div class="card stampres bad"><span class="sico">${icon('alert', 44)}</span><h1>Das hat nicht geklappt</h1><p>${esc(e.message)}</p><a class="btn primary big" href="#/zeit">Zur Zeiterfassung</a></div></div>`;
    $('.stampres a', main).onclick = () => setTimeout(refresh, 0);
    return;
  }
  const s = r.status;
  main.innerHTML = `<div class="page"><div class="card stampres ${r.action}"><span class="sico">${icon(r.action === 'out' ? 'stop' : r.action === 'in' ? 'play' : 'check', 44)}</span>
    <h1>${r.action === 'in' ? 'Eingestempelt' : r.action === 'out' ? 'Ausgestempelt' : 'Schon erfasst'}</h1>
    <p class="when">${r.action === 'repeat' ? 'Der Code wurde gerade eben schon gescannt – es wurde nichts geändert.' : `${fmtClock(r.at)} Uhr · ${esc(r.station || '')}${r.project ? ' · ' + esc(r.project) : ''}`}</p>
    <div class="facts"><div><b>${hm(s.today.worked)}</b><small>heute gearbeitet</small></div><div><b>${hm(s.week.worked)}</b><small>diese Woche</small></div><div><b>${hmSigned(s.balance)}</b><small>Stundenkonto</small></div></div>
    <p class="muted">${r.action === 'in' ? `Schönen Arbeitstag, ${esc(firstName(S.me))}!` : r.action === 'out' ? 'Schönen Feierabend!' : ''}</p>
    <div class="acts"><a class="btn primary big" href="#/zeit" id="sr-ok">Fertig</a>${r.action === 'repeat' ? '' : '<button class="btn big" id="sr-undo">Rückgängig</button>'}</div></div></div>`;
  $('#sr-ok').onclick = () => setTimeout(refresh, 0);
  const u = $('#sr-undo'); if (u) u.onclick = guard(async () => { await api('POST', '/api/time/undo'); toast('Rückgängig gemacht'); refresh(); });
};

/* ---------- Gemeinsame Bausteine ---------- */
function timeTabs(active) {
  const tabs = [['', 'Meine Zeit'], ['abwesenheit', 'Urlaub & Krankheit'], ['unterlagen', 'Meine Unterlagen']];
  if (isAdmin()) tabs.push(['team', 'Team-Zeiten'], ['antraege', 'Anträge', S.requests || ''], ['stempelstellen', 'QR-Codes & Regeln']);
  return `<nav class="tabs" style="margin-bottom:20px">${tabs.map(([k, l, n]) => `<a href="#/zeit${k ? '/' + k : ''}" class="${active === k ? 'on' : ''}">${l}${n ? `<span>${n}</span>` : ''}</a>`).join('')}</nav>`;
}
const statCards = (d) => `<div class="stats${d.noWeek ? ' three' : ''}">
  ${d.noWeek ? '' : `<div class="card stat"><span class="ico">${icon('clock', 22)}</span><span><b>${hm(d.weekWorked)}</b><small>Diese Woche${d.weekTarget ? ` von ${hm(d.weekTarget)}` : ''} Std.</small></span></div>`}
  <div class="card stat"><span class="ico">${icon('cal', 22)}</span><span><b>${hm(d.monthWorked)}</b><small>Dieser Monat${d.monthTarget ? ` von ${hm(d.monthTarget)}` : ''} Std.</small></span></div>
  <div class="card stat ${d.balance < 0 ? 'late' : 'ok'}"><span class="ico">${icon(d.balance < 0 ? 'alert' : 'check', 22)}</span><span><b>${hmSigned(d.balance)}</b><small>Stundenkonto (${d.balance < 0 ? 'Minusstunden' : 'Überstunden'})</small></span></div>
  <div class="card stat warn"><span class="ico">${icon('sun', 22)}</span><span><b>${num(d.vacation.remaining)}</b><small>Resturlaub ${d.vacation.year} von ${num(d.vacation.entitled)} Tagen${d.vacation.pending ? ` · ${num(d.vacation.pending)} beantragt` : ''}</small></span></div></div>`;
/** Monatstabelle der Tage. Administratoren können Buchungen anklicken und ändern. */
function daysTable(days, { edit = false, start = '' } = {}) {
  const t0 = todayStr();
  const rows = days.filter((d) => d.date <= t0 || d.absence || d.holiday).map((d) => {
    const before = start && d.date < start;
    const times = d.entries.map((e) => `<${edit ? 'button' : 'span'} class="tspan ${e.review ? 'rev' : ''}" ${edit ? `data-entry="${e.id}"` : ''} title="${esc([e.source === 'qr' ? 'Per QR-Code gestempelt' : e.source === 'admin' ? 'Vom Administrator eingetragen' : 'Im Programm gestempelt', e.note].filter(Boolean).join(' · '))}">${fmtClock(e.start)}–${e.end ? fmtClock(e.end) : e.open && d.date === t0 ? 'jetzt' : '?'}</${edit ? 'button' : 'span'}>`).join(' ');
    const marks = [d.holiday ? `<span class="chip accent">${esc(d.holiday)}</span>` : '', d.absence ? `<span class="chip ${ABS[d.absence.type][1]}">${ABS[d.absence.type][0]}${d.absence.half ? ' ½' : ''}</span>` : '',
      d.entries.some((e) => e.review) ? `<span class="chip late">${icon('alert', 13)}Bitte prüfen</span>` : ''].join('');
    const off = !d.target && !d.entries.length && !d.absence;
    return `<tr class="${off || before ? 'off' : ''} ${d.date === t0 ? 'now' : ''}"><td><b>${WDAYS[d.weekday - 1]}</b> ${dmy(d.date).slice(0, 6)}</td><td>${times || (off ? '' : '<span class="muted">—</span>')} ${marks}${edit ? `<button class="icon-btn addt" data-add="${d.date}" title="Zeit nachtragen">${icon('plus', 15)}</button>` : ''}</td>
      <td class="hide-m r">${d.pause ? d.pause + ' Min.' : ''}</td><td class="r"><b>${d.worked || d.credit ? hm(d.worked + d.credit) : ''}</b></td><td class="hide-m r muted">${d.target ? hm(d.target) : ''}</td>
      <td class="r ${before ? '' : d.diff < 0 ? 'neg' : d.diff > 0 ? 'pos' : ''}">${before || d.date > t0 || (d.date === t0 && d.diff < 0) ? '' : d.diff ? hmSigned(d.diff) : ''}</td></tr>`;
  });
  const past = days.filter((d) => d.date < t0 && !(start && d.date < start));
  const total = (k) => past.reduce((n, d) => n + d[k], 0);
  return `<div class="card" style="overflow:auto"><table class="tbl timetbl"><thead><tr><th>Tag</th><th>Kommen – Gehen</th><th class="hide-m r">Pause</th><th class="r">Ist</th><th class="hide-m r">Soll</th><th class="r">Saldo</th></tr></thead>
    <tbody>${rows.join('') || `<tr><td colspan="6"><div class="empty">${icon('clock', 30)}In diesem Monat gibt es noch keine Einträge.</div></td></tr>`}</tbody>
    ${past.length ? `<tfoot><tr><td colspan="2">Summe bis gestern</td><td class="hide-m r">${total('pause')} Min.</td><td class="r"><b>${hm(total('worked') + total('credit'))}</b></td><td class="hide-m r">${hm(total('target'))}</td><td class="r ${total('diff') < 0 ? 'neg' : 'pos'}"><b>${hmSigned(total('diff'))}</b></td></tr></tfoot>` : ''}</table></div>`;
}
const monthNav = (m) => { const r = monthRange(m); return `<div class="cal-head"><h2>${esc(r.label)}</h2><button class="icon-btn" data-mon="-1" aria-label="Vorheriger Monat">${icon('left', 20)}</button><button class="btn sm" data-mon="0">Heute</button><button class="icon-btn" data-mon="1" aria-label="Nächster Monat">${icon('right', 20)}</button><span class="sp"></span></div>`; };
function bindMonthNav(root) { $$('[data-mon]', root).forEach((b) => b.onclick = () => { S.timeMonth = +b.dataset.mon ? monthShift(S.timeMonth, +b.dataset.mon) : monthStr(); refresh(); }); }

/* ---------- Meine Zeit ---------- */
async function pageMyTime(main) {
  S.timeMonth ||= monthStr();
  const { from, to } = monthRange(S.timeMonth);
  const [st, data] = await Promise.all([api('GET', '/api/time/me'), api('GET', `/api/time/days?from=${from}&to=${to}`)]);
  main.innerHTML = `<div class="page"><div class="page-head"><div><h1>Zeiterfassung</h1><p>Kommen, Gehen, Stundenkonto und Urlaub – alles an einem Ort.</p></div></div>${timeTabs('')}
    ${stampCard(st)}
    ${statCards({ weekWorked: st.week.worked, weekTarget: st.week.target, monthWorked: st.month.worked, monthTarget: st.month.target, balance: st.balance, vacation: st.vacation })}
    ${monthNav(S.timeMonth)}${daysTable(data.days, { start: data.start })}
    <p class="muted" style="font-size:13px;margin:12px 4px">Vereinbart: ${num(st.work.weekly_hours)} Std. pro Woche (${st.work.workdays.map((d) => WDAYS[d - 1]).join(', ') || 'keine festen Tage'}). Das Stundenkonto zählt bis einschließlich gestern. Stimmt eine Zeit nicht? Dann sag deinem Administrator Bescheid – er kann sie korrigieren.</p></div>`;
  bindStamp(main); bindMonthNav(main);
  if (st.open && !st.open.stale) { // laufende Zeit weiterzählen
    const base = st.today.worked, t = Date.now(), iv = setInterval(() => { const el = $('[data-live]', main); if (el) el.textContent = hm(base + (Date.now() - t) / 60000); }, 20000);
    S.cleanup.push(() => clearInterval(iv));
  }
}

/* ---------- Urlaub & Krankheit ---------- */
const absStatus = (a) => (a.status === 'pending' ? '<span class="chip soon">Wartet auf Entscheidung</span>' : a.status === 'rejected' ? '<span class="chip late">Abgelehnt</span>' : `<span class="chip ok">${a.type === 'sick' ? 'Gemeldet' : 'Genehmigt'}</span>`);
const absSpan = (a) => (a.date_start === a.date_end ? fmtShort(a.date_start) + (a.half ? ' (halber Tag)' : '') : `${fmtShort(a.date_start)} – ${fmtShort(a.date_end)}`) + ' ' + a.date_end.slice(0, 4);
function absenceModal(type, { forUser = null, vac = null, done = refresh } = {}) {
  const t0 = todayStr();
  const intro = { vacation: vac ? `Verfügbar: <b>${num(vac.remaining - vac.pending)} Tage</b> (Anspruch ${num(vac.entitled)}, genommen ${num(vac.taken)}${vac.pending ? `, beantragt ${num(vac.pending)}` : ''}). Wochenenden und Feiertage werden nicht mitgezählt.` : '',
    sick: 'Die Meldung gilt sofort und geht an die Administratoren. Das Ende kannst du schätzen – eine Bescheinigung lässt sich auch später nachreichen.',
    comp: 'Freie Tage zum Abbau von Überstunden. Die Stunden werden vom Stundenkonto abgezogen.', other: 'Zum Beispiel Berufsschule, Fortbildung oder Sonderurlaub. Die Zeit wird wie gearbeitet gutgeschrieben.' }[type];
  const { d } = modal({
    title: { vacation: 'Urlaub beantragen', sick: 'Krank melden', comp: 'Überstunden-Ausgleich beantragen', other: 'Abwesenheit beantragen' }[type] + (forUser ? ` – ${forUser.name}` : ''),
    submit: type === 'sick' || forUser ? 'Eintragen' : 'Antrag senden',
    body: `${intro ? `<p class="muted" style="margin:0 0 14px">${intro}</p>` : ''}
      <div class="row">${field(type === 'sick' ? 'Krank ab' : 'Von', `<input type="date" name="date_start" value="${t0}">`)}${field(type === 'sick' ? 'Voraussichtlich bis' : 'Bis', `<input type="date" name="date_end" value="${t0}">`)}</div>
      ${type === 'sick' ? '' : '<label class="check" id="halfrow" style="margin:-4px 0 14px"><input type="checkbox" name="half">Nur ein halber Tag</label>'}
      ${type === 'sick' && !forUser ? `<label class="f"><span>Krankmeldung / Bescheinigung (optional, Foto oder PDF)</span><input type="file" name="file" accept="image/*,application/pdf"></label>` : ''}
      ${field('Notiz (optional)', '<textarea name="note" maxlength="500" placeholder="z. B. Vertretung, Erreichbarkeit …" style="min-height:64px"></textarea>')}`,
    onSubmit: async (fd) => {
      let file_id = null; const f = fd.get('file');
      if (f && f.size) file_id = (await uploadTo(f, { ctx: 'personal', category: 'sick' })).id;
      await api('POST', '/api/absences', { type, date_start: fd.get('date_start'), date_end: fd.get('date_end') || fd.get('date_start'), half: !!fd.get('half'), note: fd.get('note'), file_id, user_id: forUser ? forUser.id : undefined });
      toast(type === 'sick' ? 'Krankmeldung eingetragen – gute Besserung!' : forUser ? 'Eingetragen' : 'Antrag gesendet'); done();
    },
  });
  const ds = $('[name=date_start]', d), de = $('[name=date_end]', d), hr = $('#halfrow', d);
  const sync = () => { if (de.value < ds.value) de.value = ds.value; if (hr) { hr.hidden = de.value !== ds.value; if (hr.hidden) $('input', hr).checked = false; } };
  ds.onchange = de.onchange = sync; sync();
}
const absenceRows = (list, { admin = false } = {}) => list.map((a) => `<div class="li plain abs"><span class="ft ${ABS[a.type][1]}">${icon(a.type === 'vacation' ? 'sun' : a.type === 'sick' ? 'plus' : 'cal', 18)}</span>
  <div class="t"><b>${admin && a.user_name ? esc(a.user_name) + ' · ' : ''}${ABS[a.type][0]} · ${absSpan(a)}</b><small>${a.days !== null ? num(a.days) + (a.days === 1 ? ' Urlaubstag' : ' Urlaubstage') + ' · ' : ''}${esc(a.note || '')}${a.decision_note ? ` · Hinweis: ${esc(a.decision_note)}` : ''}</small></div>
  ${a.file ? `<a class="chip accent" href="/api/files/${a.file.id}/download" data-fname="${esc(a.file.name)}" data-fsize="${a.file.size}">${icon('clip', 13)}Bescheinigung</a>` : !admin && a.type === 'sick' ? `<button class="btn sm" data-attach="${a.id}">${icon('upload', 14)}Bescheinigung</button>` : ''}
  ${absStatus(a)}
  ${admin && a.status === 'pending' ? `<button class="btn sm primary" data-dec="approved" data-id="${a.id}">Genehmigen</button><button class="btn sm" data-dec="rejected" data-id="${a.id}">Ablehnen</button>` : ''}
  ${admin || a.status === 'pending' || a.date_start > todayStr() ? `<button class="icon-btn" data-absdel="${a.id}" title="${a.status === 'pending' ? 'Antrag zurückziehen' : 'Löschen'}">${icon('trash')}</button>` : ''}</div>`).join('');
function bindAbsences(root, list) {
  $$('[data-absdel]', root).forEach((b) => b.onclick = async () => { const a = list.find((x) => x.id === +b.dataset.absdel); if (await confirmBox(`${ABS[a.type][0]} ${absSpan(a)} wird ${a.status === 'pending' ? 'zurückgezogen' : 'gelöscht'}.`, a.status === 'pending' ? 'Zurückziehen' : 'Löschen')) { await guard(() => api('DELETE', `/api/absences/${a.id}`))(); refresh(); } });
  $$('[data-dec]', root).forEach((b) => b.onclick = () => {
    const a = list.find((x) => x.id === +b.dataset.id), ok = b.dataset.dec === 'approved';
    modal({ title: ok ? 'Antrag genehmigen' : 'Antrag ablehnen', submit: ok ? 'Genehmigen' : 'Ablehnen',
      body: `<p style="margin:0 0 14px"><b>${esc(a.user_name || '')}</b> · ${ABS[a.type][0]} · ${absSpan(a)}${a.days !== null ? ` · ${num(a.days)} Tage` : ''}</p>${field(`Hinweis an ${esc((a.user_name || '').split(' ')[0])} (optional)`, '<input type="text" name="note" maxlength="300">')}`,
      onSubmit: async (fd) => { await api('PUT', `/api/absences/${a.id}`, { status: b.dataset.dec, decision_note: fd.get('note') }); toast(ok ? 'Genehmigt' : 'Abgelehnt'); pollSummary(); refresh(); } });
  });
  $$('[data-attach]', root).forEach((b) => b.onclick = () => {
    const inp = Object.assign(document.createElement('input'), { type: 'file', accept: 'image/*,application/pdf' });
    inp.onchange = guard(async () => { if (!inp.files[0]) return; const f = await uploadTo(inp.files[0], { ctx: 'personal', category: 'sick' }); await api('PUT', `/api/absences/${b.dataset.attach}`, { file_id: f.id }); toast('Bescheinigung hochgeladen'); refresh(); });
    inp.click();
  });
}
async function pageAbsences(main) {
  const [st, list] = await Promise.all([api('GET', '/api/time/me'), api('GET', '/api/absences')]);
  const v = st.vacation, used = v.entitled ? Math.min(100, (v.taken / v.entitled) * 100) : 0, pend = v.entitled ? Math.min(100 - used, (v.pending / v.entitled) * 100) : 0;
  main.innerHTML = `<div class="page"><div class="page-head"><div><h1>Urlaub & Krankheit</h1><p>Urlaub beantragen, krank melden und den Überblick behalten.</p></div>
      <div class="actions"><button class="btn" data-new="sick">${icon('plus', 16)}Krank melden</button><button class="btn primary" data-new="vacation">${icon('sun', 16)}Urlaub beantragen</button></div></div>${timeTabs('abwesenheit')}
    <div class="grid2"><section class="card"><div class="card-h"><h3>Meine Abwesenheiten</h3></div><div class="card-b">${absenceRows(list) || `<div class="empty">${icon('sun', 28)}Noch nichts eingetragen.</div>`}</div></section>
    <div class="stack"><section class="card"><div class="card-h"><h3>Urlaubskonto ${v.year}</h3></div><div class="card-b vac">
        <div class="vacnum"><b>${num(v.remaining)}</b><span>Tage übrig</span></div>
        <div class="vacbar"><i style="width:${used}%"></i><i class="p" style="width:${pend}%"></i></div>
        <div class="vacleg"><span><i></i>Genommen / genehmigt: ${num(v.taken)}</span><span><i class="p"></i>Beantragt: ${num(v.pending)}</span><span>Anspruch: ${num(v.entitled)}</span></div></div></section>
      <section class="card"><div class="card-h"><h3>Weitere Anträge</h3></div><div class="card-b">
        <div class="li" data-new="comp"><span class="ft soon">${icon('clock', 18)}</span><div class="t"><b>Überstunden-Ausgleich</b><small>Freie Tage aus dem Stundenkonto (aktuell ${hmSigned(st.balance)} Std.)</small></div>${icon('right', 16)}</div>
        <div class="li" data-new="other"><span class="ft">${icon('cal', 18)}</span><div class="t"><b>Sonstige Abwesenheit</b><small>Berufsschule, Fortbildung, Sonderurlaub …</small></div>${icon('right', 16)}</div></div></section></div></div></div>`;
  $$('[data-new]', main).forEach((b) => b.addEventListener('click', () => absenceModal(b.dataset.new, { vac: v })));
  bindAbsences(main, list);
}

/* ---------- Persönliche Unterlagen ---------- */
function docsCard(files, { title = 'Meine Unterlagen', owner = null } = {}) {
  return `<section class="card"><div class="card-h"><h3>${esc(title)}</h3><span class="sp"></span><select data-doccat style="width:auto;height:32px">${options(owner ? DOCCATS.filter((c) => c[0] !== 'sick') : DOCCATS.filter((c) => c[0] !== 'payslip' && c[0] !== 'contract'), owner ? 'payslip' : 'certificate')}</select>
      <button class="btn sm primary" data-docup>${icon('upload', 14)}Hochladen</button><input type="file" data-docfi multiple hidden></div><div class="card-b">
    ${files.map((f) => `<div class="li plain"><a class="nm" href="/api/files/${f.id}/download" data-fname="${esc(f.name)}" data-fsize="${f.size}" style="display:flex;gap:12px;align-items:center;flex:1;min-width:0;color:inherit;text-decoration:none"><span class="ft">${esc(ext(f.name))}</span><div class="t"><b>${esc(f.name)}</b><small>${docCat(f.category)} · ${new Date(f.created_at).toLocaleDateString('de-DE', { day: 'numeric', month: 'short', year: 'numeric' })} · ${fmtSize(f.size)}${f.uploader_id !== (owner ? owner.id : S.me.id) ? ` · von ${esc(userById(f.uploader_id)?.name || 'Verwaltung')}` : ''}</small></div></a>
      <a class="icon-btn" href="/api/files/${f.id}/download" title="Herunterladen" style="display:inline-grid">${icon('down')}</a>${isAdmin() || f.uploader_id === S.me.id ? `<button class="icon-btn" data-docdel="${f.id}" title="Löschen">${icon('trash')}</button>` : ''}</div>`).join('') || `<div class="empty">${icon('folder', 28)}Noch keine Unterlagen.</div>`}</div></section>`;
}
function bindDocs(root, files, owner = null) {
  const fi = $('[data-docfi]', root);
  $('[data-docup]', root).onclick = () => fi.click();
  fi.onchange = guard(async () => { for (const f of fi.files) await uploadTo(f, { ctx: 'personal', category: $('[data-doccat]', root).value, ...(owner ? { owner: owner.id } : {}) }); toast('Hochgeladen'); refresh(); });
  $$('[data-docdel]', root).forEach((b) => b.onclick = async () => { const f = files.find((x) => x.id === +b.dataset.docdel); if (await confirmBox(`„${f.name}“ wird gelöscht.`)) { await guard(() => api('DELETE', `/api/personal-files/${f.id}`))(); refresh(); } });
}
async function pageDocs(main) {
  const files = await api('GET', '/api/personal-files');
  main.innerHTML = `<div class="page" style="max-width:900px"><div class="page-head"><div><h1>Meine Unterlagen</h1><p>Krankmeldungen, Nachweise, Lohnabrechnungen – nur du und die Administratoren können sie sehen.</p></div></div>${timeTabs('unterlagen')}${docsCard(files)}</div>`;
  bindDocs(main, files);
}

/* ---------- Administratoren: Team-Zeiten ---------- */
async function pageTeamTime(main) {
  S.timeMonth ||= monthStr();
  const data = await api('GET', `/api/time/overview?month=${S.timeMonth}`);
  const users = data.users.filter((u) => u.active || u.worked || u.credit);
  main.innerHTML = `<div class="page"><div class="page-head"><div><h1>Team-Zeiten</h1><p>Arbeitszeiten, Stundenkonten und Urlaub aller Mitarbeiter.</p></div>
      <div class="actions"><a class="btn" href="/api/time/export?month=${S.timeMonth}" download>${icon('down', 16)}Monat als Tabelle (CSV)</a></div></div>${timeTabs('team')}${monthNav(S.timeMonth)}
    <div class="card" style="overflow:auto"><table class="tbl timetbl"><thead><tr><th>Mitarbeiter</th><th class="r">Ist</th><th class="hide-m r">Soll</th><th class="r">Saldo Monat</th><th class="hide-m r">Urlaub</th><th class="hide-m r">Krank</th><th class="r">Stundenkonto</th><th class="hide-m r">Resturlaub</th></tr></thead><tbody>
      ${users.map((u) => `<tr data-user="${u.id}" style="cursor:pointer"><td><span style="display:inline-flex;gap:10px;align-items:center">${avatar(userById(u.id) || u, 28)}<b>${esc(u.name)}</b>${u.present ? '<span class="chip ok">anwesend</span>' : ''}${u.review ? `<span class="chip late">${icon('alert', 13)}prüfen</span>` : ''}</span></td>
        <td class="r"><b>${hm(u.worked + u.credit)}</b></td><td class="hide-m r muted">${hm(u.target)}</td><td class="r ${u.diff < 0 ? 'neg' : 'pos'}">${hmSigned(u.diff)}</td><td class="hide-m r">${u.vacation ? num(u.vacation) + ' T.' : ''}</td><td class="hide-m r">${u.sick ? num(u.sick) + ' T.' : ''}</td>
        <td class="r ${u.balance < 0 ? 'neg' : 'pos'}"><b>${hmSigned(u.balance)}</b></td><td class="hide-m r">${num(u.remaining)} T.</td></tr>`).join('')}</tbody></table></div>
    <p class="muted" style="font-size:13px;margin:12px 4px">Auf eine Zeile klicken, um die Tage zu sehen, Zeiten zu korrigieren und Wochenstunden oder Urlaubsanspruch festzulegen. „Ist“ enthält Gutschriften für Urlaub, Krankheit und Feiertage.</p></div>`;
  bindMonthNav(main);
  $$('[data-user]', main).forEach((r) => r.onclick = () => { location.hash = `#/zeit/team/${r.dataset.user}`; });
}
function entryModal(user, e, date) {
  const isNew = !e, start = e ? new Date(e.start) : null, end = e && e.end ? new Date(e.end) : null;
  const hhmm = (d) => `${pad(d.getHours())}:${pad(d.getMinutes())}`;
  const { d } = modal({
    title: `${isNew ? 'Zeit nachtragen' : 'Zeit korrigieren'} – ${user.name}`, submit: 'Speichern',
    extra: isNew ? '' : `<button type="button" class="btn danger" id="del">${icon('trash', 16)}Löschen</button>`,
    body: `${field('Datum', `<input type="date" name="date" value="${e ? ymd(start) : date}">`)}
      <div class="row">${field('Kommen', `<input type="time" name="from" value="${e ? hhmm(start) : '07:00'}">`)}${field('Gehen', `<input type="time" name="to" value="${end ? hhmm(end) : isNew ? '16:00' : ''}">`)}</div>
      ${field('Projekt (optional)', `<select name="project_id">${projectOptions(e ? e.project_id : null)}</select>`)}
      ${field('Grund der Änderung', `<input type="text" name="note" maxlength="300" value="${esc(e ? e.note : '')}" placeholder="z. B. Stempeln vergessen">`)}
      <p class="muted" style="font-size:12.5px;margin:0">Änderungen werden mit Namen und Uhrzeit im Protokoll festgehalten.</p>`,
    onSubmit: async (fd) => {
      if (!fd.get('date') || !fd.get('from')) throw new Error('Bitte Datum und Beginn angeben');
      const iso = (t) => new Date(`${fd.get('date')}T${t}`).toISOString();
      const body = { user_id: user.id, start: iso(fd.get('from')), end: fd.get('to') ? iso(fd.get('to')) : null, project_id: fd.get('project_id') || null, note: fd.get('note') };
      if (isNew) await api('POST', '/api/time/entries', body); else await api('PUT', `/api/time/entries/${e.id}`, body);
      toast('Gespeichert'); refresh();
    },
  });
  const del = $('#del', d);
  if (del) del.onclick = async () => { if (await confirmBox('Diese Buchung wird gelöscht.')) { await guard(() => api('DELETE', `/api/time/entries/${e.id}`))(); d.close(); refresh(); } };
}
function workModal(user, w) {
  modal({
    title: `Arbeitszeit-Vorgaben – ${user.name}`, submit: 'Speichern',
    body: `<div class="row">${field('Wochenstunden', `<input type="text" name="weekly_hours" inputmode="decimal" value="${num(w.weekly_hours)}">`)}${field('Urlaubstage pro Jahr', `<input type="text" name="vacation_days" inputmode="decimal" value="${num(w.vacation_days)}">`)}</div>
      <label class="f"><span>Arbeitstage</span><div class="pick wd">${WDAYS.map((l, i) => `<label><input type="checkbox" name="wd" value="${i + 1}" ${w.workdays.includes(i + 1) ? 'checked' : ''}>${l}</label>`).join('')}</div></label>
      <div class="row">${field('Zeiterfassung zählt ab', `<input type="date" name="time_start" value="${esc(w.time_start)}">`)}${field('Übertrag Stundenkonto (Std.)', `<input type="text" name="overtime_start" inputmode="decimal" value="${num(w.overtime_start)}">`)}</div>
      <p class="muted" style="font-size:12.5px;margin:0">Die Wochenstunden werden gleichmäßig auf die Arbeitstage verteilt. Der Übertrag ist der Stand des Stundenkontos am Starttag (z. B. aus der bisherigen Liste), Minusstunden mit „-“.</p>`,
    onSubmit: async (fd) => { await api('PUT', `/api/users/${user.id}/work`, { weekly_hours: fd.get('weekly_hours'), vacation_days: fd.get('vacation_days'), workdays: fd.getAll('wd').map(Number), time_start: fd.get('time_start'), overtime_start: fd.get('overtime_start') }); toast('Gespeichert'); refresh(); },
  });
}
async function pageUserTime(main, id) {
  S.timeMonth ||= monthStr();
  const { from, to } = monthRange(S.timeMonth);
  const [data, abs, files, ov] = await Promise.all([api('GET', `/api/time/days?user=${id}&from=${from}&to=${to}`), api('GET', `/api/absences?user=${id}`), api('GET', `/api/personal-files?user=${id}`), api('GET', `/api/time/overview?month=${monthStr()}`)]);
  const user = data.user, u = userById(id) || user, row = ov.users.find((x) => x.id === id) || {}, w = data.work;
  const entries = new Map(data.days.flatMap((d) => d.entries).map((e) => [e.id, e]));
  main.innerHTML = `<div class="page"><div class="page-head"><div style="display:flex;gap:14px;align-items:center"><a class="icon-btn" href="#/zeit/team" aria-label="Zurück">${icon('left', 20)}</a>${avatar(u, 44)}<div><h1>${esc(user.name)}</h1><p>${num(w.weekly_hours)} Std./Woche · ${w.workdays.map((d) => WDAYS[d - 1]).join(', ')} · ${num(w.vacation_days)} Urlaubstage</p></div></div>
      <div class="actions"><button class="btn" id="work">${icon('edit', 16)}Vorgaben</button><button class="btn" id="absn">${icon('sun', 16)}Abwesenheit eintragen</button><button class="btn primary" id="addt">${icon('plus', 16)}Zeit nachtragen</button></div></div>
    ${statCards({ noWeek: true, monthWorked: (row.worked || 0) + (row.credit || 0), monthTarget: row.target || 0, balance: data.balance, vacation: data.vacation })}
    ${monthNav(S.timeMonth)}${daysTable(data.days, { edit: true, start: data.start })}
    <div class="grid2" style="margin-top:20px"><section class="card"><div class="card-h"><h3>Abwesenheiten</h3></div><div class="card-b">${absenceRows(abs.map((a) => ({ ...a, user_name: user.name })), { admin: true }) || '<div class="empty">Keine Einträge.</div>'}</div></section>
      <div id="docs">${docsCard(files, { title: 'Unterlagen (nur für diese Person sichtbar)', owner: user })}</div></div></div>`;
  bindMonthNav(main);
  $('#work').onclick = () => workModal(user, w);
  $('#addt').onclick = () => entryModal(user, null, todayStr());
  $('#absn').onclick = () => {
    const { d } = modal({ title: 'Was möchtest du eintragen?', readonly: true, body: `<div class="stack" style="gap:8px">${Object.entries(ABS).map(([k, v]) => `<button type="button" class="btn" data-k="${k}" style="justify-content:flex-start">${v[0]}</button>`).join('')}</div>` });
    $$('[data-k]', d).forEach((b) => b.onclick = () => { d.close(); absenceModal(b.dataset.k, { forUser: user, vac: data.vacation }); });
  };
  $$('[data-entry]', main).forEach((b) => b.onclick = () => entryModal(user, entries.get(+b.dataset.entry)));
  $$('[data-add]', main).forEach((b) => b.onclick = () => entryModal(user, null, b.dataset.add));
  bindAbsences(main, abs.map((a) => ({ ...a, user_name: user.name })));
  bindDocs($('#docs', main), files, user);
}

/* ---------- Administratoren: Anträge ---------- */
async function pageRequests(main) {
  const list = await api('GET', '/api/absences?all=1');
  const pending = list.filter((a) => a.status === 'pending'), rest = list.filter((a) => a.status !== 'pending');
  main.innerHTML = `<div class="page" style="max-width:1000px"><div class="page-head"><div><h1>Anträge</h1><p>Urlaub und andere Abwesenheiten genehmigen oder ablehnen. Krankmeldungen gelten sofort.</p></div></div>${timeTabs('antraege')}
    <section class="card" style="margin-bottom:20px"><div class="card-h"><h3>Offen</h3></div><div class="card-b">${absenceRows(pending, { admin: true }) || `<div class="empty">${icon('check', 28)}Keine offenen Anträge.</div>`}</div></section>
    <section class="card"><div class="card-h"><h3>Aktuelle und kommende Abwesenheiten</h3></div><div class="card-b">${absenceRows(rest, { admin: true }) || '<div class="empty">Keine Einträge.</div>'}</div></section></div>`;
  bindAbsences(main, list);
}

/* ---------- Administratoren: QR-Codes (Stempelstellen) und Regeln ---------- */
function stationModal(st) {
  const isNew = !st;
  const { d } = modal({
    title: isNew ? 'Neuer QR-Code zum Stempeln' : 'QR-Code bearbeiten', submit: isNew ? 'Anlegen' : 'Speichern',
    extra: isNew ? '' : `<button type="button" class="btn danger" id="del">${icon('trash', 16)}Löschen</button>`,
    body: `${field('Name', `<input type="text" name="name" maxlength="80" value="${esc(st ? st.name : '')}" placeholder="z. B. Betriebshof, Büro, Baustelle Müller">`)}
      ${field('Projekt / Baustelle (optional)', `<select name="project_id">${projectOptions(st ? st.project_id : null)}</select>`)}
      <label class="f"><span>Art</span><div class="stack" style="gap:8px">
        <label class="check optcard"><input type="radio" name="mode" value="static" ${!st || st.mode === 'static' ? 'checked' : ''}><span><b>Ausdruck</b><br><span class="muted">Der Code bleibt gleich. Ausdrucken und am Eingang, im Fahrzeug oder auf der Baustelle aufhängen.</span></span></label>
        <label class="check optcard"><input type="radio" name="mode" value="rotating" ${st && st.mode === 'rotating' ? 'checked' : ''}><span><b>Bildschirm (wechselnder Code)</b><br><span class="muted">Der Code wechselt alle 30 Sekunden und läuft auf einem Tablet oder Bildschirm am Eingang. Ein Foto vom Code nützt später nichts – gestempelt werden kann nur vor Ort.</span></span></label></div></label>
      ${isNew ? '' : '<label class="check"><input type="checkbox" name="renew">Neuen Code erzeugen (der alte Ausdruck wird ungültig)</label>'}`,
    onSubmit: async (fd) => {
      const body = { name: fd.get('name'), project_id: fd.get('project_id') || null, mode: fd.get('mode'), renew: !!fd.get('renew') };
      if (isNew) await api('POST', '/api/time/stations', body); else await api('PUT', `/api/time/stations/${st.id}`, body);
      toast('Gespeichert'); refresh();
    },
  });
  const del = $('#del', d);
  if (del) del.onclick = async () => { if (await confirmBox(`„${st.name}“ wird gelöscht. Der QR-Code funktioniert danach nicht mehr.`)) { await guard(() => api('DELETE', `/api/time/stations/${st.id}`))(); d.close(); refresh(); } };
}
function printStation(st) {
  let box = $('#printbox'); if (box) box.remove();
  box = document.createElement('div'); box.id = 'printbox';
  box.innerHTML = `<div class="pb-brand">${esc((S.brand && S.brand.name) || 'Betriebsportal')}</div><h1>Zeiterfassung</h1><h2>${esc(st.name)}${st.project ? `<br><small>${esc(st.project)}</small>` : ''}</h2>
    <div class="pb-qr">${qrSvg(st.url)}</div><p><b>Kommen und Gehen:</b> Code mit der Handy-Kamera scannen.</p><p class="s">Beim ersten Mal mit dem eigenen Zugang anmelden – danach genügt das Scannen.</p>`;
  document.body.appendChild(box);
  window.print();
}
async function pageStations(main) {
  const [data, ov] = await Promise.all([api('GET', '/api/time/stations'), api('GET', `/api/time/overview?month=${monthStr()}`)]);
  const cfg = ov.settings, list = data.stations;
  const localOnly = /^http:\/\/(1(0|27|92\.168|72\.(1[6-9]|2\d|3[01]))\.|localhost)/.test(data.public_url);
  main.innerHTML = `<div class="page"><div class="page-head"><div><h1>QR-Codes & Regeln</h1><p>Hier legst du fest, wo und wie gestempelt wird.</p></div>
      <div class="actions"><button class="btn primary" id="new">${icon('plus', 16)}Neuer QR-Code</button></div></div>${timeTabs('stempelstellen')}
    <div class="notice ${localOnly ? '' : 'ok'}" style="${localOnly ? 'background:var(--warn-soft);color:var(--warn)' : ''}">${localOnly
      ? `Die QR-Codes führen zu <b>${esc(data.public_url)}</b>. Das funktioniert, solange das Handy im <b>Firmen-WLAN</b> ist. Für Baustellen und unterwegs braucht das Portal eine Adresse im Internet (siehe unten „Adresse für Handys“).`
      : `Die QR-Codes führen zu <b>${esc(data.public_url)}</b>.`}</div>
    <div class="stations">${list.map((st) => `<section class="card station ${st.active ? '' : 'off'}"><div class="qr">${st.mode === 'static' ? qrSvg(st.url) : `<div class="rot">${icon('qr', 44)}<span>wechselt alle 30 Sek.</span></div>`}</div>
      <div class="sb"><h3>${esc(st.name)}</h3><p class="muted">${st.project ? esc(st.project) + ' · ' : ''}${st.mode === 'static' ? 'Ausdruck' : 'Bildschirm'}</p>
        <div class="acts">${st.mode === 'static' ? `<button class="btn sm primary" data-print="${st.id}">${icon('print', 14)}Drucken</button>` : `<button class="btn sm primary" data-copy="${st.id}">${icon('copy', 14)}Adresse für den Bildschirm kopieren</button>`}<button class="btn sm" data-edit="${st.id}">${icon('edit', 14)}Bearbeiten</button></div>
        ${st.mode === 'rotating' ? '<p class="muted s">Die kopierte Adresse im Browser des Tablets oder Bildschirms am Eingang öffnen – ohne Anmeldung.</p>' : ''}</div></section>`).join('')
      || `<div class="card empty" style="grid-column:1/-1">${icon('qr', 32)}Noch kein QR-Code angelegt. Lege den ersten an – z. B. „Betriebshof“ – und hänge ihn am Eingang auf.</div>`}</div>
    <section class="card set" style="margin-top:20px"><div class="set-h"><span class="ico">${icon('gear', 20)}</span><div><h3>Regeln</h3><p class="muted">Gelten für alle Mitarbeiter.</p></div></div><div class="set-b"><form id="rules">
      <div class="row">${field('Bundesland (für die Feiertage)', `<select name="state">${options(Object.entries(cfg.states), cfg.state)}</select>`)}
        ${field('Adresse für Handys (im QR-Code)', `<input type="text" name="public_url" value="${esc(cfg.public_url)}" placeholder="${esc(data.lan_url)} (automatisch)" spellcheck="false">`)}</div>
      <label class="check" style="margin-bottom:10px"><input type="checkbox" name="auto_break" ${cfg.auto_break ? 'checked' : ''}><span><b>Gesetzliche Pause automatisch abziehen</b> <span class="muted">– 30 Minuten ab mehr als 6 Stunden, 45 Minuten ab mehr als 9 Stunden, soweit nicht ohnehin ausgestempelt wurde</span></span></label>
      <label class="check" style="margin-bottom:16px"><input type="checkbox" name="manual" ${cfg.manual ? 'checked' : ''}><span><b>Stempeln auch per Knopf im Programm erlauben</b> <span class="muted">– ausgeschaltet geht es nur über einen QR-Code, also nur vor Ort</span></span></label>
      <button class="btn primary">Speichern</button></form></div></section></div>`;
  $('#new').onclick = () => stationModal();
  const byId = (id) => list.find((s) => s.id === +id);
  $$('[data-edit]', main).forEach((b) => b.onclick = () => stationModal(byId(b.dataset.edit)));
  $$('[data-print]', main).forEach((b) => b.onclick = () => printStation(byId(b.dataset.print)));
  $$('[data-copy]', main).forEach((b) => b.onclick = guard(async () => { const url = byId(b.dataset.copy).display; try { await navigator.clipboard.writeText(url); toast('Adresse kopiert'); } catch { modal({ title: 'Adresse für den Bildschirm', readonly: true, body: `<input type="text" readonly value="${esc(url)}" onfocus="this.select()">` }); } }));
  $('#rules').onsubmit = guard(async (e) => { e.preventDefault(); const fd = new FormData(e.target); await api('PUT', '/api/admin/time', { state: fd.get('state'), public_url: fd.get('public_url'), auto_break: !!fd.get('auto_break'), manual: !!fd.get('manual') }); toast('Gespeichert'); refresh(); });
}

PAGES.zeit = (main) => {
  const [, tab, id] = hashParts();
  if (['team', 'antraege', 'stempelstellen'].includes(tab) && !isAdmin()) { location.hash = '#/zeit'; return; }
  return tab === 'abwesenheit' ? pageAbsences(main) : tab === 'unterlagen' ? pageDocs(main) : tab === 'team' ? (id ? pageUserTime(main, Number(id)) : pageTeamTime(main)) : tab === 'antraege' ? pageRequests(main) : tab === 'stempelstellen' ? pageStations(main) : pageMyTime(main);
};

/* ---------- Übersicht: Stempel-Leiste ganz oben ---------- */
const dashboardBeforeTime = PAGES[''];
PAGES[''] = async function (main) {
  const [, st] = await Promise.all([dashboardBeforeTime(main), api('GET', '/api/time/me').catch(() => null)]);
  const stats = $('.stats', main); if (!st || !stats) return;
  stats.insertAdjacentHTML('beforebegin', stampCard(st, true));
  bindStamp(main);
};
